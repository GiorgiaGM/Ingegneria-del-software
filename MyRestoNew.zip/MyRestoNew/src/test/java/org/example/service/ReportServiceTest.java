package org.example.service;

import org.example.model.Ordine;
import org.example.model.Pagamento;
import org.example.model.Piatto;
import org.example.model.Report;
import org.example.model.RigaOrdine;
import org.example.repository.OrdineRepository;
import org.example.repository.PagamentoRepository;
import org.example.repository.PiattoRepository;
import org.example.repository.ReportRepository;
import org.example.repository.RigaOrdineRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ReportServiceTest {

    @Mock
    private ReportRepository reportRepository;
    @Mock
    private OrdineRepository ordineRepository;
    @Mock
    private PagamentoRepository pagamentoRepository;
    @Mock
    private RigaOrdineRepository rigaOrdineRepository;
    @Mock
    private PiattoRepository piattoRepository;

    @InjectMocks
    private ReportService reportService;
    private Report testReportIncassi;
    private Pagamento testPagamento1;
    private Pagamento testPagamento2;

    @BeforeEach
    void setUp() {
        LocalDate dataInizioReport = LocalDate.of(2025, 6, 1);
        LocalDate dataFineReport = LocalDate.of(2025, 6, 30);

        testReportIncassi = new Report(
                1,
                "INCASSI",
                dataInizioReport,
                dataFineReport,
                "Contenuto di esempio del report incassi"
        );

        testPagamento1 = new Pagamento(
                101,
                null,
                100.0,
                LocalDateTime.of(2025, 6, 15, 10, 0),
                null
        );
        testPagamento2 = new Pagamento(
                102,
                null,
                50.0,
                LocalDateTime.of(2025, 6, 20, 14, 30),
                null
        );

        reset(reportRepository, ordineRepository, pagamentoRepository, rigaOrdineRepository, piattoRepository);
    }

    @Test
    void testGeneraReportIncassi_Successo_ConPagamenti() {
        LocalDate dataInizio = LocalDate.of(2025, 6, 1);
        LocalDate dataFine = LocalDate.of(2025, 6, 30);
        LocalDateTime inizioPeriodo = dataInizio.atStartOfDay();
        LocalDateTime finePeriodo = dataFine.atTime(LocalTime.MAX);
        int nextReportId = 2;

        List<Pagamento> pagamentiNelPeriodo = Arrays.asList(testPagamento1, testPagamento2);

        when(pagamentoRepository.findByDataPagamentoBetween(inizioPeriodo, finePeriodo))
                .thenReturn(pagamentiNelPeriodo);
        when(reportRepository.getNextId()).thenReturn(nextReportId);
        when(reportRepository.save(any(Report.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Report result = reportService.generaReportIncassi(dataInizio, dataFine);

        assertNotNull(result);
        assertEquals(nextReportId, result.getId());
        assertEquals("INCASSI", result.getTipoReport());
        assertEquals(dataInizio, result.getDataInizio());
        assertEquals(dataFine, result.getDataFine());
        assertTrue(result.getContenuto().contains(String.format(Locale.US, "Incasso Totale: %.2f EUR", 150.0)));
        assertTrue(result.getContenuto().contains("Numero di Pagamenti: 2"));

        verify(pagamentoRepository, times(1)).findByDataPagamentoBetween(inizioPeriodo, finePeriodo);
        verify(reportRepository, times(1)).getNextId();
        verify(reportRepository, times(1)).save(any(Report.class));
    }

    @Test
    void testGeneraReportIncassi_Successo_SenzaPagamenti() {
        LocalDate dataInizio = LocalDate.of(2025, 7, 1);
        LocalDate dataFine = LocalDate.of(2025, 7, 31);
        LocalDateTime inizioPeriodo = dataInizio.atStartOfDay();
        LocalDateTime finePeriodo = dataFine.atTime(LocalTime.MAX);
        int nextReportId = 3;

        when(pagamentoRepository.findByDataPagamentoBetween(inizioPeriodo, finePeriodo))
                .thenReturn(Collections.emptyList());
        when(reportRepository.getNextId()).thenReturn(nextReportId);
        when(reportRepository.save(any(Report.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Report result = reportService.generaReportIncassi(dataInizio, dataFine);

        assertNotNull(result);
        assertEquals(nextReportId, result.getId());
        assertEquals("INCASSI", result.getTipoReport());
        assertEquals(dataInizio, result.getDataInizio());
        assertEquals(dataFine, result.getDataFine());
        assertTrue(result.getContenuto().contains(String.format(Locale.US, "Incasso Totale: %.2f EUR", 0.0)));
        assertTrue(result.getContenuto().contains("Numero di Pagamenti: 0"));

        verify(pagamentoRepository, times(1)).findByDataPagamentoBetween(inizioPeriodo, finePeriodo);
        verify(reportRepository, times(1)).getNextId();
        verify(reportRepository, times(1)).save(any(Report.class));
    }

    @Test
    void testGeneraReportIncassi_DateNonValide_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                        reportService.generaReportIncassi(null, LocalDate.now()),
                "Date di inizio e fine non valide per il report degli incassi.");
        assertThrows(IllegalArgumentException.class, () ->
                        reportService.generaReportIncassi(LocalDate.now(), null),
                "Date di inizio e fine non valide per il report degli incassi.");
        assertThrows(IllegalArgumentException.class, () ->
                        reportService.generaReportIncassi(LocalDate.of(2025, 7, 1), LocalDate.of(2025, 6, 30)),
                "Date di inizio e fine non valide per il report degli incassi.");

        verifyNoInteractions(reportRepository, pagamentoRepository, ordineRepository, rigaOrdineRepository, piattoRepository);
    }
    @Test
    void testGeneraReportPiattiPiuVenduti_Successo_ConOrdini() {
        LocalDate dataInizio = LocalDate.of(2025, 1, 1);
        LocalDate dataFine = LocalDate.of(2025, 1, 31);
        LocalDateTime inizioPeriodo = dataInizio.atStartOfDay();
        LocalDateTime finePeriodo = dataFine.atTime(LocalTime.MAX);
        int nextReportId = 4;

        Ordine ordine1 = new Ordine(1, null, null, LocalDateTime.of(2025, 1, 10, 12, 0), "COMPLETATO", Collections.emptyList());
        Ordine ordine2 = new Ordine(2, null, null, LocalDateTime.of(2025, 1, 15, 14, 0), "COMPLETATO", Collections.emptyList());
        Ordine ordine3_fuoriPeriodo = new Ordine(3, null, null, LocalDateTime.of(2025, 2, 1, 9, 0), "COMPLETATO", Collections.emptyList());

        when(ordineRepository.findAll()).thenReturn(Arrays.asList(ordine1, ordine2, ordine3_fuoriPeriodo));

        Piatto pizza = new Piatto(1, "Pizza Margherita", "desc", 8.0f);
        Piatto pasta = new Piatto(2, "Pasta Carbonara", "desc", 12.0f);
        Piatto tiramisu = new Piatto(3, "Tiramisu", "desc", 5.0f);

        RigaOrdine riga1 = new RigaOrdine(101, 2, pizza.getPrezzo(), pizza, null, "normale", ordine1);
        RigaOrdine riga2 = new RigaOrdine(102, 1, pasta.getPrezzo(), pasta, null, "senza sale", ordine1);
        RigaOrdine riga3 = new RigaOrdine(103, 3, pizza.getPrezzo(), pizza, null, "doppia mozzarella", ordine2);
        RigaOrdine riga4 = new RigaOrdine(104, 1, tiramisu.getPrezzo(), tiramisu, null, "dessert", ordine2);

        when(rigaOrdineRepository.findByOrdineId(ordine1.getIdOrdine())).thenReturn(Arrays.asList(riga1, riga2));
        when(rigaOrdineRepository.findByOrdineId(ordine2.getIdOrdine())).thenReturn(Arrays.asList(riga3, riga4));

        when(reportRepository.getNextId()).thenReturn(nextReportId);
        when(reportRepository.save(any(Report.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Report result = reportService.generaReportPiattiPiuVenduti(dataInizio, dataFine);

        assertNotNull(result);
        assertEquals(nextReportId, result.getId());
        assertEquals("PIATTI_PIU_VENDUTI", result.getTipoReport());
        assertEquals(dataInizio, result.getDataInizio());
        assertEquals(dataFine, result.getDataFine());

        String contenuto = result.getContenuto();
        assertTrue(contenuto.contains("--- Report Piatti Più Venduti ---"));
        assertTrue(contenuto.contains(String.format("Periodo: dal %s al %s", dataInizio.format(DateTimeFormatter.ISO_DATE), dataFine.format(DateTimeFormatter.ISO_DATE))));
        assertTrue(contenuto.contains("Pizza Margherita: 5 unità"));
        assertTrue(contenuto.contains("Pasta Carbonara: 1 unità"));
        assertTrue(contenuto.contains("Tiramisu: 1 unità"));

        int indexPizza = contenuto.indexOf("Pizza Margherita");
        int indexPasta = contenuto.indexOf("Pasta Carbonara");
        int indexTiramisu = contenuto.indexOf("Tiramisu");
        assertTrue(indexPizza < indexPasta);
        assertTrue(indexPasta < indexTiramisu || indexTiramisu < indexPasta);

        verify(ordineRepository, times(1)).findAll();
        verify(rigaOrdineRepository, times(1)).findByOrdineId(ordine1.getIdOrdine());
        verify(rigaOrdineRepository, times(1)).findByOrdineId(ordine2.getIdOrdine());
        verify(rigaOrdineRepository, never()).findByOrdineId(ordine3_fuoriPeriodo.getIdOrdine());
        verify(piattoRepository, never()).findById(anyInt());
        verify(reportRepository, times(1)).getNextId();
        verify(reportRepository, times(1)).save(any(Report.class));
    }

    @Test
    void testGeneraReportPiattiPiuVenduti_Successo_SenzaOrdiniNelPeriodo() {
        LocalDate dataInizio = LocalDate.of(2025, 1, 1);
        LocalDate dataFine = LocalDate.of(2025, 1, 31);
        int nextReportId = 5;
        Ordine ordineFuoriPeriodo = new Ordine(1, null, null, LocalDateTime.of(2024, 1, 1, 12, 0), "COMPLETATO", Collections.emptyList());
        when(ordineRepository.findAll()).thenReturn(Arrays.asList(ordineFuoriPeriodo));

        when(reportRepository.getNextId()).thenReturn(nextReportId);
        when(reportRepository.save(any(Report.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Report result = reportService.generaReportPiattiPiuVenduti(dataInizio, dataFine);

        assertNotNull(result);
        assertEquals(nextReportId, result.getId());
        assertTrue(result.getContenuto().contains("Nessun piatto venduto nel periodo selezionato."));

        verify(ordineRepository, times(1)).findAll();
        verify(rigaOrdineRepository, never()).findByOrdineId(anyInt());
        verify(piattoRepository, never()).findById(anyInt());
        verify(reportRepository, times(1)).getNextId();
        verify(reportRepository, times(1)).save(any(Report.class));
    }

    @Test
    void testGeneraReportPiattiPiuVenduti_DateNonValide_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                        reportService.generaReportPiattiPiuVenduti(null, LocalDate.now()),
                "Date di inizio e fine non valide per il report dei piatti più venduti.");
        assertThrows(IllegalArgumentException.class, () ->
                        reportService.generaReportPiattiPiuVenduti(LocalDate.now(), null),
                "Date di inizio e fine non valide per il report dei piatti più venduti.");
        assertThrows(IllegalArgumentException.class, () ->
                        reportService.generaReportPiattiPiuVenduti(LocalDate.of(2025, 7, 1), LocalDate.of(2025, 6, 30)),
                "Date di inizio e fine non valide per il report dei piatti più venduti.");

        verifyNoInteractions(reportRepository, ordineRepository, pagamentoRepository, rigaOrdineRepository, piattoRepository);
    }

    @Test
    void testGetReportById_Esistente() {
        when(reportRepository.findById(testReportIncassi.getId())).thenReturn(Optional.of(testReportIncassi));

        Optional<Report> foundReport = reportService.getReportById(testReportIncassi.getId());

        assertTrue(foundReport.isPresent());
        assertEquals(testReportIncassi, foundReport.get());
        verify(reportRepository, times(1)).findById(testReportIncassi.getId());
    }

    @Test
    void testGetReportById_NonEsistente() {
        when(reportRepository.findById(999)).thenReturn(Optional.empty());

        Optional<Report> foundReport = reportService.getReportById(999);

        assertFalse(foundReport.isPresent());
        verify(reportRepository, times(1)).findById(999);
    }

    @Test
    void testGetAllReports_ListaNonVuota() {
        when(reportRepository.findAll()).thenReturn(Arrays.asList(testReportIncassi));

        List<Report> allReports = reportService.getAllReports();

        assertNotNull(allReports);
        assertEquals(1, allReports.size());
        assertTrue(allReports.contains(testReportIncassi));
        verify(reportRepository, times(1)).findAll();
    }

    @Test
    void testGetAllReports_ListaVuota() {
        when(reportRepository.findAll()).thenReturn(Collections.emptyList());

        List<Report> allReports = reportService.getAllReports();

        assertNotNull(allReports);
        assertTrue(allReports.isEmpty());
        verify(reportRepository, times(1)).findAll();
    }

    @Test
    void testGetReportsByTipo_Successo() {
        String tipo = "INCASSI";
        List<Report> reportsByType = Collections.singletonList(testReportIncassi);
        when(reportRepository.findByTipo(tipo)).thenReturn(reportsByType);

        List<Report> result = reportService.getReportsByTipo(tipo);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertTrue(result.contains(testReportIncassi));
        verify(reportRepository, times(1)).findByTipo(tipo);
    }

    @Test
    void testGetReportsByTipo_NessunReportPerTipo() {
        String tipo = "NON_ESISTENTE";
        when(reportRepository.findByTipo(tipo)).thenReturn(Collections.emptyList());

        List<Report> result = reportService.getReportsByTipo(tipo);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(reportRepository, times(1)).findByTipo(tipo);
    }

    @Test
    void testGetReportsByTipo_TipoNulloOVuoto_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                reportService.getReportsByTipo(null), "Il tipo di report non può essere vuoto.");
        assertThrows(IllegalArgumentException.class, () ->
                reportService.getReportsByTipo(""), "Il tipo di report non può essere vuoto.");
        assertThrows(IllegalArgumentException.class, () ->
                reportService.getReportsByTipo("   "), "Il tipo di report non può essere vuoto.");
        verifyNoInteractions(reportRepository, ordineRepository, pagamentoRepository, rigaOrdineRepository, piattoRepository);
    }

    @Test
    void testEliminaReport_Successo() {
        int idToDelete = testReportIncassi.getId();
        doNothing().when(reportRepository).deleteById(idToDelete);

        reportService.eliminaReport(idToDelete);

        verify(reportRepository, times(1)).deleteById(idToDelete);
    }

    @Test
    void testEliminaReport_IdNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                reportService.eliminaReport(0), "ID report non valido per l'eliminazione.");
        assertThrows(IllegalArgumentException.class, () ->
                reportService.eliminaReport(-5), "ID report non valido per l'eliminazione.");
        verifyNoInteractions(reportRepository, ordineRepository, pagamentoRepository, rigaOrdineRepository, piattoRepository);
    }
}