package org.example.service;

import org.example.model.Dipendente;
import org.example.repository.DipendenteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class DipendenteServiceTest {

    @Mock
    private DipendenteRepository dipendenteRepository;

    @InjectMocks
    private DipendenteService dipendenteService;

    private Dipendente dipendente1;
    private Dipendente dipendente2;

    @BeforeEach
    void setUp() {
        dipendente1 = new Dipendente(1, "Mario", "Rossi", "Developer");
        dipendente2 = new Dipendente(2, "Luisa", "Bianchi", "Tester");
    }

    @Test
    void testAggiungiNuovoDipendente_Successo() {
        when(dipendenteRepository.getNextId()).thenReturn(3);
        when(dipendenteRepository.save(any(Dipendente.class))).thenReturn(new Dipendente(3, "Paolo", "Verdi", "Analista"));

        Dipendente nuovoDipendente = dipendenteService.aggiungiNuovoDipendente("Paolo", "Verdi", "Analista");

        assertNotNull(nuovoDipendente);
        assertEquals("Paolo", nuovoDipendente.getNome());
        assertEquals("Verdi", nuovoDipendente.getCognome());
        assertEquals("Analista", nuovoDipendente.getRuolo());
        assertEquals(3, nuovoDipendente.getId());

        verify(dipendenteRepository, times(1)).getNextId();
        verify(dipendenteRepository, times(1)).save(any(Dipendente.class));
    }

    @Test
    void testAggiungiNuovoDipendente_NomeVuoto() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            dipendenteService.aggiungiNuovoDipendente("", "Verdi", "Analista");
        });
        assertEquals("Nome, cognome e ruolo del dipendente non possono essere vuoti.", thrown.getMessage());

        verify(dipendenteRepository, never()).getNextId();
        verify(dipendenteRepository, never()).save(any(Dipendente.class));
    }

    @Test
    void testAggiungiNuovoDipendente_CognomeNullo() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            dipendenteService.aggiungiNuovoDipendente("Paolo", null, "Analista");
        });
        assertEquals("Nome, cognome e ruolo del dipendente non possono essere vuoti.", thrown.getMessage());
    }

    @Test
    void testAggiungiNuovoDipendente_RuoloSpaziVuoti() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            dipendenteService.aggiungiNuovoDipendente("Paolo", "Verdi", "   ");
        });
        assertEquals("Nome, cognome e ruolo del dipendente non possono essere vuoti.", thrown.getMessage());
    }

    @Test
    void testGetDipendenteById_Esistente() {
        when(dipendenteRepository.findById(1)).thenReturn(Optional.of(dipendente1));

        Optional<Dipendente> foundDipendente = dipendenteService.getDipendenteById(1);

        assertTrue(foundDipendente.isPresent());
        assertEquals(dipendente1.getNome(), foundDipendente.get().getNome());
        verify(dipendenteRepository, times(1)).findById(1);
    }

    @Test
    void testGetDipendenteById_NonEsistente() {
        when(dipendenteRepository.findById(99)).thenReturn(Optional.empty());

        Optional<Dipendente> foundDipendente = dipendenteService.getDipendenteById(99);

        assertFalse(foundDipendente.isPresent());
        verify(dipendenteRepository, times(1)).findById(99);
    }

    @Test
    void testGetAllDipendenti_Successo() {
        when(dipendenteRepository.findAll()).thenReturn(Arrays.asList(dipendente1, dipendente2));

        List<Dipendente> dipendenti = dipendenteService.getAllDipendenti();

        assertNotNull(dipendenti);
        assertEquals(2, dipendenti.size());
        assertTrue(dipendenti.contains(dipendente1));
        assertTrue(dipendenti.contains(dipendente2));
        verify(dipendenteRepository, times(1)).findAll();
    }

    @Test
    void testGetAllDipendenti_NessunDipendente() {
        when(dipendenteRepository.findAll()).thenReturn(Collections.emptyList());

        List<Dipendente> dipendenti = dipendenteService.getAllDipendenti();

        assertNotNull(dipendenti);
        assertTrue(dipendenti.isEmpty());
        verify(dipendenteRepository, times(1)).findAll();
    }

    @Test
    void testGetDipendentiByRuolo_Successo() {
        when(dipendenteRepository.findByRuolo("Developer")).thenReturn(Collections.singletonList(dipendente1));

        List<Dipendente> developers = dipendenteService.getDipendentiByRuolo("Developer");
        assertNotNull(developers);
        assertEquals(1, developers.size());
        assertEquals("Developer", developers.get(0).getRuolo());
        verify(dipendenteRepository, times(1)).findByRuolo("Developer");
    }

    @Test
    void testGetDipendentiByRuolo_RuoloNonTrovato() {
        when(dipendenteRepository.findByRuolo("Manager")).thenReturn(Collections.emptyList());

        List<Dipendente> managers = dipendenteService.getDipendentiByRuolo("Manager");

        assertNotNull(managers);
        assertTrue(managers.isEmpty());
        verify(dipendenteRepository, times(1)).findByRuolo("Manager");
    }

    @Test
    void testGetDipendentiByRuolo_RuoloVuoto() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            dipendenteService.getDipendentiByRuolo("");
        });
        assertEquals("Il ruolo non può essere vuoto.", thrown.getMessage());
        verify(dipendenteRepository, never()).findByRuolo(anyString());
    }

    @Test
    void testAggiornaDipendente_Successo() {
        Dipendente dipendenteAggiornato = new Dipendente(1, "Mario Nuovo", "Rossi Nuovo", "Senior Developer");
        when(dipendenteRepository.save(dipendenteAggiornato)).thenReturn(dipendenteAggiornato);

        Dipendente result = dipendenteService.aggiornaDipendente(dipendenteAggiornato);

        assertNotNull(result);
        assertEquals("Mario Nuovo", result.getNome());
        assertEquals("Senior Developer", result.getRuolo());
        verify(dipendenteRepository, times(1)).save(dipendenteAggiornato);
    }

    @Test
    void testAggiornaDipendente_DipendenteNullo() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            dipendenteService.aggiornaDipendente(null);
        });
        assertEquals("Dipendente non valido per l'aggiornamento.", thrown.getMessage());
        verify(dipendenteRepository, never()).save(any(Dipendente.class));
    }

    @Test
    void testAggiornaDipendente_IdNonValido() {
        Dipendente dipendenteConIdZero = new Dipendente(0, "Nome", "Cognome", "Ruolo");
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            dipendenteService.aggiornaDipendente(dipendenteConIdZero);
        });
        assertEquals("Dipendente non valido per l'aggiornamento.", thrown.getMessage());
        verify(dipendenteRepository, never()).save(any(Dipendente.class));
    }

    @Test
    void testEliminaDipendente_Successo() {
        doNothing().when(dipendenteRepository).deleteById(1);

        dipendenteService.eliminaDipendente(1);

        verify(dipendenteRepository, times(1)).deleteById(1);
    }

    @Test
    void testEliminaDipendente_IdNonValido() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            dipendenteService.eliminaDipendente(0);
        });
        assertEquals("ID dipendente non valido per l'eliminazione.", thrown.getMessage());
        verify(dipendenteRepository, never()).deleteById(anyInt());
    }
}