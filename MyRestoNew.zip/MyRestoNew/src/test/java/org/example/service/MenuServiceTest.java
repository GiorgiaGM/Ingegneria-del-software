package org.example.service;

import org.example.model.Ingrediente;
import org.example.model.Menu;
import org.example.model.Piatto;
import org.example.repository.MenuRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MenuServiceTest {

    private MenuService menuService;
    private MenuRepository mockMenuRepository;

    @BeforeEach
    void setUp() {
        mockMenuRepository = mock(MenuRepository.class);
        menuService = new MenuService(mockMenuRepository);
    }

    @Test
    @DisplayName("Dovrebbe recuperare il menu completo con piatti e ingredienti")
    void shouldGetFullMenuWithPiattiAndIngredienti() {
        Ingrediente pomodoro = new Ingrediente(101, "Pomodoro", 0.5f);
        Ingrediente mozzarella = new Ingrediente(102, "Mozzarella", 1.0f);
        Piatto pizza = new Piatto(1, "Pizza", "desc", 10.0f, List.of(pomodoro, mozzarella));

        List<Piatto> mockPiatti = new ArrayList<>();
        mockPiatti.add(pizza);

        List<Ingrediente> mockIngredienti = new ArrayList<>();
        mockIngredienti.add(pomodoro);
        mockIngredienti.add(mozzarella);

        when(mockMenuRepository.findAllPiatti()).thenReturn(mockPiatti);
        when(mockMenuRepository.findAllIngredienti()).thenReturn(mockIngredienti);

        Menu menu = menuService.getFullMenu();

        assertNotNull(menu);
        assertFalse(menu.getPiatti().isEmpty());
        assertEquals(1, menu.getPiatti().size());
        assertEquals("Pizza", menu.getPiatti().get(0).getNome());

        assertFalse(menu.getIngredientiDisponibili().isEmpty());
        assertEquals(2, menu.getIngredientiDisponibili().size());
        assertEquals("Pomodoro", menu.getIngredientiDisponibili().get(0).getNome());
        verify(mockMenuRepository, times(1)).findAllPiatti();
        verify(mockMenuRepository, times(1)).findAllIngredienti();
    }

    @Test
    @DisplayName("Dovrebbe recuperare solo i piatti dal menu")
    void shouldGetAllPiattiFromMenu() {
        Ingrediente ingredientePasta = new Ingrediente(201, "Acqua", 0.1f);
        Piatto pasta = new Piatto(2, "Pasta", "desc", 12.0f, List.of(ingredientePasta));
        List<Piatto> mockPiatti = new ArrayList<>();
        mockPiatti.add(pasta);

        when(mockMenuRepository.findAllPiatti()).thenReturn(mockPiatti);

        List<Piatto> piatti = menuService.getAllPiattiFromMenu();

        assertNotNull(piatti);
        assertFalse(piatti.isEmpty());
        assertEquals(1, piatti.size());
        assertEquals("Pasta", piatti.get(0).getNome());
        verify(mockMenuRepository, times(1)).findAllPiatti();
    }

    @Test
    @DisplayName("Dovrebbe recuperare solo gli ingredienti dal menu")
    void shouldGetAllIngredientiFromMenu() {
        Ingrediente farina = new Ingrediente(201, "Farina", 0.8f);
        List<Ingrediente> mockIngredienti = new ArrayList<>();
        mockIngredienti.add(farina);

        when(mockMenuRepository.findAllIngredienti()).thenReturn(mockIngredienti);

        List<Ingrediente> ingredienti = menuService.getAllIngredientiFromMenu();

        assertNotNull(ingredienti);
        assertFalse(ingredienti.isEmpty());
        assertEquals(1, ingredienti.size());
        assertEquals("Farina", ingredienti.get(0).getNome());
        verify(mockMenuRepository, times(1)).findAllIngredienti();
    }

    @Test
    @DisplayName("Dovrebbe gestire un menu vuoto correttamente")
    void shouldHandleEmptyMenu() {
        when(mockMenuRepository.findAllPiatti()).thenReturn(new ArrayList<>());
        when(mockMenuRepository.findAllIngredienti()).thenReturn(new ArrayList<>());

        Menu menu = menuService.getFullMenu();

        assertNotNull(menu);
        assertTrue(menu.getPiatti().isEmpty());
        assertTrue(menu.getIngredientiDisponibili().isEmpty());
        verify(mockMenuRepository, times(1)).findAllPiatti();
        verify(mockMenuRepository, times(1)).findAllIngredienti();
    }
}