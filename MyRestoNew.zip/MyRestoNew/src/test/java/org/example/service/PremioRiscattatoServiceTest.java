package org.example.service;

import org.example.model.Cliente;
import org.example.model.Premio;
import org.example.model.PremioRiscattato;
import org.example.repository.ClienteRepository;
import org.example.repository.PremioRiscattatoRepository;
import org.example.repository.PremioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PremioRiscattatoServiceTest {

    @Mock
    private PremioRiscattatoRepository premioRiscattatoRepository;
    @Mock
    private ClienteRepository clienteRepository;
    @Mock
    private PremioRepository premioRepository;

    @InjectMocks
    private PremioRiscattatoService premioRiscattatoService;

    private Cliente testCliente1;
    private Cliente testCliente2;
    private Premio testPremio1;
    private Premio testPremio2;
    private PremioRiscattato premioRiscattato1;
    private PremioRiscattato premioRiscattato2;

    @BeforeEach
    void setUp() {
        testCliente1 = new Cliente(1, "Mario", "Rossi", "mario.rossi@example.com");
        testCliente2 = new Cliente(2, "Luisa", "Verdi", "luisa.verdi@example.com");

        testPremio1 = new Premio(101, "Buono Sconto 10€", "Buono sconto del valore di 10 euro", 100);
        testPremio2 = new Premio(102, "Cena Gratuita", "Una cena completa offerta dal ristorante", 500);

        premioRiscattato1 = new PremioRiscattato(1, testCliente1, testPremio1, LocalDateTime.now().minusDays(5));
        premioRiscattato2 = new PremioRiscattato(2, testCliente2, testPremio2, LocalDateTime.now().minusDays(1));

        reset(premioRiscattatoRepository, clienteRepository, premioRepository);
    }

    @Test
    void testRegistraRiscossionePremio_Successo() {
        int clienteId = testCliente1.getId();
        int premioId = testPremio1.getId();
        int nextId = 3;

        when(clienteRepository.findById(clienteId)).thenReturn(Optional.of(testCliente1));
        when(premioRepository.findById(premioId)).thenReturn(Optional.of(testPremio1));
        when(premioRiscattatoRepository.getNextId()).thenReturn(nextId);
        when(premioRiscattatoRepository.save(any(PremioRiscattato.class))).thenAnswer(invocation -> {
            PremioRiscattato saved = invocation.getArgument(0);
            assertEquals(nextId, saved.getId());
            assertEquals(testCliente1, saved.getCliente());
            assertEquals(testPremio1, saved.getPremio());
            assertNotNull(saved.getDataRiscatto());
            return saved;
        });

        PremioRiscattato result = premioRiscattatoService.registraRiscossionePremio(clienteId, premioId);

        assertNotNull(result);
        assertEquals(nextId, result.getId());
        assertEquals(testCliente1, result.getCliente());
        assertEquals(testPremio1, result.getPremio());
        assertNotNull(result.getDataRiscatto());

        verify(clienteRepository, times(1)).findById(clienteId);
        verify(premioRepository, times(1)).findById(premioId);
        verify(premioRiscattatoRepository, times(1)).getNextId();
        verify(premioRiscattatoRepository, times(1)).save(any(PremioRiscattato.class));
    }

    @Test
    void testRegistraRiscossionePremio_ClienteNonTrovato_ThrowsException() {
        int clienteId = 99;
        int premioId = testPremio1.getId();

        when(clienteRepository.findById(clienteId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            premioRiscattatoService.registraRiscossionePremio(clienteId, premioId);
        });

        assertEquals("Cliente non trovato con ID: " + clienteId, thrown.getMessage());
        verify(clienteRepository, times(1)).findById(clienteId);
        verifyNoInteractions(premioRepository, premioRiscattatoRepository);
    }

    @Test
    void testRegistraRiscossionePremio_PremioNonTrovato_ThrowsException() {
        int clienteId = testCliente1.getId();
        int premioId = 999;

        when(clienteRepository.findById(clienteId)).thenReturn(Optional.of(testCliente1));
        when(premioRepository.findById(premioId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            premioRiscattatoService.registraRiscossionePremio(clienteId, premioId);
        });

        assertEquals("Premio non trovato con ID: " + premioId, thrown.getMessage());
        verify(clienteRepository, times(1)).findById(clienteId);
        verify(premioRepository, times(1)).findById(premioId);
        verifyNoInteractions(premioRiscattatoRepository);
    }

    @Test
    void testGetPremioRiscattatoById_Esistente() {
        when(premioRiscattatoRepository.findById(premioRiscattato1.getId())).thenReturn(Optional.of(premioRiscattato1));

        Optional<PremioRiscattato> result = premioRiscattatoService.getPremioRiscattatoById(premioRiscattato1.getId());

        assertTrue(result.isPresent());
        assertEquals(premioRiscattato1, result.get());
        verify(premioRiscattatoRepository, times(1)).findById(premioRiscattato1.getId());
    }

    @Test
    void testGetPremioRiscattatoById_NonEsistente() {
        when(premioRiscattatoRepository.findById(999)).thenReturn(Optional.empty());

        Optional<PremioRiscattato> result = premioRiscattatoService.getPremioRiscattatoById(999);

        assertFalse(result.isPresent());
        verify(premioRiscattatoRepository, times(1)).findById(999);
    }

    @Test
    void testGetAllPremiRiscattati_Successo() {
        List<PremioRiscattato> premi = Arrays.asList(premioRiscattato1, premioRiscattato2);
        when(premioRiscattatoRepository.findAll()).thenReturn(premi);

        List<PremioRiscattato> result = premioRiscattatoService.getAllPremiRiscattati();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.contains(premioRiscattato1));
        assertTrue(result.contains(premioRiscattato2));
        verify(premioRiscattatoRepository, times(1)).findAll();
    }

    @Test
    void testGetAllPremiRiscattati_ListaVuota() {
        when(premioRiscattatoRepository.findAll()).thenReturn(Collections.emptyList());

        List<PremioRiscattato> result = premioRiscattatoService.getAllPremiRiscattati();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(premioRiscattatoRepository, times(1)).findAll();
    }

    @Test
    void testGetPremiRiscattatiByCliente_Successo() {
        int clienteId = testCliente1.getId();
        List<PremioRiscattato> premiCliente1 = Collections.singletonList(premioRiscattato1);

        when(clienteRepository.findById(clienteId)).thenReturn(Optional.of(testCliente1));
        when(premioRiscattatoRepository.findByCliente(testCliente1)).thenReturn(premiCliente1);

        List<PremioRiscattato> result = premioRiscattatoService.getPremiRiscattatiByCliente(clienteId);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertTrue(result.contains(premioRiscattato1));
        verify(clienteRepository, times(1)).findById(clienteId);
        verify(premioRiscattatoRepository, times(1)).findByCliente(testCliente1);
    }

    @Test
    void testGetPremiRiscattatiByCliente_ClienteNonTrovato_ThrowsException() {
        int clienteId = 99;
        when(clienteRepository.findById(clienteId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            premioRiscattatoService.getPremiRiscattatiByCliente(clienteId);
        });

        assertEquals("Cliente non trovato con ID: " + clienteId, thrown.getMessage());
        verify(clienteRepository, times(1)).findById(clienteId);
        verifyNoInteractions(premioRiscattatoRepository);
    }

    @Test
    void testGetPremiRiscattatiByCliente_NessunPremioPerCliente() {
        int clienteId = testCliente1.getId();

        when(clienteRepository.findById(clienteId)).thenReturn(Optional.of(testCliente1));
        when(premioRiscattatoRepository.findByCliente(testCliente1)).thenReturn(Collections.emptyList());

        List<PremioRiscattato> result = premioRiscattatoService.getPremiRiscattatiByCliente(clienteId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(clienteRepository, times(1)).findById(clienteId);
        verify(premioRiscattatoRepository, times(1)).findByCliente(testCliente1);
    }

    @Test
    void testGetPremiRiscattatiByPremio_Successo() {
        int premioId = testPremio1.getId();
        List<PremioRiscattato> premiRiscattatiPremio1 = Collections.singletonList(premioRiscattato1);

        when(premioRepository.findById(premioId)).thenReturn(Optional.of(testPremio1));
        when(premioRiscattatoRepository.findByPremio(testPremio1)).thenReturn(premiRiscattatiPremio1);

        List<PremioRiscattato> result = premioRiscattatoService.getPremiRiscattatiByPremio(premioId);

        assertNotNull(result);
        assertEquals(1, result.size());
        assertTrue(result.contains(premioRiscattato1));
        verify(premioRepository, times(1)).findById(premioId);
        verify(premioRiscattatoRepository, times(1)).findByPremio(testPremio1);
    }

    @Test
    void testGetPremiRiscattatiByPremio_PremioNonTrovato_ThrowsException() {
        int premioId = 999;
        when(premioRepository.findById(premioId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            premioRiscattatoService.getPremiRiscattatiByPremio(premioId);
        });

        assertEquals("Premio non trovato con ID: " + premioId, thrown.getMessage());
        verify(premioRepository, times(1)).findById(premioId);
        verifyNoInteractions(premioRiscattatoRepository);
    }

    @Test
    void testGetPremiRiscattatiByPremio_NessunRiscattatoPerPremio() {
        int premioId = testPremio1.getId();

        when(premioRepository.findById(premioId)).thenReturn(Optional.of(testPremio1));
        when(premioRiscattatoRepository.findByPremio(testPremio1)).thenReturn(Collections.emptyList());

        List<PremioRiscattato> result = premioRiscattatoService.getPremiRiscattatiByPremio(premioId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(premioRepository, times(1)).findById(premioId);
        verify(premioRiscattatoRepository, times(1)).findByPremio(testPremio1);
    }

    @Test
    void testEliminaPremioRiscattato_Successo() {
        int idToDelete = premioRiscattato1.getId();
        doNothing().when(premioRiscattatoRepository).deleteById(idToDelete);

        premioRiscattatoService.eliminaPremioRiscattato(idToDelete);

        verify(premioRiscattatoRepository, times(1)).deleteById(idToDelete);
    }

    @Test
    void testEliminaPremioRiscattato_IdNonValido_ThrowsException() {
        int invalidId = 0;
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            premioRiscattatoService.eliminaPremioRiscattato(invalidId);
        });

        assertEquals("ID Premio Riscattato non valido per l'eliminazione.", thrown.getMessage());
        verifyNoInteractions(premioRiscattatoRepository);
    }
}