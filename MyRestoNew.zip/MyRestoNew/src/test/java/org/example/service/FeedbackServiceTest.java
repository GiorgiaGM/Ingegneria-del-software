package org.example.service;

import org.example.model.Feedback;
import org.example.model.Cliente;
import org.example.model.Piatto;
import org.example.repository.FeedbackRepository;
import org.example.repository.ClienteRepository;
import org.example.repository.PiattoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FeedbackServiceTest {

    @Mock
    private FeedbackRepository feedbackRepository;
    @Mock
    private ClienteRepository clienteRepository;
    @Mock
    private PiattoRepository piattoRepository;

    @InjectMocks
    private FeedbackService feedbackService;

    private Cliente testCliente;
    private Cliente testCliente2;
    private Piatto testPiatto;
    private Feedback feedback1; // Con piatto
    private Feedback feedback2; // Senza piatto
    private Feedback feedback3; // Con un altro cliente

    @BeforeEach
    void setUp() {
        testCliente = new Cliente(1, "Mario", "Rossi", "mario.rossi@example.com");
        testCliente2 = new Cliente(2, "Luisa", "Bianchi", "luisa.b@example.com");

        testPiatto = new Piatto(101, "Pizza Margherita", "Pizza classica con pomodoro e mozzarella", 8.50f);

        feedback1 = new Feedback(1, testCliente, testPiatto, 5, "Ottima pizza!");
        feedback2 = new Feedback(2, testCliente, null, 4, "Servizio veloce.");
        feedback3 = new Feedback(3, testCliente2, testPiatto, 3, "Buono, ma migliorabile.");
    }

    @Test
    void testAggiungiFeedback_ConPiatto_Successo() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(piattoRepository.findById(testPiatto.getId())).thenReturn(Optional.of(testPiatto));
        when(feedbackRepository.getNextId()).thenReturn(1);
        when(feedbackRepository.save(any(Feedback.class))).thenReturn(feedback1);

        Feedback result = feedbackService.aggiungiFeedback(testCliente.getId(), Optional.of(testPiatto.getId()), "Ottima pizza!", 5);

        assertNotNull(result);
        assertEquals(feedback1.getCommento(), result.getCommento());
        assertEquals(feedback1.getValutazione(), result.getValutazione());
        assertEquals(testCliente.getId(), result.getCliente().getId());
        assertEquals(testPiatto.getId(), result.getPiatto().getId());

        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(piattoRepository, times(1)).findById(testPiatto.getId());
        verify(feedbackRepository, times(1)).getNextId();
        verify(feedbackRepository, times(1)).save(any(Feedback.class));
    }

    @Test
    void testAggiungiFeedback_SenzaPiatto_Successo() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(feedbackRepository.getNextId()).thenReturn(2);
        when(feedbackRepository.save(any(Feedback.class))).thenReturn(feedback2);

        Feedback result = feedbackService.aggiungiFeedback(testCliente.getId(), Optional.empty(), "Servizio veloce.", 4);

        assertNotNull(result);
        assertEquals(feedback2.getCommento(), result.getCommento());
        assertEquals(feedback2.getValutazione(), result.getValutazione());
        assertEquals(testCliente.getId(), result.getCliente().getId());
        assertNull(result.getPiatto());

        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(piattoRepository, never()).findById(anyInt());
        verify(feedbackRepository, times(1)).getNextId();
        verify(feedbackRepository, times(1)).save(any(Feedback.class));
    }

    @Test
    void testAggiungiFeedback_CommentoVuoto_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiungiFeedback(testCliente.getId(), Optional.of(testPiatto.getId()), "", 5);
        });
        assertEquals("Il commento non può essere vuoto.", thrown.getMessage());
        verifyNoInteractions(clienteRepository, piattoRepository, feedbackRepository);
    }

    @Test
    void testAggiungiFeedback_ValutazioneNonValida_TroppoBassa_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiungiFeedback(testCliente.getId(), Optional.of(testPiatto.getId()), "Commento", 0);
        });
        assertEquals("La valutazione deve essere tra 1 e 5.", thrown.getMessage());
        verifyNoInteractions(clienteRepository, piattoRepository, feedbackRepository);
    }

    @Test
    void testAggiungiFeedback_ValutazioneNonValida_TroppoAlta_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiungiFeedback(testCliente.getId(), Optional.of(testPiatto.getId()), "Commento", 6);
        });
        assertEquals("La valutazione deve essere tra 1 e 5.", thrown.getMessage());
        verifyNoInteractions(clienteRepository, piattoRepository, feedbackRepository);
    }

    @Test
    void testAggiungiFeedback_ClienteNonTrovato_ThrowsException() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiungiFeedback(testCliente.getId(), Optional.of(testPiatto.getId()), "Commento", 5);
        });
        assertEquals("Cliente non trovato con ID: " + testCliente.getId(), thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verifyNoInteractions(piattoRepository, feedbackRepository);
    }

    @Test
    void testAggiungiFeedback_PiattoNonTrovato_ThrowsException() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(piattoRepository.findById(testPiatto.getId())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiungiFeedback(testCliente.getId(), Optional.of(testPiatto.getId()), "Commento", 5);
        });
        assertEquals("Piatto non trovato con ID: " + testPiatto.getId(), thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(piattoRepository, times(1)).findById(testPiatto.getId());
        verifyNoInteractions(feedbackRepository);
    }

    @Test
    void testGetFeedbackById_Esistente() {
        when(feedbackRepository.findById(feedback1.getId())).thenReturn(Optional.of(feedback1));
        Optional<Feedback> result = feedbackService.getFeedbackById(feedback1.getId());
        assertTrue(result.isPresent());
        assertEquals(feedback1, result.get());
        verify(feedbackRepository, times(1)).findById(feedback1.getId());
    }

    @Test
    void testGetFeedbackById_NonEsistente() {
        when(feedbackRepository.findById(99)).thenReturn(Optional.empty());
        Optional<Feedback> result = feedbackService.getFeedbackById(99);
        assertFalse(result.isPresent());
        verify(feedbackRepository, times(1)).findById(99);
    }

    @Test
    void testGetAllFeedback_Successo() {
        when(feedbackRepository.findAll()).thenReturn(Arrays.asList(feedback1, feedback2));
        List<Feedback> allFeedback = feedbackService.getAllFeedback();
        assertNotNull(allFeedback);
        assertEquals(2, allFeedback.size());
        assertTrue(allFeedback.contains(feedback1));
        assertTrue(allFeedback.contains(feedback2));
        verify(feedbackRepository, times(1)).findAll();
    }

    @Test
    void testGetAllFeedback_NessunFeedback() {
        when(feedbackRepository.findAll()).thenReturn(Collections.emptyList());
        List<Feedback> allFeedback = feedbackService.getAllFeedback();
        assertNotNull(allFeedback);
        assertTrue(allFeedback.isEmpty());
        verify(feedbackRepository, times(1)).findAll();
    }

    @Test
    void testGetFeedbackByPiatto_Successo() {
        when(piattoRepository.findById(testPiatto.getId())).thenReturn(Optional.of(testPiatto));
        when(feedbackRepository.findByPiatto(testPiatto)).thenReturn(Arrays.asList(feedback1, feedback3));

        List<Feedback> feedbackList = feedbackService.getFeedbackByPiatto(testPiatto.getId());

        assertNotNull(feedbackList);
        assertEquals(2, feedbackList.size());
        assertTrue(feedbackList.contains(feedback1));
        assertTrue(feedbackList.contains(feedback3));
        verify(piattoRepository, times(1)).findById(testPiatto.getId());
        verify(feedbackRepository, times(1)).findByPiatto(testPiatto);
    }

    @Test
    void testGetFeedbackByPiatto_PiattoNonTrovato_ThrowsException() {
        when(piattoRepository.findById(99)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.getFeedbackByPiatto(99);
        });
        assertEquals("Piatto non trovato con ID: 99", thrown.getMessage());
        verify(piattoRepository, times(1)).findById(99);
        verify(feedbackRepository, never()).findByPiatto(any(Piatto.class));
    }

    @Test
    void testGetFeedbackByCliente_Successo() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(feedbackRepository.findByCliente(testCliente)).thenReturn(Arrays.asList(feedback1, feedback2));

        List<Feedback> feedbackList = feedbackService.getFeedbackByCliente(testCliente.getId());

        assertNotNull(feedbackList);
        assertEquals(2, feedbackList.size());
        assertTrue(feedbackList.contains(feedback1));
        assertTrue(feedbackList.contains(feedback2));
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(feedbackRepository, times(1)).findByCliente(testCliente);
    }

    @Test
    void testGetFeedbackByCliente_ClienteNonTrovato_ThrowsException() {
        when(clienteRepository.findById(99)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.getFeedbackByCliente(99);
        });
        assertEquals("Cliente non trovato con ID: 99", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(99);
        verify(feedbackRepository, never()).findByCliente(any(Cliente.class));
    }

    @Test
    void testGetFeedbackByValutazioneGreaterThanEqual_Successo() {
        when(feedbackRepository.findByValutazioneGreaterThanEqual(4)).thenReturn(Arrays.asList(feedback1, feedback2));
        List<Feedback> highRated = feedbackService.getFeedbackByValutazioneGreaterThanEqual(4);
        assertNotNull(highRated);
        assertEquals(2, highRated.size());
        assertTrue(highRated.contains(feedback1));
        assertTrue(highRated.contains(feedback2));
        verify(feedbackRepository, times(1)).findByValutazioneGreaterThanEqual(4);
    }

    @Test
    void testGetFeedbackByValutazioneGreaterThanEqual_ValutazioneNonValida_TroppoBassa_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.getFeedbackByValutazioneGreaterThanEqual(0);
        });
        assertEquals("La valutazione minima deve essere tra 1 e 5.", thrown.getMessage());
        verifyNoInteractions(feedbackRepository);
    }

    @Test
    void testAggiornaFeedback_ConPiatto_Successo() {
        Feedback updatedFeedback = new Feedback(1, testCliente, testPiatto, 4, "Pizza migliorata!");
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(piattoRepository.findById(testPiatto.getId())).thenReturn(Optional.of(testPiatto));
        when(feedbackRepository.save(updatedFeedback)).thenReturn(updatedFeedback);

        Feedback result = feedbackService.aggiornaFeedback(updatedFeedback);

        assertNotNull(result);
        assertEquals("Pizza migliorata!", result.getCommento());
        assertEquals(4, result.getValutazione());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(piattoRepository, times(1)).findById(testPiatto.getId());
        verify(feedbackRepository, times(1)).save(updatedFeedback);
    }

    @Test
    void testAggiornaFeedback_SenzaPiatto_Successo() {
        Feedback updatedFeedback = new Feedback(2, testCliente, null, 5, "Servizio eccellente!");
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(feedbackRepository.save(updatedFeedback)).thenReturn(updatedFeedback);

        Feedback result = feedbackService.aggiornaFeedback(updatedFeedback);

        assertNotNull(result);
        assertEquals("Servizio eccellente!", result.getCommento());
        assertEquals(5, result.getValutazione());
        assertNull(result.getPiatto());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(piattoRepository, never()).findById(anyInt());
        verify(feedbackRepository, times(1)).save(updatedFeedback);
    }

    @Test
    void testAggiornaFeedback_FeedbackNullo_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiornaFeedback(null);
        });
        assertEquals("Feedback non valido per l'aggiornamento.", thrown.getMessage());
        verifyNoInteractions(clienteRepository, piattoRepository, feedbackRepository);
    }

    @Test
    void testAggiornaFeedback_IdNonValido_ThrowsException() {
        Feedback invalidFeedback = new Feedback(0, testCliente, testPiatto, 5, "Commento");
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiornaFeedback(invalidFeedback);
        });
        assertEquals("Feedback non valido per l'aggiornamento.", thrown.getMessage());
        verifyNoInteractions(clienteRepository, piattoRepository, feedbackRepository);
    }

    @Test
    void testAggiornaFeedback_ValutazioneNonValida_ThrowsException() {
        Feedback invalidValuation = new Feedback(1, testCliente, testPiatto, 0, "Commento");
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiornaFeedback(invalidValuation);
        });
        assertEquals("La valutazione deve essere tra 1 e 5.", thrown.getMessage());
        verifyNoInteractions(clienteRepository, piattoRepository, feedbackRepository);
    }

    @Test
    void testAggiornaFeedback_ClienteAssociatoNonTrovato_ThrowsException() {
        Feedback updatedFeedback = new Feedback(1, new Cliente(99, "Non", "Esistente", "no@example.com"), testPiatto, 4, "Pizza migliorata!");
        when(clienteRepository.findById(99)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiornaFeedback(updatedFeedback);
        });
        assertEquals("Cliente associato non trovato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(99);
        verifyNoInteractions(piattoRepository, feedbackRepository);
    }

    @Test
    void testAggiornaFeedback_PiattoAssociatoNonTrovato_ThrowsException() {
        Feedback updatedFeedback = new Feedback(1, testCliente, new Piatto(999, "Non Esistente", "Descrizione generica", 0.0f), 4, "Pizza migliorata!");
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(piattoRepository.findById(999)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.aggiornaFeedback(updatedFeedback);
        });
        assertEquals("Piatto associato non trovato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(piattoRepository, times(1)).findById(999);
        verifyNoInteractions(feedbackRepository);
    }

    @Test
    void testEliminaFeedback_Successo() {
        doNothing().when(feedbackRepository).deleteById(feedback1.getId());
        feedbackService.eliminaFeedback(feedback1.getId());
        verify(feedbackRepository, times(1)).deleteById(feedback1.getId());
    }

    @Test
    void testEliminaFeedback_IdNonValido_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            feedbackService.eliminaFeedback(0);
        });
        assertEquals("ID feedback non valido per l'eliminazione.", thrown.getMessage());
        verifyNoInteractions(feedbackRepository);
    }
}