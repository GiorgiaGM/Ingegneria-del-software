package org.example.service;

import org.example.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class MyRestoServiceTest {

    @Mock private ClienteService clienteService;
    @Mock private PiattoService piattoService;
    @Mock private TavoloService tavoloService;
    @Mock private PrenotazioneService prenotazioneService;
    @Mock private OrdineService ordineService;
    @Mock private PagamentoService pagamentoService;
    @Mock private FeedbackService feedbackService;
    @Mock private FidelityCardService fidelityCardService;
    @Mock private PremioService premioService;
    @Mock private IngredienteService ingredienteService;
    @Mock private DipendenteService dipendenteService;
    @Mock private TurnoService turnoService;
    @Mock private RigaOrdineService rigaOrdineService;
    @Mock private VariazioneService variazioneService;
    @Mock private ReportService reportService;

    @InjectMocks
    private MyRestoService myRestoService;

    private Cliente testCliente;
    private Piatto testPiatto;
    private Tavolo testTavolo;
    private Prenotazione testPrenotazione;
    private Ordine testOrdine;
    private Ingrediente testIngrediente;
    private Dipendente testDipendente;
    private Turno testTurno;
    private RigaOrdine testRigaOrdine;
    private Variazione testVariazione;
    private FidelityCard testFidelityCard;


    @BeforeEach
    void setUp() {
        testCliente = new Cliente(1, "Marco", "Bianchi", "marco.bianchi@example.com");
        testPiatto = new Piatto(101, "Pizza Margherita", "Pomodoro, mozzarella", 8.00f, Collections.emptyList());


        testTavolo = new Tavolo(1, 4, "Libero");

        testPrenotazione = new Prenotazione("CODICE123", testCliente, LocalDate.of(2025, 7, 20),
                LocalTime.of(20, 0), 2, testTavolo, Prenotazione.STATO_ATTIVA);

        testOrdine = new Ordine(1, testCliente, testTavolo, "IN_PREPARAZIONE");
        testIngrediente = new Ingrediente(1, "Pomodoro", 0.50f);
        testDipendente = new Dipendente(1, "Giulia", "Neri", "Cameriera");
        testTurno = new Turno(1, testDipendente, LocalDate.of(2025, 7, 20), LocalTime.of(18, 0), "Sera");
        testRigaOrdine = new RigaOrdine(1, 2, testPiatto.getPrezzo(), testPiatto, Collections.emptyList(), "Senza sale", testOrdine);
        testFidelityCard = new FidelityCard(1, testCliente, 100);
        testVariazione = new Variazione(1, "Extra formaggio", 1.50f);

        reset(clienteService, piattoService, tavoloService, prenotazioneService, ordineService,
                pagamentoService, feedbackService, fidelityCardService, premioService,
                ingredienteService, dipendenteService, turnoService, rigaOrdineService,
                variazioneService, reportService);
    }

    @Test
    void testRegistraNuovoCliente() {
        String nome = "Nuovo";
        String cognome = "Cliente";
        String email = "nuovo.cliente@example.com";
        Cliente newClient = new Cliente(2, nome, cognome, email);

        when(clienteService.registraNuovoCliente(nome, cognome, email)).thenReturn(newClient);

        Cliente result = myRestoService.registraNuovoCliente(nome, cognome, email);

        assertNotNull(result);
        assertEquals(newClient, result);
        verify(clienteService, times(1)).registraNuovoCliente(nome, cognome, email);
    }

    @Test
    void testCercaClientePerId() {
        int id = testCliente.getId();
        when(clienteService.getClienteById(id)).thenReturn(Optional.of(testCliente));

        Optional<Cliente> result = myRestoService.cercaClientePerId(id);

        assertTrue(result.isPresent());
        assertEquals(testCliente, result.get());
        verify(clienteService, times(1)).getClienteById(id);
    }

    @Test
    void testGetAllClienti() {
        List<Cliente> clienti = Arrays.asList(testCliente, new Cliente(2, "Luca", "Verdi", "luca@example.com"));
        when(clienteService.getAllClienti()).thenReturn(clienti);

        List<Cliente> result = myRestoService.getAllClienti();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(2, result.size());
        verify(clienteService, times(1)).getAllClienti();
    }

    @Test
    void testCreaPiatto() {
        String nome = "Pasta al Pesto";
        String descrizione = "Pasta con pesto di basilico";
        float prezzo = 12.50f;
        List<Integer> ingredientiIds = Arrays.asList(1, 2);
        Piatto newPiatto = new Piatto(201, nome, descrizione, prezzo, Collections.emptyList());

        when(piattoService.creaPiatto(nome, descrizione, prezzo, ingredientiIds)).thenReturn(newPiatto);

        Piatto result = myRestoService.creaPiatto(nome, descrizione, prezzo, ingredientiIds);

        assertNotNull(result);
        assertEquals(newPiatto, result);
        verify(piattoService, times(1)).creaPiatto(nome, descrizione, prezzo, ingredientiIds);
    }

    @Test
    void testAggiungiNuovoIngrediente() {
        String nome = "Olio d'oliva";
        float prezzo = 0.80f;
        Ingrediente newIngrediente = new Ingrediente(2, nome, prezzo);

        when(ingredienteService.aggiungiNuovoIngrediente(nome, prezzo)).thenReturn(newIngrediente);

        Ingrediente result = myRestoService.aggiungiNuovoIngrediente(nome, prezzo);

        assertNotNull(result);
        assertEquals(newIngrediente, result);
        verify(ingredienteService, times(1)).aggiungiNuovoIngrediente(nome, prezzo);
    }

    @Test
    void testCreaTavolo() {
        int numeroTavolo = 5;
        int numPosti = 6;
        Tavolo newTavolo = new Tavolo(numeroTavolo, numPosti, Tavolo.STATO_LIBERO);

        when(tavoloService.creaTavolo(numeroTavolo, numPosti)).thenReturn(newTavolo);

        Tavolo result = myRestoService.creaTavolo(numeroTavolo, numPosti);

        assertNotNull(result);
        assertEquals(newTavolo, result);
        verify(tavoloService, times(1)).creaTavolo(numeroTavolo, numPosti);
    }

    @Test
    void testAggiornaStatoTavolo() {
        int numeroTavolo = testTavolo.getNumeroTavolo();
        String nuovoStato = Tavolo.STATO_OCCUPATO;
        Tavolo updatedTavolo = new Tavolo(numeroTavolo, testTavolo.getNumPosti(), nuovoStato);

        when(tavoloService.aggiornaStatoTavolo(numeroTavolo, nuovoStato)).thenReturn(updatedTavolo);

        Tavolo result = myRestoService.aggiornaStatoTavolo(numeroTavolo, nuovoStato);

        assertNotNull(result);
        assertEquals(updatedTavolo, result);
        verify(tavoloService, times(1)).aggiornaStatoTavolo(numeroTavolo, nuovoStato);
    }

    @Test
    void testCreaPrenotazione() {
        int clienteId = testCliente.getId();
        LocalDate data = LocalDate.of(2025, 8, 1);
        LocalTime ora = LocalTime.of(19, 30);
        int numeroPersone = 3;
        Optional<Integer> numeroTavoloAssegnato = Optional.of(testTavolo.getNumeroTavolo());
        Prenotazione newPrenotazione = new Prenotazione("NEWCODE", testCliente, data, ora, numeroPersone, testTavolo, Prenotazione.STATO_ATTIVA);

        when(prenotazioneService.creaPrenotazione(clienteId, data, ora, numeroPersone, numeroTavoloAssegnato))
                .thenReturn(newPrenotazione);

        Prenotazione result = myRestoService.creaPrenotazione(clienteId, data, ora, numeroPersone, numeroTavoloAssegnato);

        assertNotNull(result);
        assertEquals(newPrenotazione, result);
        verify(prenotazioneService, times(1)).creaPrenotazione(clienteId, data, ora, numeroPersone, numeroTavoloAssegnato);
    }

    @Test
    void testEliminaPrenotazione() {
        String codice = testPrenotazione.getCodicePrenotazione();
        doNothing().when(prenotazioneService).eliminaPrenotazione(codice);

        myRestoService.eliminaPrenotazione(codice);

        verify(prenotazioneService, times(1)).eliminaPrenotazione(codice);
    }

    @Test
    void testCreaNuovoOrdine() {
        int clienteId = testCliente.getId();
        int numeroTavolo = testTavolo.getNumeroTavolo();
        Ordine newOrdine = new Ordine(2, testCliente, testTavolo, "NUOVO");

        when(ordineService.creaNuovoOrdine(clienteId, numeroTavolo)).thenReturn(newOrdine);

        Ordine result = myRestoService.creaNuovoOrdine(clienteId, numeroTavolo);

        assertNotNull(result);
        assertEquals(newOrdine, result);
        verify(ordineService, times(1)).creaNuovoOrdine(clienteId, numeroTavolo);
    }

    @Test
    void testCalcolaTotaleOrdine() {
        int ordineId = testOrdine.getIdOrdine();
        double expectedTotal = 50.0;

        when(ordineService.calcolaTotaleOrdine(ordineId)).thenReturn(expectedTotal);

        double result = myRestoService.calcolaTotaleOrdine(ordineId);

        assertEquals(expectedTotal, result, 0.001);
        verify(ordineService, times(1)).calcolaTotaleOrdine(ordineId);
    }

    @Test
    void testAggiungiNuovoDipendente() {
        String nome = "Luca";
        String cognome = "Rossi";
        String ruolo = "Cameriere";
        Dipendente newDipendente = new Dipendente(2, nome, cognome, ruolo);

        when(dipendenteService.aggiungiNuovoDipendente(nome, cognome, ruolo)).thenReturn(newDipendente);

        Dipendente result = myRestoService.aggiungiNuovoDipendente(nome, cognome, ruolo);

        assertNotNull(result);
        assertEquals(newDipendente, result);
        verify(dipendenteService, times(1)).aggiungiNuovoDipendente(nome, cognome, ruolo);
    }

    @Test
    void testAssegnaTurno() {
        int dipendenteId = testDipendente.getId();
        LocalDate dataTurno = LocalDate.of(2025, 9, 1);
        LocalTime oraInizioTurno = LocalTime.of(9, 0);
        String tipoTurno = "Giorno";
        Turno newTurno = new Turno(2, testDipendente, dataTurno, oraInizioTurno, tipoTurno);

        when(turnoService.assegnaTurno(dipendenteId, dataTurno, oraInizioTurno, tipoTurno)).thenReturn(newTurno);

        Turno result = myRestoService.assegnaTurno(dipendenteId, dataTurno, oraInizioTurno, tipoTurno);

        assertNotNull(result);
        assertEquals(newTurno, result);
        verify(turnoService, times(1)).assegnaTurno(dipendenteId, dataTurno, oraInizioTurno, tipoTurno);
    }

    @Test
    void testAggiungiRigaOrdine() {
        int ordineId = testOrdine.getIdOrdine();
        int piattoId = testPiatto.getId();
        int quantita = 1;
        String note = "Piccante";
        List<Integer> variazioniIds = Collections.singletonList(testVariazione.getId());
        RigaOrdine newRigaOrdine = new RigaOrdine(2, quantita, testPiatto.getPrezzo(), testPiatto, Collections.singletonList(testVariazione), note, testOrdine);

        when(rigaOrdineService.creaRigaOrdine(ordineId, piattoId, quantita, note, variazioniIds)).thenReturn(newRigaOrdine);

        RigaOrdine result = myRestoService.aggiungiRigaOrdine(ordineId, piattoId, quantita, note, variazioniIds);

        assertNotNull(result);
        assertEquals(newRigaOrdine, result);
        verify(rigaOrdineService, times(1)).creaRigaOrdine(ordineId, piattoId, quantita, note, variazioniIds);
    }

    @Test
    void testCreaFidelityCardPerCliente() {
        FidelityCard newFidelityCard = new FidelityCard(2, testCliente, 0);

        when(fidelityCardService.creaFidelityCardPerCliente(testCliente.getId())).thenReturn(newFidelityCard);

        FidelityCard result = myRestoService.creaFidelityCardPerCliente(testCliente.getId());

        assertNotNull(result);
        assertEquals(newFidelityCard, result);
        assertEquals(0, result.getPuntiAccumulati());
        verify(fidelityCardService, times(1)).creaFidelityCardPerCliente(testCliente.getId());
    }

    @Test
    void testCreaVariazione_MyRestoService() {
        String tipo = "Extra olive";
        float costo = 1.00f;
        Variazione newVariazione = new Variazione(2, tipo, costo);

        when(variazioneService.creaVariazione(tipo, costo)).thenReturn(newVariazione);

        Variazione result = myRestoService.creaVariazione(tipo, costo);

        assertNotNull(result);
        assertEquals(newVariazione, result);
        verify(variazioneService, times(1)).creaVariazione(tipo, costo);
    }
}