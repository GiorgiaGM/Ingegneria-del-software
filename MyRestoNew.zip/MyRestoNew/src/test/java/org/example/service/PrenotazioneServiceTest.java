package org.example.service;

import org.example.model.Cliente;
import org.example.model.Prenotazione;
import org.example.model.Tavolo;
import org.example.repository.ClienteRepository;
import org.example.repository.PrenotazioneRepository;
import org.example.repository.TavoloRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PrenotazioneServiceTest {

    @Mock
    private PrenotazioneRepository prenotazioneRepository;
    @Mock
    private ClienteRepository clienteRepository;
    @Mock
    private TavoloRepository tavoloRepository;

    @InjectMocks
    private PrenotazioneService prenotazioneService;
    private Cliente testCliente;
    private Tavolo testTavoloLibero;
    private Tavolo testTavoloOccupato;
    private Tavolo testTavoloRiservato;
    private Prenotazione testPrenotazioneAttiva;

    @BeforeEach
    void setUp() {
        testCliente = new Cliente(1, "Luca", "Bianchi", "luca.bianchi@example.com");

        testTavoloLibero = new Tavolo(101, 4, Tavolo.STATO_LIBERO);
        testTavoloOccupato = new Tavolo(102, 2, Tavolo.STATO_OCCUPATO);
        testTavoloRiservato = new Tavolo(103, 6, Tavolo.STATO_RISERVATO);

        testPrenotazioneAttiva = new Prenotazione(
                "PREN001",
                testCliente,
                LocalDate.now().plusDays(1),
                LocalTime.of(20, 0),
                4,
                testTavoloLibero,
                Prenotazione.STATO_ATTIVA
        );
        reset(prenotazioneRepository, clienteRepository, tavoloRepository);
    }

    @Test
    void testCreaPrenotazione_Successo_TavoloAssegnato() {
        LocalDate data = LocalDate.now().plusDays(2);
        LocalTime ora = LocalTime.of(19, 30);
        int numeroPersone = 4;
        int numeroTavolo = testTavoloLibero.getNumeroTavolo();
        String nextCodicePrenotazione = "NEW_PREN002";

        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(numeroTavolo)).thenReturn(Optional.of(testTavoloLibero));
        when(prenotazioneRepository.findByDataOraTavolo(data, ora, testTavoloLibero)).thenReturn(Optional.empty());
        when(prenotazioneRepository.getNextId()).thenReturn(nextCodicePrenotazione);
        when(prenotazioneRepository.save(any(Prenotazione.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(tavoloRepository.save(any(Tavolo.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Prenotazione result = prenotazioneService.creaPrenotazione(testCliente.getId(), data, ora, numeroPersone, Optional.of(numeroTavolo));

        assertNotNull(result);
        assertEquals(nextCodicePrenotazione, result.getCodicePrenotazione());
        assertEquals(testCliente, result.getCliente());
        assertEquals(data, result.getData());
        assertEquals(ora, result.getOra());
        assertEquals(numeroPersone, result.getNumeroPersone());
        assertEquals(testTavoloLibero, result.getTavoloAssegnato());
        assertEquals(Prenotazione.STATO_ATTIVA, result.getStatoPrenotazione());
        assertEquals(Tavolo.STATO_RISERVATO, testTavoloLibero.getStato());

        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavolo);
        verify(prenotazioneRepository, times(1)).findByDataOraTavolo(data, ora, testTavoloLibero);
        verify(prenotazioneRepository, times(1)).getNextId();
        verify(prenotazioneRepository, times(1)).save(any(Prenotazione.class));
        verify(tavoloRepository, times(1)).save(testTavoloLibero);
    }

    @Test
    void testCreaPrenotazione_Successo_TavoloAutomatico() {
        LocalDate data = LocalDate.now().plusDays(2);
        LocalTime ora = LocalTime.of(19, 30);
        int numeroPersone = 3;
        String nextCodicePrenotazione = "NEW_PREN003";
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByStato(Tavolo.STATO_LIBERO)).thenReturn(Collections.singletonList(testTavoloLibero));
        when(prenotazioneRepository.findByDataOraTavolo(data, ora, testTavoloLibero)).thenReturn(Optional.empty());
        when(prenotazioneRepository.getNextId()).thenReturn(nextCodicePrenotazione);
        when(prenotazioneRepository.save(any(Prenotazione.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(tavoloRepository.save(any(Tavolo.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Prenotazione result = prenotazioneService.creaPrenotazione(testCliente.getId(), data, ora, numeroPersone, Optional.empty());

        assertNotNull(result);
        assertEquals(nextCodicePrenotazione, result.getCodicePrenotazione());
        assertEquals(testTavoloLibero, result.getTavoloAssegnato());
        assertEquals(Tavolo.STATO_RISERVATO, testTavoloLibero.getStato());

        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByStato(Tavolo.STATO_LIBERO);
        verify(prenotazioneRepository, times(1)).findByDataOraTavolo(data, ora, testTavoloLibero);
        verify(prenotazioneRepository, times(1)).getNextId();
        verify(prenotazioneRepository, times(1)).save(any(Prenotazione.class));
        verify(tavoloRepository, times(1)).save(testTavoloLibero);
    }

    @Test
    void testCreaPrenotazione_ClienteNonTrovato_ThrowsException() {
        LocalDate data = LocalDate.now().plusDays(1);
        LocalTime ora = LocalTime.of(19, 0);
        int clienteId = 999;

        when(clienteRepository.findById(clienteId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                prenotazioneService.creaPrenotazione(clienteId, data, ora, 2, Optional.empty()));

        assertEquals("Cliente non trovato con ID: " + clienteId, thrown.getMessage());
        verify(clienteRepository, times(1)).findById(clienteId);
        verifyNoInteractions(prenotazioneRepository, tavoloRepository);
    }

    @Test
    void testCreaPrenotazione_DataPassata_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                        prenotazioneService.creaPrenotazione(testCliente.getId(), LocalDate.now().minusDays(1), LocalTime.now(), 2, Optional.empty()),
                "Impossibile creare una prenotazione nel passato.");
        assertThrows(IllegalArgumentException.class, () ->
                        prenotazioneService.creaPrenotazione(testCliente.getId(), LocalDate.now(), LocalTime.now().minusMinutes(1), 2, Optional.empty()),
                "Impossibile creare una prenotazione nel passato.");
        verifyNoInteractions(clienteRepository, prenotazioneRepository, tavoloRepository);
    }

    @Test
    void testCreaPrenotazione_DatiNonValidi_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                        prenotazioneService.creaPrenotazione(testCliente.getId(), null, LocalTime.now(), 2, Optional.empty()),
                "Data, ora o numero di persone non validi.");
        assertThrows(IllegalArgumentException.class, () ->
                        prenotazioneService.creaPrenotazione(testCliente.getId(), LocalDate.now(), null, 2, Optional.empty()),
                "Data, ora o numero di persone non validi.");
        assertThrows(IllegalArgumentException.class, () ->
                        prenotazioneService.creaPrenotazione(testCliente.getId(), LocalDate.now(), LocalTime.now(), 0, Optional.empty()),
                "Data, ora o numero di persone non validi.");
        verifyNoInteractions(clienteRepository, prenotazioneRepository, tavoloRepository);
    }

    @Test
    void testCreaPrenotazione_TavoloAssegnato_NonTrovato_ThrowsException() {
        LocalDate data = LocalDate.now().plusDays(1);
        LocalTime ora = LocalTime.of(19, 0);
        int numeroTavolo = 999;

        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(numeroTavolo)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                prenotazioneService.creaPrenotazione(testCliente.getId(), data, ora, 2, Optional.of(numeroTavolo)));

        assertEquals("Tavolo non trovato con numero: " + numeroTavolo, thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavolo);
        verifyNoInteractions(prenotazioneRepository);
    }

    @Test
    void testCreaPrenotazione_TavoloAssegnato_GiaPrenotato_ThrowsException() {
        LocalDate data = LocalDate.now().plusDays(1);
        LocalTime ora = LocalTime.of(19, 0);
        int numeroTavolo = testTavoloLibero.getNumeroTavolo();

        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(numeroTavolo)).thenReturn(Optional.of(testTavoloLibero));
        when(prenotazioneRepository.findByDataOraTavolo(data, ora, testTavoloLibero)).thenReturn(Optional.of(testPrenotazioneAttiva));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () ->
                prenotazioneService.creaPrenotazione(testCliente.getId(), data, ora, 2, Optional.of(numeroTavolo)));

        assertEquals("Il tavolo " + numeroTavolo + " non è disponibile per l'orario richiesto o è già occupato/riservato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavolo);
        verify(prenotazioneRepository, times(1)).findByDataOraTavolo(data, ora, testTavoloLibero);
        verifyNoMoreInteractions(prenotazioneRepository, tavoloRepository);
    }

    @Test
    void testCreaPrenotazione_TavoloAssegnato_GiaOccupato_ThrowsException() {
        LocalDate data = LocalDate.now().plusDays(1);
        LocalTime ora = LocalTime.of(19, 0);
        int numeroTavolo = testTavoloOccupato.getNumeroTavolo();

        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(numeroTavolo)).thenReturn(Optional.of(testTavoloOccupato));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () ->
                prenotazioneService.creaPrenotazione(testCliente.getId(), data, ora, 2, Optional.of(numeroTavolo)));

        assertEquals("Il tavolo " + numeroTavolo + " non è disponibile per l'orario richiesto o è già occupato/riservato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavolo);
        verify(prenotazioneRepository, times(1)).findByDataOraTavolo(data, ora, testTavoloOccupato);
        verifyNoMoreInteractions(prenotazioneRepository);
    }

    @Test
    void testCreaPrenotazione_TavoloAssegnato_GiaRiservato_ThrowsException() {
        LocalDate data = LocalDate.now().plusDays(1);
        LocalTime ora = LocalTime.of(19, 0);
        int numeroTavolo = testTavoloRiservato.getNumeroTavolo();

        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(numeroTavolo)).thenReturn(Optional.of(testTavoloRiservato));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () ->
                prenotazioneService.creaPrenotazione(testCliente.getId(), data, ora, 2, Optional.of(numeroTavolo)));

        assertEquals("Il tavolo " + numeroTavolo + " non è disponibile per l'orario richiesto o è già occupato/riservato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavolo);
        verify(prenotazioneRepository, times(1)).findByDataOraTavolo(data, ora, testTavoloRiservato);
        verifyNoMoreInteractions(prenotazioneRepository);
    }

    @Test
    void testCreaPrenotazione_NessunTavoloDisponibileAutomatico_ThrowsException() {
        LocalDate data = LocalDate.now().plusDays(1);
        LocalTime ora = LocalTime.of(19, 0);
        int numeroPersone = 8;
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByStato(Tavolo.STATO_LIBERO)).thenReturn(Collections.singletonList(testTavoloLibero));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () ->
                prenotazioneService.creaPrenotazione(testCliente.getId(), data, ora, numeroPersone, Optional.empty()));

        assertEquals("Nessun tavolo disponibile per " + numeroPersone + " persone all'orario specificato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByStato(Tavolo.STATO_LIBERO);
        verify(prenotazioneRepository, never()).save(any(Prenotazione.class));
        verify(tavoloRepository, never()).save(any(Tavolo.class));
    }

    @Test
    void testGetPrenotazioneByCodice_Esistente() {
        when(prenotazioneRepository.findById(testPrenotazioneAttiva.getCodicePrenotazione())).thenReturn(Optional.of(testPrenotazioneAttiva));

        Optional<Prenotazione> found = prenotazioneService.getPrenotazioneByCodice(testPrenotazioneAttiva.getCodicePrenotazione());

        assertTrue(found.isPresent());
        assertEquals(testPrenotazioneAttiva, found.get());
        verify(prenotazioneRepository, times(1)).findById(testPrenotazioneAttiva.getCodicePrenotazione());
    }

    @Test
    void testGetPrenotazioneByCodice_NonEsistente() {
        when(prenotazioneRepository.findById("UNKNOWN")).thenReturn(Optional.empty());

        Optional<Prenotazione> found = prenotazioneService.getPrenotazioneByCodice("UNKNOWN");

        assertFalse(found.isPresent());
        verify(prenotazioneRepository, times(1)).findById("UNKNOWN");
    }

    @Test
    void testGetAllPrenotazioni_Successo() {
        List<Prenotazione> allBookings = Arrays.asList(testPrenotazioneAttiva);
        when(prenotazioneRepository.findAll()).thenReturn(allBookings);

        List<Prenotazione> result = prenotazioneService.getAllPrenotazioni();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertTrue(result.contains(testPrenotazioneAttiva));
        verify(prenotazioneRepository, times(1)).findAll();
    }

    @Test
    void testGetAllPrenotazioni_ListaVuota() {
        when(prenotazioneRepository.findAll()).thenReturn(Collections.emptyList());

        List<Prenotazione> result = prenotazioneService.getAllPrenotazioni();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(prenotazioneRepository, times(1)).findAll();
    }

    @Test
    void testGetPrenotazioniPerData_Successo() {
        LocalDate searchDate = LocalDate.now().plusDays(1);
        List<Prenotazione> bookingsForDate = Collections.singletonList(testPrenotazioneAttiva);
        when(prenotazioneRepository.findByData(searchDate)).thenReturn(bookingsForDate);

        List<Prenotazione> result = prenotazioneService.getPrenotazioniPerData(searchDate);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertTrue(result.contains(testPrenotazioneAttiva));
        verify(prenotazioneRepository, times(1)).findByData(searchDate);
    }

    @Test
    void testGetPrenotazioniPerData_NessunaPrenotazione() {
        LocalDate searchDate = LocalDate.now().plusDays(5);
        when(prenotazioneRepository.findByData(searchDate)).thenReturn(Collections.emptyList());

        List<Prenotazione> result = prenotazioneService.getPrenotazioniPerData(searchDate);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(prenotazioneRepository, times(1)).findByData(searchDate);
    }

    @Test
    void testGetPrenotazioniPerCliente_Successo() {
        List<Prenotazione> bookingsForCliente = Collections.singletonList(testPrenotazioneAttiva);

        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(prenotazioneRepository.findByCliente(testCliente)).thenReturn(bookingsForCliente);

        List<Prenotazione> result = prenotazioneService.getPrenotazioniPerCliente(testCliente.getId());

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertTrue(result.contains(testPrenotazioneAttiva));
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(prenotazioneRepository, times(1)).findByCliente(testCliente);
    }

    @Test
    void testGetPrenotazioniPerCliente_ClienteNonTrovato_ThrowsException() {
        int clienteId = 999;
        when(clienteRepository.findById(clienteId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                prenotazioneService.getPrenotazioniPerCliente(clienteId));

        assertEquals("Cliente non trovato con ID: " + clienteId, thrown.getMessage());
        verify(clienteRepository, times(1)).findById(clienteId);
        verifyNoInteractions(prenotazioneRepository);
    }

    @Test
    void testGetPrenotazioniPerCliente_NessunaPrenotazione() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(prenotazioneRepository.findByCliente(testCliente)).thenReturn(Collections.emptyList());

        List<Prenotazione> result = prenotazioneService.getPrenotazioniPerCliente(testCliente.getId());

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(prenotazioneRepository, times(1)).findByCliente(testCliente);
    }

    @Test
    void testAggiornaPrenotazione_Successo() {
        Prenotazione prenotazioneAggiornata = new Prenotazione(
                testPrenotazioneAttiva.getCodicePrenotazione(),
                testCliente,
                testPrenotazioneAttiva.getData(),
                testPrenotazioneAttiva.getOra().plusHours(1),
                5,
                testTavoloLibero,
                Prenotazione.STATO_ARRIVATO
        );

        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(testTavoloLibero.getNumeroTavolo())).thenReturn(Optional.of(testTavoloLibero));
        when(prenotazioneRepository.save(any(Prenotazione.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Prenotazione result = prenotazioneService.aggiornaPrenotazione(prenotazioneAggiornata);

        assertNotNull(result);
        assertEquals(prenotazioneAggiornata.getOra(), result.getOra());
        assertEquals(prenotazioneAggiornata.getNumeroPersone(), result.getNumeroPersone());
        assertEquals(Prenotazione.STATO_ARRIVATO, result.getStatoPrenotazione());

        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(testTavoloLibero.getNumeroTavolo());
        verify(prenotazioneRepository, times(1)).save(prenotazioneAggiornata);
    }

    @Test
    void testAggiornaPrenotazione_PrenotazioneNullaOIdNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                prenotazioneService.aggiornaPrenotazione(null), "Prenotazione non valida per l'aggiornamento (codice prenotazione mancante).");
        assertThrows(IllegalArgumentException.class, () ->
                        prenotazioneService.aggiornaPrenotazione(new Prenotazione(null, testCliente, LocalDate.now(), LocalTime.now(), 2, null, Prenotazione.STATO_ATTIVA)),
                "Prenotazione non valida per l'aggiornamento (codice prenotazione mancante).");
        assertThrows(IllegalArgumentException.class, () ->
                        prenotazioneService.aggiornaPrenotazione(new Prenotazione("", testCliente, LocalDate.now(), LocalTime.now(), 2, null, Prenotazione.STATO_ATTIVA)),
                "Prenotazione non valida per l'aggiornamento (codice prenotazione mancante).");
        verifyNoInteractions(clienteRepository, tavoloRepository, prenotazioneRepository);
    }

    @Test
    void testAggiornaPrenotazione_ClienteAssociatoNonTrovato_ThrowsException() {
        Prenotazione prenotazioneConClienteInesistente = new Prenotazione(
                "PREN002",
                new Cliente(999, "Fake", "Client", "fake@example.com"),
                LocalDate.now().plusDays(1),
                LocalTime.of(20, 0),
                2,
                testTavoloLibero,
                Prenotazione.STATO_ATTIVA
        );

        when(clienteRepository.findById(prenotazioneConClienteInesistente.getCliente().getId())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                prenotazioneService.aggiornaPrenotazione(prenotazioneConClienteInesistente));

        assertEquals("Cliente associato non trovato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(prenotazioneConClienteInesistente.getCliente().getId());
        verifyNoInteractions(tavoloRepository, prenotazioneRepository);
    }

    @Test
    void testAggiornaPrenotazione_TavoloAssociatoNonTrovato_ThrowsException() {
        Prenotazione prenotazioneConTavoloInesistente = new Prenotazione(
                "PREN003",
                testCliente,
                LocalDate.now().plusDays(1),
                LocalTime.of(20, 0),
                2,
                new Tavolo(999, 4, Tavolo.STATO_LIBERO),
                Prenotazione.STATO_ATTIVA
        );

        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(prenotazioneConTavoloInesistente.getTavoloAssegnato().getNumeroTavolo())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                prenotazioneService.aggiornaPrenotazione(prenotazioneConTavoloInesistente));

        assertEquals("Tavolo associato non trovato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(prenotazioneConTavoloInesistente.getTavoloAssegnato().getNumeroTavolo());
        verifyNoInteractions(prenotazioneRepository);
    }

    @Test
    void testEliminaPrenotazione_Successo_LiberaTavolo() {
        String codiceToDelete = testPrenotazioneAttiva.getCodicePrenotazione();
        Tavolo tavoloDellaPrenotazione = testPrenotazioneAttiva.getTavoloAssegnato();
        tavoloDellaPrenotazione.setStato(Tavolo.STATO_RISERVATO);

        when(prenotazioneRepository.findById(codiceToDelete)).thenReturn(Optional.of(testPrenotazioneAttiva));
        when(prenotazioneRepository.findByDataOraTavolo(testPrenotazioneAttiva.getData(), testPrenotazioneAttiva.getOra(), tavoloDellaPrenotazione))
                .thenReturn(Optional.of(testPrenotazioneAttiva));
        doNothing().when(prenotazioneRepository).deleteById(codiceToDelete);
        when(tavoloRepository.save(any(Tavolo.class))).thenAnswer(invocation -> invocation.getArgument(0));

        prenotazioneService.eliminaPrenotazione(codiceToDelete);
        assertEquals(Tavolo.STATO_LIBERO, tavoloDellaPrenotazione.getStato());

        verify(prenotazioneRepository, times(1)).findById(codiceToDelete);
        verify(prenotazioneRepository, times(1)).findByDataOraTavolo(testPrenotazioneAttiva.getData(), testPrenotazioneAttiva.getOra(), tavoloDellaPrenotazione);
        verify(tavoloRepository, times(1)).save(tavoloDellaPrenotazione);
        verify(prenotazioneRepository, times(1)).deleteById(codiceToDelete);
    }

    @Test
    void testEliminaPrenotazione_Successo_NonLiberaTavoloSeOccupato() {
        String codiceToDelete = testPrenotazioneAttiva.getCodicePrenotazione();
        Tavolo tavoloDellaPrenotazione = testPrenotazioneAttiva.getTavoloAssegnato();
        tavoloDellaPrenotazione.setStato(Tavolo.STATO_OCCUPATO);

        when(prenotazioneRepository.findById(codiceToDelete)).thenReturn(Optional.of(testPrenotazioneAttiva));
        when(prenotazioneRepository.findByDataOraTavolo(testPrenotazioneAttiva.getData(), testPrenotazioneAttiva.getOra(), tavoloDellaPrenotazione))
                .thenReturn(Optional.of(testPrenotazioneAttiva));
        doNothing().when(prenotazioneRepository).deleteById(codiceToDelete);

        prenotazioneService.eliminaPrenotazione(codiceToDelete);
        assertEquals(Tavolo.STATO_OCCUPATO, tavoloDellaPrenotazione.getStato());

        verify(prenotazioneRepository, times(1)).findById(codiceToDelete);
        verify(prenotazioneRepository, times(1)).findByDataOraTavolo(testPrenotazioneAttiva.getData(), testPrenotazioneAttiva.getOra(), tavoloDellaPrenotazione);
        verify(tavoloRepository, never()).save(any(Tavolo.class));
        verify(prenotazioneRepository, times(1)).deleteById(codiceToDelete);
    }

    @Test
    void testEliminaPrenotazione_CodiceNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                prenotazioneService.eliminaPrenotazione(null), "Codice prenotazione non valido per l'eliminazione.");
        assertThrows(IllegalArgumentException.class, () ->
                prenotazioneService.eliminaPrenotazione(""), "Codice prenotazione non valido per l'eliminazione.");
        assertThrows(IllegalArgumentException.class, () ->
                prenotazioneService.eliminaPrenotazione("   "), "Codice prenotazione non valido per l'eliminazione.");
        verifyNoInteractions(prenotazioneRepository, tavoloRepository);
    }

    @Test
    void testEliminaPrenotazione_PrenotazioneNonTrovata_SoloEliminazione() {
        String codiceNonEsistente = "NON_ESISTE";
        when(prenotazioneRepository.findById(codiceNonEsistente)).thenReturn(Optional.empty());
        doNothing().when(prenotazioneRepository).deleteById(codiceNonEsistente);

        prenotazioneService.eliminaPrenotazione(codiceNonEsistente);

        verify(prenotazioneRepository, times(1)).findById(codiceNonEsistente);
        verify(prenotazioneRepository, times(1)).deleteById(codiceNonEsistente);
        verifyNoInteractions(tavoloRepository);
    }
}