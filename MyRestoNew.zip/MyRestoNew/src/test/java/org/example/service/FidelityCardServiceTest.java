package org.example.service;

import org.example.model.Cliente;
import org.example.model.FidelityCard;
import org.example.repository.ClienteRepository;
import org.example.repository.FidelityCardRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class FidelityCardServiceTest {

    @Mock
    private FidelityCardRepository fidelityCardRepository;
    @Mock
    private ClienteRepository clienteRepository;

    @InjectMocks
    private FidelityCardService fidelityCardService;

    private Cliente testCliente;
    private FidelityCard testFidelityCard;

    @BeforeEach
    void setUp() {
        testCliente = new Cliente(1, "Mario", "Rossi", "mario.rossi@example.com");
        testFidelityCard = new FidelityCard(101, testCliente, 50);
        reset(fidelityCardRepository, clienteRepository);
    }

    @Test
    void testCreaFidelityCardPerCliente_Successo() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(fidelityCardRepository.findByClienteId(testCliente.getId())).thenReturn(Optional.empty());
        when(fidelityCardRepository.getNextId()).thenReturn(101);
        when(fidelityCardRepository.save(any(FidelityCard.class))).thenAnswer(invocation -> {
            FidelityCard card = invocation.getArgument(0);
            assertEquals(101, card.getIdCard());
            return card;
        });

        FidelityCard createdCard = fidelityCardService.creaFidelityCardPerCliente(testCliente.getId());

        assertNotNull(createdCard);
        assertEquals(testCliente.getId(), createdCard.getCliente().getId());
        assertEquals(0, createdCard.getPuntiAccumulati());
        assertEquals(101, createdCard.getIdCard());

        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(fidelityCardRepository, times(1)).findByClienteId(testCliente.getId());
        verify(fidelityCardRepository, times(1)).getNextId();
        verify(fidelityCardRepository, times(1)).save(any(FidelityCard.class));
    }

    @Test
    void testCreaFidelityCardPerCliente_ClienteNonTrovato_ThrowsException() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.creaFidelityCardPerCliente(testCliente.getId()));

        assertEquals("Cliente non trovato con ID: " + testCliente.getId(), thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verifyNoInteractions(fidelityCardRepository);
    }

    @Test
    void testCreaFidelityCardPerCliente_ClienteHaGiaCard_ThrowsException() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(fidelityCardRepository.findByClienteId(testCliente.getId())).thenReturn(Optional.of(testFidelityCard));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.creaFidelityCardPerCliente(testCliente.getId()));

        assertEquals("Il cliente " + testCliente.getNome() + " ha già una Fidelity Card.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(fidelityCardRepository, times(1)).findByClienteId(testCliente.getId());
        verify(fidelityCardRepository, never()).save(any(FidelityCard.class));
    }

    @Test
    void testGetFidelityCardById_Successo() {
        when(fidelityCardRepository.findById(testFidelityCard.getIdCard())).thenReturn(Optional.of(testFidelityCard));

        Optional<FidelityCard> foundCard = fidelityCardService.getFidelityCardById(testFidelityCard.getIdCard());

        assertTrue(foundCard.isPresent());
        assertEquals(testFidelityCard.getIdCard(), foundCard.get().getIdCard());
        verify(fidelityCardRepository, times(1)).findById(testFidelityCard.getIdCard());
    }

    @Test
    void testGetFidelityCardById_NonTrovata_ReturnsEmptyOptional() {
        when(fidelityCardRepository.findById(999)).thenReturn(Optional.empty());

        Optional<FidelityCard> foundCard = fidelityCardService.getFidelityCardById(999);

        assertFalse(foundCard.isPresent());
        verify(fidelityCardRepository, times(1)).findById(999);
    }

    @Test
    void testGetFidelityCardByCliente_Successo() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(fidelityCardRepository.findByClienteId(testCliente.getId())).thenReturn(Optional.of(testFidelityCard));

        Optional<FidelityCard> foundCard = fidelityCardService.getFidelityCardByCliente(testCliente.getId());

        assertTrue(foundCard.isPresent());
        assertEquals(testFidelityCard.getIdCard(), foundCard.get().getIdCard());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(fidelityCardRepository, times(1)).findByClienteId(testCliente.getId());
    }

    @Test
    void testGetFidelityCardByCliente_ClienteNonTrovato_ThrowsException() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.getFidelityCardByCliente(testCliente.getId()));

        assertEquals("Cliente non trovato con ID: " + testCliente.getId(), thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verifyNoInteractions(fidelityCardRepository);
    }

    @Test
    void testGetFidelityCardByCliente_NessunaCardPerCliente_ReturnsEmptyOptional() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(fidelityCardRepository.findByClienteId(testCliente.getId())).thenReturn(Optional.empty());

        Optional<FidelityCard> foundCard = fidelityCardService.getFidelityCardByCliente(testCliente.getId());

        assertFalse(foundCard.isPresent());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(fidelityCardRepository, times(1)).findByClienteId(testCliente.getId());
    }

    @Test
    void testGetAllFidelityCards_ListaNonVuota() {
        when(fidelityCardRepository.findAll()).thenReturn(Arrays.asList(testFidelityCard, new FidelityCard(102, new Cliente(2, "Giovanna", "Bianchi", "gio@example.com"), 10)));

        List<FidelityCard> allCards = fidelityCardService.getAllFidelityCards();

        assertNotNull(allCards);
        assertEquals(2, allCards.size());
        assertTrue(allCards.contains(testFidelityCard));
        verify(fidelityCardRepository, times(1)).findAll();
    }

    @Test
    void testGetAllFidelityCards_ListaVuota() {
        when(fidelityCardRepository.findAll()).thenReturn(Collections.emptyList());

        List<FidelityCard> allCards = fidelityCardService.getAllFidelityCards();

        assertNotNull(allCards);
        assertTrue(allCards.isEmpty());
        verify(fidelityCardRepository, times(1)).findAll();
    }

    @Test
    void testAggiungiPunti_Successo() {
        int puntiDaAggiungere = 20;
        FidelityCard cardAfterAdd = new FidelityCard(testFidelityCard.getIdCard(), testCliente, testFidelityCard.getPuntiAccumulati() + puntiDaAggiungere);

        when(fidelityCardRepository.findById(testFidelityCard.getIdCard())).thenReturn(Optional.of(testFidelityCard));
        when(fidelityCardRepository.save(any(FidelityCard.class))).thenReturn(cardAfterAdd);

        FidelityCard updatedCard = fidelityCardService.aggiungiPunti(testFidelityCard.getIdCard(), puntiDaAggiungere);

        assertNotNull(updatedCard);
        assertEquals(70, updatedCard.getPuntiAccumulati());
        verify(fidelityCardRepository, times(1)).findById(testFidelityCard.getIdCard());
        verify(fidelityCardRepository, times(1)).save(testFidelityCard);
    }

    @Test
    void testAggiungiPunti_FidelityCardNonTrovata_ThrowsException() {
        int puntiDaAggiungere = 20;
        when(fidelityCardRepository.findById(testFidelityCard.getIdCard())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.aggiungiPunti(testFidelityCard.getIdCard(), puntiDaAggiungere));

        assertEquals("Fidelity Card non trovata con ID: " + testFidelityCard.getIdCard(), thrown.getMessage());
        verify(fidelityCardRepository, times(1)).findById(testFidelityCard.getIdCard());
        verify(fidelityCardRepository, never()).save(any(FidelityCard.class));
    }

    @Test
    void testAggiungiPunti_PuntiNonValidi_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.aggiungiPunti(testFidelityCard.getIdCard(), 0), "I punti da aggiungere devono essere positivi.");
        assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.aggiungiPunti(testFidelityCard.getIdCard(), -10), "I punti da aggiungere devono essere positivi.");
        verifyNoInteractions(fidelityCardRepository);
    }

    @Test
    void testRimuoviPunti_Successo() {
        int puntiDaRimuovere = 20;
        FidelityCard cardAfterRemove = new FidelityCard(testFidelityCard.getIdCard(), testCliente, testFidelityCard.getPuntiAccumulati() - puntiDaRimuovere);

        when(fidelityCardRepository.findById(testFidelityCard.getIdCard())).thenReturn(Optional.of(testFidelityCard));
        when(fidelityCardRepository.save(any(FidelityCard.class))).thenReturn(cardAfterRemove);

        FidelityCard updatedCard = fidelityCardService.rimuoviPunti(testFidelityCard.getIdCard(), puntiDaRimuovere);

        assertNotNull(updatedCard);
        assertEquals(30, updatedCard.getPuntiAccumulati());
        verify(fidelityCardRepository, times(1)).findById(testFidelityCard.getIdCard());
        verify(fidelityCardRepository, times(1)).save(testFidelityCard);
    }

    @Test
    void testRimuoviPunti_FidelityCardNonTrovata_ThrowsException() {
        int puntiDaRimuovere = 20;
        when(fidelityCardRepository.findById(testFidelityCard.getIdCard())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.rimuoviPunti(testFidelityCard.getIdCard(), puntiDaRimuovere));

        assertEquals("Fidelity Card non trovata con ID: " + testFidelityCard.getIdCard(), thrown.getMessage());
        verify(fidelityCardRepository, times(1)).findById(testFidelityCard.getIdCard());
        verify(fidelityCardRepository, never()).save(any(FidelityCard.class));
    }

    @Test
    void testRimuoviPunti_PuntiNonValidi_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.rimuoviPunti(testFidelityCard.getIdCard(), 0), "I punti da rimuovere devono essere positivi.");
        assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.rimuoviPunti(testFidelityCard.getIdCard(), -10), "I punti da rimuovere devono essere positivi.");
        verifyNoInteractions(fidelityCardRepository);
    }

    @Test
    void testRimuoviPunti_PuntiInsufficienti_ThrowsException() {
        int puntiDaRimuovere = 100;
        when(fidelityCardRepository.findById(testFidelityCard.getIdCard())).thenReturn(Optional.of(testFidelityCard));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.rimuoviPunti(testFidelityCard.getIdCard(), puntiDaRimuovere));

        assertEquals("Non ci sono abbastanza punti sulla card per questa operazione.", thrown.getMessage());
        verify(fidelityCardRepository, times(1)).findById(testFidelityCard.getIdCard());
        verify(fidelityCardRepository, never()).save(any(FidelityCard.class));
    }

    @Test
    void testAggiornaFidelityCard_Successo() {
        FidelityCard updatedCard = new FidelityCard(testFidelityCard.getIdCard(), testCliente, 75);
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(fidelityCardRepository.save(updatedCard)).thenReturn(updatedCard);

        FidelityCard result = fidelityCardService.aggiornaFidelityCard(updatedCard);

        assertNotNull(result);
        assertEquals(75, result.getPuntiAccumulati());
        verify(fidelityCardRepository, times(1)).save(updatedCard);
        verify(clienteRepository, times(1)).findById(testCliente.getId());
    }

    @Test
    void testAggiornaFidelityCard_CardNullaOIdNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.aggiornaFidelityCard(null), "Fidelity Card non valida per l'aggiornamento.");
        assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.aggiornaFidelityCard(new FidelityCard(0, testCliente, 10)), "Fidelity Card non valida per l'aggiornamento.");
        verifyNoInteractions(fidelityCardRepository);
        verifyNoInteractions(clienteRepository);
    }

    @Test
    void testAggiornaFidelityCard_ClienteAssociatoNonTrovato_ThrowsException() {
        FidelityCard cardWithMissingClient = new FidelityCard(testFidelityCard.getIdCard(), new Cliente(999, "Fake", "Client", "fake@example.com"), 75);
        when(clienteRepository.findById(cardWithMissingClient.getCliente().getId())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.aggiornaFidelityCard(cardWithMissingClient));

        assertEquals("Cliente associato non trovato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(cardWithMissingClient.getCliente().getId());
        verifyNoInteractions(fidelityCardRepository);
    }


    @Test
    void testEliminaFidelityCard_Successo() {
        int idCardToDelete = testFidelityCard.getIdCard();
        doNothing().when(fidelityCardRepository).deleteById(idCardToDelete);

        fidelityCardService.eliminaFidelityCard(idCardToDelete);

        verify(fidelityCardRepository, times(1)).deleteById(idCardToDelete);
    }

    @Test
    void testEliminaFidelityCard_IdNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.eliminaFidelityCard(0), "ID Fidelity Card non valido per l'eliminazione.");
        assertThrows(IllegalArgumentException.class, () ->
                fidelityCardService.eliminaFidelityCard(-5), "ID Fidelity Card non valido per l'eliminazione.");
        verifyNoInteractions(fidelityCardRepository);
    }
}