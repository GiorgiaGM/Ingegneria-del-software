package org.example.service;

import org.example.model.Ingrediente;
import org.example.repository.IngredienteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class IngredienteServiceTest {

    @Mock
    private IngredienteRepository ingredienteRepository;

    @InjectMocks
    private IngredienteService ingredienteService;
    private Ingrediente ingrediente1;
    private Ingrediente ingrediente2;

    @BeforeEach
    void setUp() {
        ingrediente1 = new Ingrediente(1, "Pomodoro", 1.50f);
        ingrediente2 = new Ingrediente(2, "Mozzarella", 2.00f);
    }

    @Test
    void testAggiungiNuovoIngrediente_Successo() {
        when(ingredienteRepository.findByNome("Basilico")).thenReturn(Optional.empty());
        when(ingredienteRepository.getNextId()).thenReturn(3);
        when(ingredienteRepository.save(any(Ingrediente.class))).thenAnswer(invocation -> {
            Ingrediente ing = invocation.getArgument(0);
            assertEquals(3, ing.getId());
            return ing;
        });

        Ingrediente newIngrediente = ingredienteService.aggiungiNuovoIngrediente("Basilico", 0.80f);

        assertNotNull(newIngrediente);
        assertEquals("Basilico", newIngrediente.getNome());
        assertEquals(0.80f, newIngrediente.getPrezzo());
        assertEquals(3, newIngrediente.getId());

        verify(ingredienteRepository, times(1)).findByNome("Basilico");
        verify(ingredienteRepository, times(1)).getNextId();
        verify(ingredienteRepository, times(1)).save(any(Ingrediente.class));
    }

    @Test
    void testAggiungiNuovoIngrediente_NomeVuoto_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ingredienteService.aggiungiNuovoIngrediente("", 1.00f);
        });
        assertEquals("Il nome dell'ingrediente non può essere vuoto.", thrown.getMessage());
        verifyNoInteractions(ingredienteRepository);
    }

    @Test
    void testAggiungiNuovoIngrediente_NomeNullo_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ingredienteService.aggiungiNuovoIngrediente(null, 1.00f);
        });
        assertEquals("Il nome dell'ingrediente non può essere vuoto.", thrown.getMessage());
        verifyNoInteractions(ingredienteRepository);
    }

    @Test
    void testAggiungiNuovoIngrediente_PrezzoNegativo_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ingredienteService.aggiungiNuovoIngrediente("Farina", -0.50f);
        });
        assertEquals("Il prezzo dell'ingrediente non può essere negativo.", thrown.getMessage());
        verifyNoInteractions(ingredienteRepository);
    }

    @Test
    void testAggiungiNuovoIngrediente_NomeGiaEsistente_ThrowsException() {
        when(ingredienteRepository.findByNome("Pomodoro")).thenReturn(Optional.of(ingrediente1));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ingredienteService.aggiungiNuovoIngrediente("Pomodoro", 1.20f);
        });
        assertEquals("Esiste già un ingrediente con questo nome: Pomodoro", thrown.getMessage());
        verify(ingredienteRepository, times(1)).findByNome("Pomodoro");
        verifyNoMoreInteractions(ingredienteRepository);
    }

    @Test
    void testGetIngredienteById_Esistente() {
        when(ingredienteRepository.findById(ingrediente1.getId())).thenReturn(Optional.of(ingrediente1));

        Optional<Ingrediente> foundIngrediente = ingredienteService.getIngredienteById(ingrediente1.getId());

        assertTrue(foundIngrediente.isPresent());
        assertEquals(ingrediente1, foundIngrediente.get());
        verify(ingredienteRepository, times(1)).findById(ingrediente1.getId());
    }

    @Test
    void testGetIngredienteById_NonEsistente() {
        when(ingredienteRepository.findById(99)).thenReturn(Optional.empty());

        Optional<Ingrediente> foundIngrediente = ingredienteService.getIngredienteById(99);

        assertFalse(foundIngrediente.isPresent());
        verify(ingredienteRepository, times(1)).findById(99);
    }

    @Test
    void testGetIngredienteByNome_Esistente() {
        when(ingredienteRepository.findByNome("Mozzarella")).thenReturn(Optional.of(ingrediente2));

        Optional<Ingrediente> foundIngrediente = ingredienteService.getIngredienteByNome("Mozzarella");

        assertTrue(foundIngrediente.isPresent());
        assertEquals(ingrediente2, foundIngrediente.get());
        verify(ingredienteRepository, times(1)).findByNome("Mozzarella");
    }

    @Test
    void testGetIngredienteByNome_NonEsistente() {
        when(ingredienteRepository.findByNome("Farina")).thenReturn(Optional.empty());

        Optional<Ingrediente> foundIngrediente = ingredienteService.getIngredienteByNome("Farina");

        assertFalse(foundIngrediente.isPresent());
        verify(ingredienteRepository, times(1)).findByNome("Farina");
    }

    @Test
    void testGetAllIngredienti_Successo() {
        when(ingredienteRepository.findAll()).thenReturn(Arrays.asList(ingrediente1, ingrediente2));

        List<Ingrediente> allIngredienti = ingredienteService.getAllIngredienti();

        assertNotNull(allIngredienti);
        assertEquals(2, allIngredienti.size());
        assertTrue(allIngredienti.contains(ingrediente1));
        assertTrue(allIngredienti.contains(ingrediente2));
        verify(ingredienteRepository, times(1)).findAll();
    }

    @Test
    void testGetAllIngredienti_NessunIngrediente() {
        when(ingredienteRepository.findAll()).thenReturn(Collections.emptyList());

        List<Ingrediente> allIngredienti = ingredienteService.getAllIngredienti();

        assertNotNull(allIngredienti);
        assertTrue(allIngredienti.isEmpty());
        verify(ingredienteRepository, times(1)).findAll();
    }

    @Test
    void testAggiornaIngrediente_Successo() {
        Ingrediente updatedIngrediente = new Ingrediente(1, "Pomodoro San Marzano", 1.80f);

        when(ingredienteRepository.findByNome(updatedIngrediente.getNome())).thenReturn(Optional.of(ingrediente1));
        when(ingredienteRepository.save(updatedIngrediente)).thenReturn(updatedIngrediente);
        Ingrediente result = ingredienteService.aggiornaIngrediente(updatedIngrediente);

        assertNotNull(result);
        assertEquals(updatedIngrediente.getNome(), result.getNome());
        assertEquals(updatedIngrediente.getPrezzo(), result.getPrezzo());
        verify(ingredienteRepository, times(1)).findByNome(updatedIngrediente.getNome());
        verify(ingredienteRepository, times(1)).save(updatedIngrediente);
    }

    @Test
    void testAggiornaIngrediente_IngredienteNullo_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ingredienteService.aggiornaIngrediente(null);
        });
        assertEquals("Ingrediente non valido per l'aggiornamento.", thrown.getMessage());
        verifyNoInteractions(ingredienteRepository);
    }

    @Test
    void testAggiornaIngrediente_IdNonValido_ThrowsException() {
        Ingrediente invalidIngrediente = new Ingrediente(0, "Pane", 1.00f);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ingredienteService.aggiornaIngrediente(invalidIngrediente);
        });
        assertEquals("Ingrediente non valido per l'aggiornamento.", thrown.getMessage());
        verifyNoInteractions(ingredienteRepository);
    }

    @Test
    void testAggiornaIngrediente_PrezzoNegativo_ThrowsException() {
        Ingrediente invalidPrezzoIngrediente = new Ingrediente(1, "Basilico", -0.10f);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ingredienteService.aggiornaIngrediente(invalidPrezzoIngrediente);
        });
        assertEquals("Il prezzo dell'ingrediente non può essere negativo.", thrown.getMessage());
        verifyNoInteractions(ingredienteRepository);
    }

    @Test
    void testAggiornaIngrediente_NomeDuplicatoConIdDiverso_ThrowsException() {
        Ingrediente duplicateNameIngrediente = new Ingrediente(2, "Pomodoro", 1.50f);

        when(ingredienteRepository.findByNome("Pomodoro")).thenReturn(Optional.of(ingrediente1));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ingredienteService.aggiornaIngrediente(duplicateNameIngrediente);
        });
        assertEquals("Esiste già un altro ingrediente con questo nome.", thrown.getMessage());
        verify(ingredienteRepository, times(1)).findByNome("Pomodoro");
        verify(ingredienteRepository, never()).save(any(Ingrediente.class));
    }

    @Test
    void testEliminaIngrediente_Successo() {
        doNothing().when(ingredienteRepository).deleteById(ingrediente1.getId());

        ingredienteService.eliminaIngrediente(ingrediente1.getId());
        verify(ingredienteRepository, times(1)).deleteById(ingrediente1.getId());
    }

    @Test
    void testEliminaIngrediente_IdNonValido_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ingredienteService.eliminaIngrediente(0);
        });
        assertEquals("ID ingrediente non valido per l'eliminazione.", thrown.getMessage());
        verifyNoInteractions(ingredienteRepository);
    }
}