package org.example.service;

import org.example.model.Cliente;
import org.example.model.FidelityCard;
import org.example.model.Premio;
import org.example.model.PremioRiscattato;
import org.example.repository.FidelityCardRepository;
import org.example.repository.PremioRepository;
import org.example.repository.PremioRiscattatoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PremioServiceTest {

    @Mock
    private PremioRepository premioRepository;
    @Mock
    private FidelityCardRepository fidelityCardRepository;
    @Mock
    private PremioRiscattatoRepository premioRiscattatoRepository;
    @Mock
    private FidelityCardService fidelityCardService;

    @InjectMocks
    private PremioService premioService;
    private Premio testPremio1;
    private Premio testPremio2;
    private Cliente testCliente1;
    private Cliente testCliente2;
    private FidelityCard testFidelityCard1;
    private FidelityCard testFidelityCard2;

    @BeforeEach
    void setUp() {
        testPremio1 = new Premio(1, "Buono Sconto 10€", "Sconto di 10 euro su una spesa minima di 50€", 100);
        testPremio2 = new Premio(2, "Cena Gratuita", "Cena per due persone con menu degustazione", 500);
        testCliente1 = new Cliente(10, "Anna", "Verdi", "anna.verdi@example.com");
        testCliente2 = new Cliente(11, "Giulia", "Neri", "giulia.neri@example.com");
        testFidelityCard1 = new FidelityCard(20, testCliente1, 150);
        testFidelityCard2 = new FidelityCard(21, testCliente2, 40);
        reset(premioRepository, fidelityCardRepository, premioRiscattatoRepository, fidelityCardService);
    }

    @Test
    void testCreaNuovoPremio_Successo() {
        String nome = "Spedizione Gratuita";
        String descrizione = "Spedizione gratuita per il tuo prossimo ordine";
        int punti = 50;
        int nextId = 3;

        when(premioRepository.findByNome(nome)).thenReturn(Optional.empty());
        when(premioRepository.getNextId()).thenReturn(nextId);
        when(premioRepository.save(any(Premio.class))).thenAnswer(invocation -> {
            Premio savedPremio = invocation.getArgument(0);
            assertEquals(nextId, savedPremio.getId());
            assertEquals(nome, savedPremio.getNome());
            assertEquals(descrizione, savedPremio.getDescrizione());
            assertEquals(punti, savedPremio.getPuntiNecessari());
            return savedPremio;
        });

        Premio nuovoPremio = premioService.creaNuovoPremio(nome, descrizione, punti);

        assertNotNull(nuovoPremio);
        assertEquals(nome, nuovoPremio.getNome());
        assertEquals(punti, nuovoPremio.getPuntiNecessari());

        verify(premioRepository, times(1)).findByNome(nome);
        verify(premioRepository, times(1)).getNextId();
        verify(premioRepository, times(1)).save(any(Premio.class));
    }

    @Test
    void testCreaNuovoPremio_NomeNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                        premioService.creaNuovoPremio(null, "desc", 10),
                "Nome o punti necessari del premio non validi.");
        assertThrows(IllegalArgumentException.class, () ->
                        premioService.creaNuovoPremio("", "desc", 10),
                "Nome o punti necessari del premio non validi.");
        assertThrows(IllegalArgumentException.class, () ->
                        premioService.creaNuovoPremio("   ", "desc", 10),
                "Nome o punti necessari del premio non validi.");
        verifyNoInteractions(premioRepository);
    }

    @Test
    void testCreaNuovoPremio_PuntiNonValidi_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                        premioService.creaNuovoPremio("Nome Premio", "desc", 0),
                "Nome o punti necessari del premio non validi.");
        assertThrows(IllegalArgumentException.class, () ->
                        premioService.creaNuovoPremio("Nome Premio", "desc", -10),
                "Nome o punti necessari del premio non validi.");
        verifyNoInteractions(premioRepository);
    }

    @Test
    void testCreaNuovoPremio_NomeDuplicato_ThrowsException() {
        String nomeDuplicato = testPremio1.getNome();
        when(premioRepository.findByNome(nomeDuplicato)).thenReturn(Optional.of(testPremio1));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                premioService.creaNuovoPremio(nomeDuplicato, "Descrizione", 200));

        assertEquals("Esiste già un premio con questo nome: " + nomeDuplicato, thrown.getMessage());
        verify(premioRepository, times(1)).findByNome(nomeDuplicato);
        verifyNoMoreInteractions(premioRepository);
    }

    @Test
    void testGetPremioById_Esistente() {
        when(premioRepository.findById(testPremio1.getId())).thenReturn(Optional.of(testPremio1));

        Optional<Premio> foundPremio = premioService.getPremioById(testPremio1.getId());

        assertTrue(foundPremio.isPresent());
        assertEquals(testPremio1, foundPremio.get());
        verify(premioRepository, times(1)).findById(testPremio1.getId());
    }

    @Test
    void testGetPremioById_NonEsistente() {
        when(premioRepository.findById(999)).thenReturn(Optional.empty());

        Optional<Premio> foundPremio = premioService.getPremioById(999);

        assertFalse(foundPremio.isPresent());
        verify(premioRepository, times(1)).findById(999);
    }

    @Test
    void testGetPremioByNome_Esistente() {
        when(premioRepository.findByNome(testPremio2.getNome())).thenReturn(Optional.of(testPremio2));

        Optional<Premio> foundPremio = premioService.getPremioByNome(testPremio2.getNome());

        assertTrue(foundPremio.isPresent());
        assertEquals(testPremio2, foundPremio.get());
        verify(premioRepository, times(1)).findByNome(testPremio2.getNome());
    }

    @Test
    void testGetPremioByNome_NonEsistente() {
        when(premioRepository.findByNome("Premio Inesistente")).thenReturn(Optional.empty());

        Optional<Premio> foundPremio = premioService.getPremioByNome("Premio Inesistente");

        assertFalse(foundPremio.isPresent());
        verify(premioRepository, times(1)).findByNome("Premio Inesistente");
    }

    @Test
    void testGetAllPremi_ListaNonVuota() {
        when(premioRepository.findAll()).thenReturn(Arrays.asList(testPremio1, testPremio2));

        List<Premio> allPremi = premioService.getAllPremi();

        assertNotNull(allPremi);
        assertEquals(2, allPremi.size());
        assertTrue(allPremi.contains(testPremio1));
        assertTrue(allPremi.contains(testPremio2));
        verify(premioRepository, times(1)).findAll();
    }

    @Test
    void testGetAllPremi_ListaVuota() {
        when(premioRepository.findAll()).thenReturn(Collections.emptyList());

        List<Premio> allPremi = premioService.getAllPremi();

        assertNotNull(allPremi);
        assertTrue(allPremi.isEmpty());
        verify(premioRepository, times(1)).findAll();
    }

    @Test
    void testAggiornaPremio_Successo() {
        Premio premioAggiornato = new Premio(testPremio1.getId(), "Buono Sconto 15€", "Sconto di 15 euro", 150);
        when(premioRepository.findByNome(premioAggiornato.getNome())).thenReturn(Optional.of(testPremio1));
        when(premioRepository.save(premioAggiornato)).thenReturn(premioAggiornato);

        Premio result = premioService.aggiornaPremio(premioAggiornato);

        assertNotNull(result);
        assertEquals(premioAggiornato.getNome(), result.getNome());
        assertEquals(premioAggiornato.getPuntiNecessari(), result.getPuntiNecessari());
        verify(premioRepository, times(1)).findByNome(premioAggiornato.getNome());
        verify(premioRepository, times(1)).save(premioAggiornato);
    }

    @Test
    void testAggiornaPremio_PremioNulloOIdNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                premioService.aggiornaPremio(null), "Premio non valido per l'aggiornamento.");
        assertThrows(IllegalArgumentException.class, () ->
                premioService.aggiornaPremio(new Premio(0, "Invalid", "", 10)), "Premio non valido per l'aggiornamento.");
        verifyNoInteractions(premioRepository);
    }

    @Test
    void testAggiornaPremio_PuntiNonValidi_ThrowsException() {
        Premio premioConPuntiZero = new Premio(testPremio1.getId(), "Nome", "Desc", 0);
        Premio premioConPuntiNegativi = new Premio(testPremio1.getId(), "Nome", "Desc", -5);

        IllegalArgumentException thrownZero = assertThrows(IllegalArgumentException.class, () ->
                premioService.aggiornaPremio(premioConPuntiZero));
        assertEquals("I punti necessari per il premio devono essere maggiori di zero.", thrownZero.getMessage());

        IllegalArgumentException thrownNegative = assertThrows(IllegalArgumentException.class, () ->
                premioService.aggiornaPremio(premioConPuntiNegativi));
        assertEquals("I punti necessari per il premio devono essere maggiori di zero.", thrownNegative.getMessage());

        verifyNoInteractions(premioRepository);
    }

    @Test
    void testAggiornaPremio_NomeDuplicatoConAltroId_ThrowsException() {
        Premio premioDaAggiornare = new Premio(testPremio1.getId(), testPremio2.getNome(), "Nuova descrizione", 100);
        when(premioRepository.findByNome(premioDaAggiornare.getNome())).thenReturn(Optional.of(testPremio2));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                premioService.aggiornaPremio(premioDaAggiornare));

        assertEquals("Esiste già un altro premio con questo nome.", thrown.getMessage());
        verify(premioRepository, times(1)).findByNome(premioDaAggiornare.getNome());
        verifyNoMoreInteractions(premioRepository);
    }

    @Test
    void testEliminaPremio_Successo() {
        int idToDelete = testPremio1.getId();

        doNothing().when(premioRepository).deleteById(idToDelete);

        premioService.eliminaPremio(idToDelete);

        verify(premioRepository, times(1)).deleteById(idToDelete);
    }

    @Test
    void testEliminaPremio_IdNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                premioService.eliminaPremio(0), "ID premio non valido per l'eliminazione.");
        assertThrows(IllegalArgumentException.class, () ->
                premioService.eliminaPremio(-5), "ID premio non valido per l'eliminazione.");
        verifyNoInteractions(premioRepository);
    }

    @Test
    void testRiscattaPremio_Successo() {
        int clienteId = testCliente1.getId();
        int premioId = testPremio1.getId();
        int puntiScalati = testPremio1.getPuntiNecessari();
        int nextRiscattatoId = 1;

        FidelityCard fidelityCardDopoRimozione = new FidelityCard(
                testFidelityCard1.getIdCard(),
                testFidelityCard1.getCliente(),
                testFidelityCard1.getPuntiAccumulati() - puntiScalati
        );

        when(premioRepository.findById(premioId)).thenReturn(Optional.of(testPremio1));
        when(fidelityCardRepository.findByClienteId(clienteId)).thenReturn(Optional.of(testFidelityCard1));
        when(fidelityCardService.rimuoviPunti(testFidelityCard1.getIdCard(), puntiScalati))
                .thenReturn(fidelityCardDopoRimozione);
        when(premioRiscattatoRepository.getNextId()).thenReturn(nextRiscattatoId);
        when(premioRiscattatoRepository.save(any(PremioRiscattato.class))).thenAnswer(invocation -> {
            PremioRiscattato saved = invocation.getArgument(0);
            assertEquals(nextRiscattatoId, saved.getId());
            assertEquals(testCliente1, saved.getCliente());
            assertEquals(testPremio1, saved.getPremio());
            assertNotNull(saved.getDataRiscatto());
            return saved;
        });

        PremioRiscattato result = premioService.riscattaPremio(clienteId, premioId);

        assertNotNull(result);
        assertEquals(nextRiscattatoId, result.getId());
        assertEquals(testCliente1, result.getCliente());
        assertEquals(testPremio1, result.getPremio());
        assertNotNull(result.getDataRiscatto());

        verify(premioRepository, times(1)).findById(premioId);
        verify(fidelityCardRepository, times(1)).findByClienteId(clienteId);
        verify(fidelityCardService, times(1)).rimuoviPunti(testFidelityCard1.getIdCard(), puntiScalati);
        verify(premioRiscattatoRepository, times(1)).getNextId();
        verify(premioRiscattatoRepository, times(1)).save(any(PremioRiscattato.class));
    }

    @Test
    void testRiscattaPremio_PremioNonTrovato_ThrowsException() {
        int clienteId = testCliente1.getId();
        int premioId = 999;

        when(premioRepository.findById(premioId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            premioService.riscattaPremio(clienteId, premioId);
        });

        assertEquals("Premio non trovato con ID: " + premioId, thrown.getMessage());
        verify(premioRepository, times(1)).findById(premioId);
        verifyNoInteractions(fidelityCardRepository, fidelityCardService, premioRiscattatoRepository);
    }

    @Test
    void testRiscattaPremio_FidelityCardNonTrovata_ThrowsException() {
        int clienteId = 99;
        int premioId = testPremio1.getId();

        when(premioRepository.findById(premioId)).thenReturn(Optional.of(testPremio1));
        when(fidelityCardRepository.findByClienteId(clienteId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            premioService.riscattaPremio(clienteId, premioId);
        });

        assertEquals("Fidelity Card non trovata per il cliente con ID: " + clienteId, thrown.getMessage());
        verify(premioRepository, times(1)).findById(premioId);
        verify(fidelityCardRepository, times(1)).findByClienteId(clienteId);
        verifyNoInteractions(fidelityCardService, premioRiscattatoRepository);
    }

    @Test
    void testRiscattaPremio_PuntiInsufficienti_ThrowsException() {
        int clienteId = testCliente1.getId();
        int premioId = testPremio2.getId();
        testFidelityCard1.setPuntiAccumulati(100);

        when(premioRepository.findById(premioId)).thenReturn(Optional.of(testPremio2));
        when(fidelityCardRepository.findByClienteId(clienteId)).thenReturn(Optional.of(testFidelityCard1));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () -> {
            premioService.riscattaPremio(clienteId, premioId);
        });

        assertEquals("Punti insufficienti (100) per riscattare il premio 'Cena Gratuita' (necessari: 500).", thrown.getMessage());
        verify(premioRepository, times(1)).findById(premioId);
        verify(fidelityCardRepository, times(1)).findByClienteId(clienteId);
        verifyNoInteractions(fidelityCardService, premioRiscattatoRepository);
    }
}