package org.example.service;

import org.example.model.Variazione;
import org.example.repository.VariazioneRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class VariazioneServiceTest {

    @Mock
    private VariazioneRepository variazioneRepository;

    @InjectMocks
    private VariazioneService variazioneService;
    private Variazione variazionePositiva;
    private Variazione variazioneNegativa;
    private Variazione variazioneSenzaRigaOrdine;


    @BeforeEach
    void setUp() {
        variazionePositiva = new Variazione(1, "Extra formaggio", 1.50f);
        variazioneNegativa = new Variazione(2, "Senza cipolla", -0.75f);
        variazioneSenzaRigaOrdine = new Variazione(3, "Salsa extra", 0.50f);
        reset(variazioneRepository);
    }

    @Test
    void testCreaVariazione_Successo_CostoPositivo() {
        String tipo = "Aggiungi bacon";
        float costo = 2.00f;
        int nextId = 4;

        when(variazioneRepository.getNextId()).thenReturn(nextId);
        when(variazioneRepository.save(any(Variazione.class))).thenAnswer(invocation -> {
            Variazione var = invocation.getArgument(0);
            assertEquals(nextId, var.getId());
            return var;
        });

        Variazione createdVariazione = variazioneService.creaVariazione(tipo, costo);

        assertNotNull(createdVariazione);
        assertEquals(nextId, createdVariazione.getId());
        assertEquals(tipo, createdVariazione.getTipo());
        assertEquals(costo, createdVariazione.getCosto(), 0.001);
        assertNull(createdVariazione.getRigaOrdine());

        verify(variazioneRepository, times(1)).getNextId();
        verify(variazioneRepository, times(1)).save(any(Variazione.class));
    }

    @Test
    void testCreaVariazione_Successo_CostoNegativo() {
        String tipo = "Senza glutine";
        float costo = -1.00f;
        int nextId = 5;

        when(variazioneRepository.getNextId()).thenReturn(nextId);
        when(variazioneRepository.save(any(Variazione.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Variazione createdVariazione = variazioneService.creaVariazione(tipo, costo);

        assertNotNull(createdVariazione);
        assertEquals(nextId, createdVariazione.getId());
        assertEquals(tipo, createdVariazione.getTipo());
        assertEquals(costo, createdVariazione.getCosto(), 0.001);

        verify(variazioneRepository, times(1)).getNextId();
        verify(variazioneRepository, times(1)).save(any(Variazione.class));
    }

    @Test
    void testCreaVariazione_TipoNullo_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                variazioneService.creaVariazione(null, 1.00f));

        assertEquals("Il tipo di variazione non può essere vuoto.", thrown.getMessage());
        verifyNoInteractions(variazioneRepository);
    }

    @Test
    void testCreaVariazione_TipoVuoto_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                variazioneService.creaVariazione("   ", 1.00f));

        assertEquals("Il tipo di variazione non può essere vuoto.", thrown.getMessage());
        verifyNoInteractions(variazioneRepository);
    }

    @Test
    void testGetVariazioneById_Esistente() {
        when(variazioneRepository.findById(variazionePositiva.getId())).thenReturn(Optional.of(variazionePositiva));

        Optional<Variazione> foundVariazione = variazioneService.getVariazioneById(variazionePositiva.getId());

        assertTrue(foundVariazione.isPresent());
        assertEquals(variazionePositiva, foundVariazione.get());
        verify(variazioneRepository, times(1)).findById(variazionePositiva.getId());
    }

    @Test
    void testGetVariazioneById_NonEsistente() {
        int nonExistentId = 999;
        when(variazioneRepository.findById(nonExistentId)).thenReturn(Optional.empty());

        Optional<Variazione> foundVariazione = variazioneService.getVariazioneById(nonExistentId);

        assertFalse(foundVariazione.isPresent());
        verify(variazioneRepository, times(1)).findById(nonExistentId);
    }

    @Test
    void testGetAllVariazioni_ListaNonVuota() {
        List<Variazione> allVariazioni = Arrays.asList(variazionePositiva, variazioneNegativa, variazioneSenzaRigaOrdine);
        when(variazioneRepository.findAll()).thenReturn(allVariazioni);

        List<Variazione> result = variazioneService.getAllVariazioni();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(3, result.size());
        assertTrue(result.contains(variazionePositiva));
        assertTrue(result.contains(variazioneNegativa));
        verify(variazioneRepository, times(1)).findAll();
    }

    @Test
    void testGetAllVariazioni_ListaVuota() {
        when(variazioneRepository.findAll()).thenReturn(Collections.emptyList());

        List<Variazione> result = variazioneService.getAllVariazioni();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(variazioneRepository, times(1)).findAll();
    }

    @Test
    void testAggiornaVariazione_Successo() {
        Variazione updatedVariazione = new Variazione(variazionePositiva.getId(), "Extra mozzarella", 2.00f);
        when(variazioneRepository.save(updatedVariazione)).thenReturn(updatedVariazione);

        Variazione result = variazioneService.aggiornaVariazione(updatedVariazione);

        assertNotNull(result);
        assertEquals(updatedVariazione.getId(), result.getId());
        assertEquals(updatedVariazione.getTipo(), result.getTipo());
        assertEquals(updatedVariazione.getCosto(), result.getCosto(), 0.001);
        verify(variazioneRepository, times(1)).save(updatedVariazione);
    }

    @Test
    void testAggiornaVariazione_VariazioneNull_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                variazioneService.aggiornaVariazione(null));

        assertEquals("Variazione non valida per l'aggiornamento.", thrown.getMessage());
        verifyNoInteractions(variazioneRepository);
    }

    @Test
    void testAggiornaVariazione_IdNonValido_ThrowsException() {
        Variazione invalidVariazione = new Variazione(0, "Tipo", 1.0f);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                variazioneService.aggiornaVariazione(invalidVariazione));

        assertEquals("Variazione non valida per l'aggiornamento.", thrown.getMessage());
        verifyNoInteractions(variazioneRepository);
    }

    @Test
    void testAggiornaVariazione_TipoNullo_ThrowsException() {
        Variazione variazioneWithNullTipo = new Variazione(variazionePositiva.getId(), null, 1.0f);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                variazioneService.aggiornaVariazione(variazioneWithNullTipo));

        assertEquals("Il tipo di variazione non può essere vuoto.", thrown.getMessage());
        verifyNoInteractions(variazioneRepository);
    }

    @Test
    void testAggiornaVariazione_TipoVuoto_ThrowsException() {
        Variazione variazioneWithEmptyTipo = new Variazione(variazionePositiva.getId(), "  ", 1.0f);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                variazioneService.aggiornaVariazione(variazioneWithEmptyTipo));

        assertEquals("Il tipo di variazione non può essere vuoto.", thrown.getMessage());
        verifyNoInteractions(variazioneRepository);
    }

    @Test
    void testEliminaVariazione_Successo() {
        int idToDelete = variazioneNegativa.getId();
        doNothing().when(variazioneRepository).deleteById(idToDelete);

        variazioneService.eliminaVariazione(idToDelete);

        verify(variazioneRepository, times(1)).deleteById(idToDelete);
    }

    @Test
    void testEliminaVariazione_IdNonValido_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                variazioneService.eliminaVariazione(0));

        assertEquals("ID variazione non valido per l'eliminazione.", thrown.getMessage());
        verifyNoInteractions(variazioneRepository);
    }
}