package org.example.service;

import org.example.model.Dipendente;
import org.example.model.Turno;
import org.example.repository.DipendenteRepository;
import org.example.repository.TurnoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TurnoServiceTest {

    private static final Duration DURATA_TURNO_STANDARD = Duration.ofHours(6);

    @Mock
    private TurnoRepository turnoRepository;

    @Mock
    private DipendenteRepository dipendenteRepository;

    @InjectMocks
    private TurnoService turnoService;

    private Dipendente dipendente1;
    private Dipendente dipendente2;
    private Turno turno1_dip1;
    private Turno turno2_dip1;
    private Turno turno3_dip2;

    @BeforeEach
    void setUp() {
        dipendente1 = new Dipendente(1, "Mario", "Rossi", "Cuoco");
        dipendente2 = new Dipendente(2, "Luigi", "Verdi", "Cameriere");

        turno1_dip1 = new Turno(101, dipendente1, LocalDate.of(2025, 7, 10), LocalTime.of(9, 0), "Mattina"); // 9:00 - 15:00
        turno2_dip1 = new Turno(102, dipendente1, LocalDate.of(2025, 7, 15), LocalTime.of(14, 0), "Pomeriggio"); // 14:00 - 20:00
        turno3_dip2 = new Turno(103, dipendente2, LocalDate.of(2025, 7, 10), LocalTime.of(22, 0), "Notte"); // 22:00 - 04:00

        reset(turnoRepository, dipendenteRepository);
    }

    private LocalTime getOraFine(LocalTime oraInizio) {
        return oraInizio.plus(DURATA_TURNO_STANDARD);
    }

    private boolean isOverlapping(LocalDate data1, LocalTime inizio1, LocalTime fine1,
                                  LocalDate data2, LocalTime inizio2, LocalTime fine2) {
        if (!data1.isEqual(data2)) {
            return false;
        }
        return !inizio1.isAfter(fine2.minusMinutes(1)) && !inizio2.isAfter(fine1.minusMinutes(1));
    }


    @Test
    void testAssegnaTurno_Successo() {
        LocalDate data = LocalDate.of(2025, 8, 1);
        LocalTime ora = LocalTime.of(9, 0); // 9:00 - 15:00
        String tipo = "Mattina";
        int nextId = 1;

        when(dipendenteRepository.findById(dipendente1.getId())).thenReturn(Optional.of(dipendente1));
        when(turnoRepository.findByDipendenteAndData(dipendente1, data)).thenReturn(Collections.emptyList());
        when(turnoRepository.getNextId()).thenReturn(nextId);
        when(turnoRepository.save(any(Turno.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Turno result = turnoService.assegnaTurno(dipendente1.getId(), data, ora, tipo);

        assertNotNull(result);
        assertEquals(nextId, result.getId());
        assertEquals(dipendente1, result.getDipendente());
        assertEquals(data, result.getData());
        assertEquals(ora, result.getOra());
        assertEquals(tipo, result.getTipoTurno());

        verify(dipendenteRepository, times(1)).findById(dipendente1.getId());
        verify(turnoRepository, times(1)).findByDipendenteAndData(dipendente1, data);
        verify(turnoRepository, times(1)).getNextId();
        verify(turnoRepository, times(1)).save(any(Turno.class));
    }

    @Test
    void testAssegnaTurno_DipendenteNonTrovato_ThrowsException() {
        LocalDate data = LocalDate.of(2025, 8, 1);
        LocalTime ora = LocalTime.of(9, 0);
        String tipo = "Mattina";
        int nonExistentId = 999;

        when(dipendenteRepository.findById(nonExistentId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                turnoService.assegnaTurno(nonExistentId, data, ora, tipo));

        assertEquals("Dipendente non trovato con ID: " + nonExistentId, thrown.getMessage());
        verify(dipendenteRepository, times(1)).findById(nonExistentId);
        verifyNoInteractions(turnoRepository);
    }

    @Test
    void testAssegnaTurno_DataNull_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                turnoService.assegnaTurno(dipendente1.getId(), null, LocalTime.of(9, 0), "Mattina"));

        assertEquals("Dati turno non validi: data o ora non possono essere null.", thrown.getMessage());
        verifyNoInteractions(dipendenteRepository, turnoRepository);
    }

    @Test
    void testAssegnaTurno_OraNull_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                turnoService.assegnaTurno(dipendente1.getId(), LocalDate.of(2025, 8, 1), null, "Mattina"));

        assertEquals("Dati turno non validi: data o ora non possono essere null.", thrown.getMessage());
        verifyNoInteractions(dipendenteRepository, turnoRepository);
    }

    @Test
    void testAssegnaTurno_TipoTurnoVuoto_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                turnoService.assegnaTurno(dipendente1.getId(), LocalDate.of(2025, 8, 1), LocalTime.of(9,0), ""));

        assertEquals("Il tipo di turno non può essere vuoto.", thrown.getMessage());
        verifyNoInteractions(dipendenteRepository, turnoRepository);
    }

    @Test
    void testAssegnaTurno_TipoTurnoNull_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                turnoService.assegnaTurno(dipendente1.getId(), LocalDate.of(2025, 8, 1), LocalTime.of(9,0), null));

        assertEquals("Il tipo di turno non può essere vuoto.", thrown.getMessage());
        verifyNoInteractions(dipendenteRepository, turnoRepository);
    }

    @Test
    void testAssegnaTurno_Sovrapposizione_StessaDataStessoDipendente() {
        LocalDate existingData = turno1_dip1.getData();
        LocalTime newOra = LocalTime.of(14, 0);
        String newTipo = "Pomeriggio";

        when(dipendenteRepository.findById(dipendente1.getId())).thenReturn(Optional.of(dipendente1));
        when(turnoRepository.findByDipendenteAndData(dipendente1, existingData)).thenReturn(Arrays.asList(turno1_dip1));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () ->
                turnoService.assegnaTurno(dipendente1.getId(), existingData, newOra, newTipo));

        assertTrue(thrown.getMessage().contains("Il dipendente " + dipendente1.getNome() + " ha già un turno assegnato per la data " + existingData + "."));
        verify(dipendenteRepository, times(1)).findById(dipendente1.getId());
        verify(turnoRepository, times(1)).findByDipendenteAndData(dipendente1, existingData);
        verify(turnoRepository, never()).save(any(Turno.class));
    }

    @Test
    void testAssegnaTurno_Sovrapposizione_StessaDataStessoDipendente_ConIntervalloNonSovrappostoMaDataUguale() {
        LocalDate existingData = turno1_dip1.getData();
        LocalTime newOra = LocalTime.of(15, 0);
        String newTipo = "PomeriggioTardivo";

        when(dipendenteRepository.findById(dipendente1.getId())).thenReturn(Optional.of(dipendente1));
        when(turnoRepository.findByDipendenteAndData(dipendente1, existingData)).thenReturn(Arrays.asList(turno1_dip1));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () ->
                turnoService.assegnaTurno(dipendente1.getId(), existingData, newOra, newTipo));

        assertTrue(thrown.getMessage().contains("Il dipendente " + dipendente1.getNome() + " ha già un turno assegnato per la data " + existingData + "."));
        verify(dipendenteRepository, times(1)).findById(dipendente1.getId());
        verify(turnoRepository, times(1)).findByDipendenteAndData(dipendente1, existingData);
        verify(turnoRepository, never()).save(any(Turno.class));
    }

    @Test
    void testAssegnaTurno_NonSovrapposizione_StessaDataDipendentiDiversi() {
        // dipendente1 ha turno1_dip1 il 2025-07-10 (9:00-15:00)
        // dipendente2 vuole un turno il 2025-07-10 (22:00-04:00)
        LocalDate data = LocalDate.of(2025, 7, 10);
        LocalTime ora = LocalTime.of(22, 0);
        String tipo = "Notte";
        int nextId = 104;

        when(dipendenteRepository.findById(dipendente2.getId())).thenReturn(Optional.of(dipendente2));
        when(turnoRepository.findByDipendenteAndData(dipendente2, data)).thenReturn(Collections.emptyList());
        when(turnoRepository.getNextId()).thenReturn(nextId);
        when(turnoRepository.save(any(Turno.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Turno result = turnoService.assegnaTurno(dipendente2.getId(), data, ora, tipo);

        assertNotNull(result);
        assertEquals(nextId, result.getId());
        assertEquals(dipendente2, result.getDipendente());
        assertEquals(data, result.getData());
        assertEquals(ora, result.getOra());
        assertEquals(tipo, result.getTipoTurno());

        verify(dipendenteRepository, times(1)).findById(dipendente2.getId());
        verify(turnoRepository, times(1)).findByDipendenteAndData(dipendente2, data);
        verify(turnoRepository, times(1)).getNextId();
        verify(turnoRepository, times(1)).save(any(Turno.class));
    }

    @Test
    void testGetTurnoById_Esistente() {
        when(turnoRepository.findById(turno1_dip1.getId())).thenReturn(Optional.of(turno1_dip1));

        Optional<Turno> found = turnoService.getTurnoById(turno1_dip1.getId());
        assertTrue(found.isPresent());
        assertEquals(turno1_dip1, found.get());
        verify(turnoRepository, times(1)).findById(turno1_dip1.getId());
    }

    @Test
    void testGetTurnoById_NonEsistente() {
        when(turnoRepository.findById(999)).thenReturn(Optional.empty());

        Optional<Turno> found = turnoService.getTurnoById(999);
        assertFalse(found.isPresent());
        verify(turnoRepository, times(1)).findById(999);
    }

    @Test
    void testGetAllTurni_ListaNonVuota() {
        List<Turno> allTurni = Arrays.asList(turno1_dip1, turno2_dip1, turno3_dip2);
        when(turnoRepository.findAll()).thenReturn(allTurni);

        List<Turno> result = turnoService.getAllTurni();
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(3, result.size());
        assertTrue(result.contains(turno1_dip1));
        assertTrue(result.contains(turno3_dip2));
        verify(turnoRepository, times(1)).findAll();
    }

    @Test
    void testGetAllTurni_ListaVuota() {
        when(turnoRepository.findAll()).thenReturn(Collections.emptyList());

        List<Turno> result = turnoService.getAllTurni();
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(turnoRepository, times(1)).findAll();
    }

    @Test
    void testGetTurniByDipendente_DipendenteConTurni() {
        when(dipendenteRepository.findById(dipendente1.getId())).thenReturn(Optional.of(dipendente1));
        when(turnoRepository.findByDipendente(dipendente1)).thenReturn(Arrays.asList(turno1_dip1, turno2_dip1));

        List<Turno> result = turnoService.getTurniByDipendente(dipendente1.getId());
        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(2, result.size());
        assertTrue(result.contains(turno1_dip1));
        assertTrue(result.contains(turno2_dip1));
        verify(dipendenteRepository, times(1)).findById(dipendente1.getId());
        verify(turnoRepository, times(1)).findByDipendente(dipendente1);
    }

    @Test
    void testGetTurniByDipendente_DipendenteSenzaTurni() {
        when(dipendenteRepository.findById(dipendente2.getId())).thenReturn(Optional.of(dipendente2));
        when(turnoRepository.findByDipendente(dipendente2)).thenReturn(Collections.emptyList());

        List<Turno> result = turnoService.getTurniByDipendente(dipendente2.getId());
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(dipendenteRepository, times(1)).findById(dipendente2.getId());
        verify(turnoRepository, times(1)).findByDipendente(dipendente2);
    }

    @Test
    void testGetTurniByDipendente_DipendenteNonTrovato_ThrowsException() {
        int nonExistentId = 999;
        when(dipendenteRepository.findById(nonExistentId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                turnoService.getTurniByDipendente(nonExistentId));

        assertEquals("Dipendente non trovato con ID: " + nonExistentId, thrown.getMessage());
        verify(dipendenteRepository, times(1)).findById(nonExistentId);
        verifyNoInteractions(turnoRepository);
    }

    @Test
    void testGetTurniByData_DataConTurno() {
        LocalDate data = LocalDate.of(2025, 7, 10);
        List<Turno> allTurni = Arrays.asList(turno1_dip1, turno2_dip1, turno3_dip2);

        when(turnoRepository.findByData(data)).thenReturn(
                allTurni.stream()
                        .filter(t -> t.getData().isEqual(data))
                        .collect(Collectors.toList())
        );

        List<Turno> result = turnoService.getTurniByData(data);
        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.contains(turno1_dip1));
        assertTrue(result.contains(turno3_dip2));
        verify(turnoRepository, times(1)).findByData(data);
    }

    @Test
    void testGetTurniByData_NessunTurnoPerData() {
        LocalDate data = LocalDate.of(2025, 7, 1);
        when(turnoRepository.findByData(data)).thenReturn(Collections.emptyList());

        List<Turno> result = turnoService.getTurniByData(data);
        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(turnoRepository, times(1)).findByData(data);
    }

    @Test
    void testAggiornaTurno_Successo() {
        Turno turnoToUpdate = new Turno(turno1_dip1.getId(), dipendente1, LocalDate.of(2025, 7, 10), LocalTime.of(18, 0), "Sera");

        when(dipendenteRepository.findById(dipendente1.getId())).thenReturn(Optional.of(dipendente1));
        when(turnoRepository.findByDipendente(dipendente1)).thenReturn(new ArrayList<>(Arrays.asList(turno1_dip1, turno2_dip1)));
        when(turnoRepository.save(turnoToUpdate)).thenReturn(turnoToUpdate);

        Turno updatedTurno = turnoService.aggiornaTurno(turnoToUpdate);

        assertNotNull(updatedTurno);
        assertEquals(turnoToUpdate.getOra(), updatedTurno.getOra());
        assertEquals(turnoToUpdate.getTipoTurno(), updatedTurno.getTipoTurno());

        verify(dipendenteRepository, times(1)).findById(dipendente1.getId());
        verify(turnoRepository, times(1)).findByDipendente(dipendente1);
        verify(turnoRepository, times(1)).save(turnoToUpdate);
    }


    @Test
    void testAggiornaTurno_TurnoNonValido_ThrowsException() {
        Turno invalidTurno = new Turno(0, dipendente1, LocalDate.of(2025, 1, 1), LocalTime.of(9,0), "Mattina");

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                turnoService.aggiornaTurno(invalidTurno));

        assertEquals("Turno non valido per l'aggiornamento.", thrown.getMessage());
        verifyNoInteractions(dipendenteRepository, turnoRepository);
    }

    @Test
    void testAggiornaTurno_DipendenteAssociatoNonTrovato_ThrowsException() {
        Dipendente nonExistentDipendente = new Dipendente(999, "Nome", "Cognome", "Ruolo");
        Turno turnoWithNonExistentDip = new Turno(turno1_dip1.getId(), nonExistentDipendente, LocalDate.of(2025, 7, 10), LocalTime.of(9,0), "Mattina");

        when(dipendenteRepository.findById(nonExistentDipendente.getId())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                turnoService.aggiornaTurno(turnoWithNonExistentDip));

        assertEquals("Dipendente associato non trovato per l'aggiornamento del turno.", thrown.getMessage());
        verify(dipendenteRepository, times(1)).findById(nonExistentDipendente.getId());
        verifyNoInteractions(turnoRepository);
    }

    @Test
    void testAggiornaTurno_SovrapposizioneDopoAggiornamento_ThrowsException() {
        Turno turnoToUpdate = new Turno(turno2_dip1.getId(), dipendente1, LocalDate.of(2025, 7, 10), LocalTime.of(18, 0), "Sera");

        when(dipendenteRepository.findById(dipendente1.getId())).thenReturn(Optional.of(dipendente1));
        when(turnoRepository.findByDipendente(dipendente1)).thenReturn(Arrays.asList(turno1_dip1, turno2_dip1));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () ->
                turnoService.aggiornaTurno(turnoToUpdate));

        assertTrue(thrown.getMessage().contains("causa una sovrapposizione con il turno esistente in data"));
        verify(dipendenteRepository, times(1)).findById(dipendente1.getId());
        verify(turnoRepository, times(1)).findByDipendente(dipendente1);
        verify(turnoRepository, never()).save(any(Turno.class));
    }

    @Test
    void testEliminaTurno_Successo() {
        int idToDelete = turno1_dip1.getId();
        doNothing().when(turnoRepository).deleteById(idToDelete);

        turnoService.eliminaTurno(idToDelete);
        verify(turnoRepository, times(1)).deleteById(idToDelete);
    }

    @Test
    void testEliminaTurno_IdNonValido_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                turnoService.eliminaTurno(0));

        assertEquals("ID turno non valido per l'eliminazione.", thrown.getMessage());
        verifyNoInteractions(turnoRepository);
    }
}