package org.example.service;

import org.example.model.Tavolo;
import org.example.repository.TavoloRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TavoloServiceTest {

    @Mock
    private TavoloRepository tavoloRepository;

    @InjectMocks
    private TavoloService tavoloService;
    private Tavolo tavoloLiberoGrande;
    private Tavolo tavoloLiberoPiccolo;
    private Tavolo tavoloOccupato;
    private Tavolo tavoloRiservato;

    @BeforeEach
    void setUp() {
        tavoloLiberoGrande = new Tavolo(1, 4, Tavolo.STATO_LIBERO);
        tavoloLiberoPiccolo = new Tavolo(2, 2, Tavolo.STATO_LIBERO);
        tavoloOccupato = new Tavolo(3, 6, Tavolo.STATO_OCCUPATO);
        tavoloRiservato = new Tavolo(4, 4, Tavolo.STATO_RISERVATO);

        reset(tavoloRepository);
    }

    @Test
    void testCreaTavolo_Successo() {
        int numeroTavolo = 5;
        int numPosti = 8;
        Tavolo nuovoTavoloDaCreare = new Tavolo(numeroTavolo, numPosti, Tavolo.STATO_LIBERO);

        when(tavoloRepository.findByNumeroTavolo(numeroTavolo)).thenReturn(Optional.empty());
        when(tavoloRepository.save(any(Tavolo.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Tavolo createdTavolo = tavoloService.creaTavolo(numeroTavolo, numPosti);

        assertNotNull(createdTavolo);
        assertEquals(numeroTavolo, createdTavolo.getNumeroTavolo());
        assertEquals(numPosti, createdTavolo.getNumPosti());
        assertEquals(Tavolo.STATO_LIBERO, createdTavolo.getStato());

        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavolo);
        verify(tavoloRepository, times(1)).save(any(Tavolo.class));
    }

    @Test
    void testCreaTavolo_NumeroEsistente_ThrowsException() {
        int numeroTavoloEsistente = tavoloLiberoGrande.getNumeroTavolo();
        when(tavoloRepository.findByNumeroTavolo(numeroTavoloEsistente)).thenReturn(Optional.of(tavoloLiberoGrande));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                tavoloService.creaTavolo(numeroTavoloEsistente, 4));

        assertEquals("Tavolo con numero " + numeroTavoloEsistente + " esiste già.", thrown.getMessage());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavoloEsistente);
        verify(tavoloRepository, never()).save(any(Tavolo.class));
    }

    @Test
    void testGetTavoloByNumero_Esistente() {
        int numeroEsistente = tavoloOccupato.getNumeroTavolo();

        when(tavoloRepository.findByNumeroTavolo(numeroEsistente)).thenReturn(Optional.of(tavoloOccupato));

        Optional<Tavolo> foundTavolo = tavoloService.getTavoloByNumero(numeroEsistente);

        assertTrue(foundTavolo.isPresent());
        assertEquals(tavoloOccupato, foundTavolo.get());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroEsistente);
    }

    @Test
    void testGetTavoloByNumero_NonEsistente() {
        int numeroNonEsistente = 999;

        when(tavoloRepository.findByNumeroTavolo(numeroNonEsistente)).thenReturn(Optional.empty());

        Optional<Tavolo> foundTavolo = tavoloService.getTavoloByNumero(numeroNonEsistente);

        assertFalse(foundTavolo.isPresent());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroNonEsistente);
    }

    @Test
    void testGetAllTavoli_ListaNonVuota() {
        List<Tavolo> allTavoli = Arrays.asList(tavoloLiberoGrande, tavoloOccupato, tavoloRiservato);
        when(tavoloRepository.findAll()).thenReturn(allTavoli);

        List<Tavolo> result = tavoloService.getAllTavoli();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(3, result.size());
        assertTrue(result.contains(tavoloLiberoGrande));
        verify(tavoloRepository, times(1)).findAll();
    }

    @Test
    void testGetAllTavoli_ListaVuota() {
        when(tavoloRepository.findAll()).thenReturn(Collections.emptyList());

        List<Tavolo> result = tavoloService.getAllTavoli();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(tavoloRepository, times(1)).findAll();
    }

    @Test
    void testAggiornaStatoTavolo_Successo() {
        int numeroTavolo = tavoloLiberoGrande.getNumeroTavolo();
        String nuovoStato = Tavolo.STATO_OCCUPATO;

        when(tavoloRepository.findByNumeroTavolo(numeroTavolo)).thenReturn(Optional.of(tavoloLiberoGrande));
        when(tavoloRepository.save(any(Tavolo.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Tavolo updatedTavolo = tavoloService.aggiornaStatoTavolo(numeroTavolo, nuovoStato);

        assertNotNull(updatedTavolo);
        assertEquals(numeroTavolo, updatedTavolo.getNumeroTavolo());
        assertEquals(nuovoStato, updatedTavolo.getStato());
        assertTrue(updatedTavolo.isOccupato());

        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavolo);
        verify(tavoloRepository, times(1)).save(tavoloLiberoGrande);
    }

    @Test
    void testAggiornaStatoTavolo_TavoloNonTrovato_ThrowsException() {
        int numeroTavoloNonEsistente = 999;
        String nuovoStato = Tavolo.STATO_OCCUPATO;

        when(tavoloRepository.findByNumeroTavolo(numeroTavoloNonEsistente)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                tavoloService.aggiornaStatoTavolo(numeroTavoloNonEsistente, nuovoStato));

        assertEquals("Tavolo non trovato con numero: " + numeroTavoloNonEsistente, thrown.getMessage());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavoloNonEsistente);
        verify(tavoloRepository, never()).save(any(Tavolo.class));
    }

    @Test
    void testGetTavoliDisponibiliPerPosti_Trovati() {
        int postiRichiesti = 4;
        when(tavoloRepository.findByNumPostiAndStato(postiRichiesti, Tavolo.STATO_LIBERO))
                .thenReturn(Arrays.asList(tavoloLiberoGrande));

        List<Tavolo> result = tavoloService.getTavoliDisponibiliPerPosti(postiRichiesti);

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(1, result.size());
        assertTrue(result.contains(tavoloLiberoGrande));
        verify(tavoloRepository, times(1)).findByNumPostiAndStato(postiRichiesti, Tavolo.STATO_LIBERO);
    }

    @Test
    void testGetTavoliDisponibiliPerPosti_NessunTavoloTrovato() {
        int postiRichiesti = 10;

        when(tavoloRepository.findByNumPostiAndStato(postiRichiesti, Tavolo.STATO_LIBERO))
                .thenReturn(Collections.emptyList());

        List<Tavolo> result = tavoloService.getTavoliDisponibiliPerPosti(postiRichiesti);

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(tavoloRepository, times(1)).findByNumPostiAndStato(postiRichiesti, Tavolo.STATO_LIBERO);
    }

    @Test
    void testEliminaTavolo_Successo_Libero() {
        int numeroTavoloDaEliminare = tavoloLiberoPiccolo.getNumeroTavolo();
        doNothing().when(tavoloRepository).deleteById(numeroTavoloDaEliminare);

        when(tavoloRepository.findByNumeroTavolo(numeroTavoloDaEliminare)).thenReturn(Optional.of(tavoloLiberoPiccolo));

        tavoloService.eliminaTavolo(numeroTavoloDaEliminare);

        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavoloDaEliminare);
        verify(tavoloRepository, times(1)).deleteById(numeroTavoloDaEliminare);
    }

    @Test
    void testEliminaTavolo_TavoloNonTrovato_ThrowsException() {
        int numeroTavoloNonEsistente = 999;

        when(tavoloRepository.findByNumeroTavolo(numeroTavoloNonEsistente)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                tavoloService.eliminaTavolo(numeroTavoloNonEsistente));

        assertEquals("Tavolo non trovato con numero: " + numeroTavoloNonEsistente, thrown.getMessage());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavoloNonEsistente);
        verify(tavoloRepository, never()).deleteById(anyInt());
    }

    @Test
    void testEliminaTavolo_TavoloOccupato_ThrowsException() {
        int numeroTavoloOccupato = tavoloOccupato.getNumeroTavolo();

        when(tavoloRepository.findByNumeroTavolo(numeroTavoloOccupato)).thenReturn(Optional.of(tavoloOccupato));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () ->
                tavoloService.eliminaTavolo(numeroTavoloOccupato));

        assertEquals("Impossibile eliminare il tavolo " + numeroTavoloOccupato + " perché è occupato.", thrown.getMessage());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(numeroTavoloOccupato);
        verify(tavoloRepository, never()).deleteById(anyInt());
    }

    @Test
    void testEliminaTavolo_NumeroNonValido_ThrowsException() {
        int numeroTavoloNonValido = 0;

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                tavoloService.eliminaTavolo(numeroTavoloNonValido));

        assertEquals("Numero Tavolo non valido per l'eliminazione.", thrown.getMessage());
        verifyNoInteractions(tavoloRepository);
    }
}
