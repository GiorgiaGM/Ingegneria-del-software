package org.example.service;

import org.example.model.Cliente;
import org.example.model.FidelityCard;
import org.example.model.Ordine;
import org.example.model.Pagamento;
import org.example.model.Tavolo;
import org.example.repository.FidelityCardRepository;
import org.example.repository.OrdineRepository;
import org.example.repository.PagamentoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PagamentoServiceTest {

    @Mock
    private PagamentoRepository pagamentoRepository;
    @Mock
    private OrdineRepository ordineRepository;
    @Mock
    private FidelityCardRepository fidelityCardRepository;
    @Mock
    private FidelityCardService fidelityCardService;
    @Mock
    private OrdineService ordineService;

    @InjectMocks
    private PagamentoService pagamentoService;
    private Cliente testCliente;
    private Tavolo testTavolo;
    private Ordine testOrdineServito;
    private Ordine testOrdinePronto;
    private Ordine testOrdineInPreparazione;
    private FidelityCard testFidelityCard;
    private Pagamento testPagamento1;
    private Pagamento testPagamento2;

    @BeforeEach
    void setUp() {
        testCliente = new Cliente(1, "Mario", "Rossi", "mario.rossi@example.com");
        testTavolo = new Tavolo(1, 4, Tavolo.STATO_OCCUPATO);
        testOrdineServito = new Ordine(101, testCliente, testTavolo, OrdineService.STATO_SERVITO);
        testOrdinePronto = new Ordine(102, testCliente, testTavolo, OrdineService.STATO_PRONTO);
        testOrdineInPreparazione = new Ordine(103, testCliente, testTavolo, OrdineService.STATO_IN_PREPARAZIONE);

        testFidelityCard = new FidelityCard(1, testCliente, 100);        testPagamento1 = new Pagamento(1, testOrdineServito, 50.0, LocalDateTime.now().minusHours(1), null);
        testPagamento2 = new Pagamento(2, testOrdinePronto, 30.0, LocalDateTime.now().minusMinutes(30), testFidelityCard);

        reset(pagamentoRepository, ordineRepository, fidelityCardRepository, fidelityCardService, ordineService);
    }

    @Test
    void testRegistraPagamento_SuccessoConFidelityCard() {
        double importoPagamento = 45.0;
        int idFidelityCard = testFidelityCard.getIdCard();

        when(ordineRepository.findById(testOrdineServito.getIdOrdine())).thenReturn(Optional.of(testOrdineServito));
        when(fidelityCardRepository.findById(idFidelityCard)).thenReturn(Optional.of(testFidelityCard));
        when(pagamentoRepository.getNextId()).thenReturn(1);
        when(pagamentoRepository.save(any(Pagamento.class))).thenAnswer(invocation -> {
            Pagamento savedPagamento = invocation.getArgument(0);
            assertEquals(1, savedPagamento.getId());
            assertEquals(testOrdineServito.getIdOrdine(), savedPagamento.getOrdine().getIdOrdine());
            assertEquals(importoPagamento, savedPagamento.getTotale(), 0.001);
            assertNotNull(savedPagamento.getDataPagamento());
            assertEquals(testFidelityCard.getIdCard(), savedPagamento.getFidelityCard().getIdCard());
            return savedPagamento;
        });

        Pagamento nuovoPagamento = pagamentoService.registraPagamento(testOrdineServito.getIdOrdine(), importoPagamento, Optional.of(idFidelityCard));

        assertNotNull(nuovoPagamento);
        assertEquals(importoPagamento, nuovoPagamento.getTotale(), 0.001);
        assertEquals(testOrdineServito.getIdOrdine(), nuovoPagamento.getOrdine().getIdOrdine());
        assertEquals(testFidelityCard.getIdCard(), nuovoPagamento.getFidelityCard().getIdCard());

        verify(ordineRepository, times(1)).findById(testOrdineServito.getIdOrdine());
        verify(fidelityCardRepository, times(1)).findById(idFidelityCard);
        verify(fidelityCardService, times(1)).aggiungiPunti(idFidelityCard, 4);
        verify(pagamentoRepository, times(1)).getNextId();
        verify(pagamentoRepository, times(1)).save(any(Pagamento.class));
        verify(ordineService, times(1)).aggiornaStatoOrdine(testOrdineServito.getIdOrdine(), OrdineService.STATO_COMPLETATO);
    }

    @Test
    void testRegistraPagamento_SuccessoSenzaFidelityCard() {
        double importoPagamento = 25.0;

        when(ordineRepository.findById(testOrdinePronto.getIdOrdine())).thenReturn(Optional.of(testOrdinePronto));
        when(pagamentoRepository.getNextId()).thenReturn(1);
        when(pagamentoRepository.save(any(Pagamento.class))).thenAnswer(invocation -> {
            Pagamento savedPagamento = invocation.getArgument(0);
            assertEquals(1, savedPagamento.getId());
            assertEquals(testOrdinePronto.getIdOrdine(), savedPagamento.getOrdine().getIdOrdine());
            assertEquals(importoPagamento, savedPagamento.getTotale(), 0.001);
            assertNotNull(savedPagamento.getDataPagamento());
            assertNull(savedPagamento.getFidelityCard());
            return savedPagamento;
        });

        Pagamento nuovoPagamento = pagamentoService.registraPagamento(testOrdinePronto.getIdOrdine(), importoPagamento, Optional.empty());

        assertNotNull(nuovoPagamento);
        assertEquals(importoPagamento, nuovoPagamento.getTotale(), 0.001);
        assertNull(nuovoPagamento.getFidelityCard());

        verify(ordineRepository, times(1)).findById(testOrdinePronto.getIdOrdine());
        verifyNoInteractions(fidelityCardRepository);
        verifyNoInteractions(fidelityCardService);
        verify(pagamentoRepository, times(1)).getNextId();
        verify(pagamentoRepository, times(1)).save(any(Pagamento.class));
        verify(ordineService, times(1)).aggiornaStatoOrdine(testOrdinePronto.getIdOrdine(), OrdineService.STATO_COMPLETATO);
    }

    @Test
    void testRegistraPagamento_OrdineNonTrovato_ThrowsException() {
        int nonExistingOrderId = 999;
        when(ordineRepository.findById(nonExistingOrderId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            pagamentoService.registraPagamento(nonExistingOrderId, 100.0, Optional.empty());
        });

        assertEquals("Ordine non trovato con ID: " + nonExistingOrderId, thrown.getMessage());
        verify(ordineRepository, times(1)).findById(nonExistingOrderId);
        verifyNoMoreInteractions(pagamentoRepository, fidelityCardRepository, fidelityCardService, ordineService);
    }

    @Test
    void testRegistraPagamento_OrdineStatoNonValido_ThrowsException() {
        when(ordineRepository.findById(testOrdineInPreparazione.getIdOrdine())).thenReturn(Optional.of(testOrdineInPreparazione));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () -> {
            pagamentoService.registraPagamento(testOrdineInPreparazione.getIdOrdine(), 100.0, Optional.empty());
        });

        assertEquals("L'ordine " + testOrdineInPreparazione.getIdOrdine() + " non è nello stato corretto per il pagamento (" + OrdineService.STATO_IN_PREPARAZIONE + "). Deve essere '" + OrdineService.STATO_SERVITO + "' o '" + OrdineService.STATO_PRONTO + "'.", thrown.getMessage());
        verify(ordineRepository, times(1)).findById(testOrdineInPreparazione.getIdOrdine());
        verifyNoMoreInteractions(pagamentoRepository, fidelityCardRepository, fidelityCardService, ordineService);
    }

    @Test
    void testRegistraPagamento_ImportoNonValido_ThrowsException() {
        when(ordineRepository.findById(testOrdineServito.getIdOrdine())).thenReturn(Optional.of(testOrdineServito));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            pagamentoService.registraPagamento(testOrdineServito.getIdOrdine(), 0.0, Optional.empty());
        });

        assertEquals("L'importo del pagamento deve essere positivo.", thrown.getMessage());
        verify(ordineRepository, times(1)).findById(testOrdineServito.getIdOrdine());
        verifyNoMoreInteractions(pagamentoRepository, fidelityCardRepository, fidelityCardService, ordineService);
    }

    @Test
    void testRegistraPagamento_FidelityCardNonTrovata_ThrowsException() {
        int nonExistingFidelityCardId = 99;
        when(ordineRepository.findById(testOrdineServito.getIdOrdine())).thenReturn(Optional.of(testOrdineServito));
        when(fidelityCardRepository.findById(nonExistingFidelityCardId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            pagamentoService.registraPagamento(testOrdineServito.getIdOrdine(), 50.0, Optional.of(nonExistingFidelityCardId));
        });

        assertEquals("Fidelity Card non trovata con ID: " + nonExistingFidelityCardId, thrown.getMessage());
        verify(ordineRepository, times(1)).findById(testOrdineServito.getIdOrdine());
        verify(fidelityCardRepository, times(1)).findById(nonExistingFidelityCardId);
        verifyNoMoreInteractions(pagamentoRepository, fidelityCardService, ordineService);
    }

    @Test
    void testGetPagamentoById_Esistente() {
        when(pagamentoRepository.findById(testPagamento1.getId())).thenReturn(Optional.of(testPagamento1));

        Optional<Pagamento> foundPagamento = pagamentoService.getPagamentoById(testPagamento1.getId());

        assertTrue(foundPagamento.isPresent());
        assertEquals(testPagamento1, foundPagamento.get());
        verify(pagamentoRepository, times(1)).findById(testPagamento1.getId());
    }

    @Test
    void testGetPagamentoById_NonEsistente() {
        int nonExistingPagamentoId = 999;
        when(pagamentoRepository.findById(nonExistingPagamentoId)).thenReturn(Optional.empty());

        Optional<Pagamento> foundPagamento = pagamentoService.getPagamentoById(nonExistingPagamentoId);

        assertFalse(foundPagamento.isPresent());
        verify(pagamentoRepository, times(1)).findById(nonExistingPagamentoId);
    }

    @Test
    void testGetAllPagamenti_ListaNonVuota() {
        when(pagamentoRepository.findAll()).thenReturn(Arrays.asList(testPagamento1, testPagamento2));

        List<Pagamento> allPagamenti = pagamentoService.getAllPagamenti();

        assertNotNull(allPagamenti);
        assertEquals(2, allPagamenti.size());
        assertTrue(allPagamenti.contains(testPagamento1));
        assertTrue(allPagamenti.contains(testPagamento2));
        verify(pagamentoRepository, times(1)).findAll();
    }

    @Test
    void testGetAllPagamenti_ListaVuota() {
        when(pagamentoRepository.findAll()).thenReturn(Collections.emptyList());

        List<Pagamento> allPagamenti = pagamentoService.getAllPagamenti();

        assertNotNull(allPagamenti);
        assertTrue(allPagamenti.isEmpty());
        verify(pagamentoRepository, times(1)).findAll();
    }
}