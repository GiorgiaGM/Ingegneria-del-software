package org.example.service;

import org.example.model.Ordine;
import org.example.model.Piatto;
import org.example.model.RigaOrdine;
import org.example.model.Variazione;
import org.example.repository.OrdineRepository;
import org.example.repository.PiattoRepository;
import org.example.repository.RigaOrdineRepository;
import org.example.repository.VariazioneRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.ArrayList;

import org.example.model.Ingrediente;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;


import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class RigaOrdineServiceTest {

    @Mock
    private RigaOrdineRepository rigaOrdineRepository;
    @Mock
    private PiattoRepository piattoRepository;
    @Mock
    private VariazioneRepository variazioneRepository;
    @Mock
    private OrdineRepository ordineRepository;

    @InjectMocks
    private RigaOrdineService rigaOrdineService;
    private Ordine testOrdine;
    private Piatto testPiatto;
    private Piatto testPiatto2;
    private Variazione testVariazione1;
    private Variazione testVariazione2;
    private RigaOrdine testRigaOrdine;

    @BeforeEach
    void setUp() {
        testOrdine = new Ordine(1, null, null, "IN_PREPARAZIONE");
        testPiatto = new Piatto(101, "Pizza Margherita", "Pizza", 8.50f, new ArrayList<Ingrediente>());
        testPiatto2 = new Piatto(102, "Pasta al Pesto", "Primo", 10.00f, new ArrayList<Ingrediente>());
        testVariazione1 = new Variazione(201, "Extra Mozzarella", 1.50f);
        testVariazione2 = new Variazione(202, "Senza Cipolla", 0.00f);

        testRigaOrdine = new RigaOrdine(
                1,
                2,
                (float) testPiatto.getPrezzo(),
                testPiatto,
                Arrays.asList(testVariazione1),
                "Ben cotta",
                testOrdine
        );
        reset(rigaOrdineRepository, piattoRepository, variazioneRepository, ordineRepository);
    }

    @Test
    void testCreaRigaOrdine_Successo_ConVariazioni() {
        int idOrdine = testOrdine.getIdOrdine();
        int piattoId = testPiatto.getId();
        int quantita = 2;
        String note = "Ben cotta";
        List<Integer> variazioniIds = Arrays.asList(testVariazione1.getId(), testVariazione2.getId());
        int nextRigaId = 2;

        when(ordineRepository.findById(idOrdine)).thenReturn(Optional.of(testOrdine));
        when(piattoRepository.findById(piattoId)).thenReturn(Optional.of(testPiatto));
        when(variazioneRepository.findById(testVariazione1.getId())).thenReturn(Optional.of(testVariazione1));
        when(variazioneRepository.findById(testVariazione2.getId())).thenReturn(Optional.of(testVariazione2));
        when(rigaOrdineRepository.getNextId()).thenReturn(nextRigaId);
        when(rigaOrdineRepository.save(any(RigaOrdine.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(ordineRepository.save(any(Ordine.class))).thenAnswer(invocation -> invocation.getArgument(0));

        RigaOrdine createdRiga = rigaOrdineService.creaRigaOrdine(idOrdine, piattoId, quantita, note, variazioniIds);

        assertNotNull(createdRiga);
        assertEquals(nextRigaId, createdRiga.getId());
        assertEquals(quantita, createdRiga.getQuantita());
        assertEquals(testPiatto.getPrezzo(), createdRiga.getPrezzoUnitario(), 0.001);
        assertEquals(testPiatto, createdRiga.getPiatto());
        assertEquals(2, createdRiga.getVariazioni().size());
        assertTrue(createdRiga.getVariazioni().contains(testVariazione1));
        assertTrue(createdRiga.getVariazioni().contains(testVariazione2));
        assertEquals(note, createdRiga.getNote());
        assertEquals(testOrdine, createdRiga.getOrdine());

        verify(ordineRepository, times(1)).findById(idOrdine);
        verify(piattoRepository, times(1)).findById(piattoId);
        verify(variazioneRepository, times(1)).findById(testVariazione1.getId());
        verify(variazioneRepository, times(1)).findById(testVariazione2.getId());
        verify(rigaOrdineRepository, times(1)).getNextId();
        verify(rigaOrdineRepository, times(1)).save(createdRiga);
        verify(ordineRepository, times(1)).save(testOrdine);
        assertTrue(testOrdine.getRigheOrdine().contains(createdRiga));
    }

    @Test
    void testCreaRigaOrdine_Successo_SenzaVariazioni() {
        int idOrdine = testOrdine.getIdOrdine();
        int piattoId = testPiatto.getId();
        int quantita = 1;
        String note = "Senza nulla";
        int nextRigaId = 3;
        when(ordineRepository.findById(idOrdine)).thenReturn(Optional.of(testOrdine));
        when(piattoRepository.findById(piattoId)).thenReturn(Optional.of(testPiatto));
        when(rigaOrdineRepository.getNextId()).thenReturn(nextRigaId);
        when(rigaOrdineRepository.save(any(RigaOrdine.class))).thenAnswer(invocation -> invocation.getArgument(0));
        when(ordineRepository.save(any(Ordine.class))).thenAnswer(invocation -> invocation.getArgument(0));

        RigaOrdine createdRiga = rigaOrdineService.creaRigaOrdine(idOrdine, piattoId, quantita, note, null);

        assertNotNull(createdRiga);
        assertEquals(nextRigaId, createdRiga.getId());
        assertEquals(quantita, createdRiga.getQuantita());
        assertTrue(createdRiga.getVariazioni().isEmpty());
        assertEquals(note, createdRiga.getNote());
        assertEquals(testOrdine, createdRiga.getOrdine());

        verify(ordineRepository, times(1)).findById(idOrdine);
        verify(piattoRepository, times(1)).findById(piattoId);
        verify(variazioneRepository, never()).findById(anyInt());
        verify(rigaOrdineRepository, times(1)).getNextId();
        verify(rigaOrdineRepository, times(1)).save(createdRiga);
        verify(ordineRepository, times(1)).save(testOrdine);
        assertTrue(testOrdine.getRigheOrdine().contains(createdRiga));
    }

    @Test
    void testCreaRigaOrdine_QuantitaZero_ThrowsException() {
        int idOrdine = testOrdine.getIdOrdine();
        int piattoId = testPiatto.getId();
        int quantita = 0;

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.creaRigaOrdine(idOrdine, piattoId, quantita, "Note", null));

        assertEquals("La quantità deve essere maggiore di zero.", thrown.getMessage());
        verifyNoInteractions(rigaOrdineRepository, piattoRepository, variazioneRepository, ordineRepository);
    }

    @Test
    void testCreaRigaOrdine_OrdineNonTrovato_ThrowsException() {
        int idOrdine = 999;
        int piattoId = testPiatto.getId();
        int quantita = 1;

        when(ordineRepository.findById(idOrdine)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.creaRigaOrdine(idOrdine, piattoId, quantita, "Note", null));

        assertEquals("Ordine non trovato con ID: " + idOrdine, thrown.getMessage());
        verify(ordineRepository, times(1)).findById(idOrdine);
        verifyNoInteractions(rigaOrdineRepository, piattoRepository, variazioneRepository);
    }

    @Test
    void testCreaRigaOrdine_PiattoNonTrovato_ThrowsException() {
        int idOrdine = testOrdine.getIdOrdine();
        int piattoId = 999;
        int quantita = 1;

        when(ordineRepository.findById(idOrdine)).thenReturn(Optional.of(testOrdine));
        when(piattoRepository.findById(piattoId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.creaRigaOrdine(idOrdine, piattoId, quantita, "Note", null));

        assertEquals("Piatto non trovato con ID: " + piattoId, thrown.getMessage());
        verify(ordineRepository, times(1)).findById(idOrdine);
        verify(piattoRepository, times(1)).findById(piattoId);
        verifyNoInteractions(rigaOrdineRepository, variazioneRepository);
    }

    @Test
    void testCreaRigaOrdine_VariazioneNonTrovata_ThrowsException() {
        int idOrdine = testOrdine.getIdOrdine();
        int piattoId = testPiatto.getId();
        int quantita = 1;
        List<Integer> variazioniIds = Arrays.asList(testVariazione1.getId(), 999);

        when(ordineRepository.findById(idOrdine)).thenReturn(Optional.of(testOrdine));
        when(piattoRepository.findById(piattoId)).thenReturn(Optional.of(testPiatto));
        when(variazioneRepository.findById(testVariazione1.getId())).thenReturn(Optional.of(testVariazione1));
        when(variazioneRepository.findById(999)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.creaRigaOrdine(idOrdine, piattoId, quantita, "Note", variazioniIds));

        assertEquals("Variazione non trovata con ID: 999", thrown.getMessage());
        verify(ordineRepository, times(1)).findById(idOrdine);
        verify(piattoRepository, times(1)).findById(piattoId);
        verify(variazioneRepository, times(1)).findById(testVariazione1.getId());
        verify(variazioneRepository, times(1)).findById(999);
        verifyNoInteractions(rigaOrdineRepository);
    }

    @Test
    void testGetRigaOrdineById_Esistente() {
        when(rigaOrdineRepository.findById(testRigaOrdine.getId())).thenReturn(Optional.of(testRigaOrdine));

        Optional<RigaOrdine> foundRiga = rigaOrdineService.getRigaOrdineById(testRigaOrdine.getId());

        assertTrue(foundRiga.isPresent());
        assertEquals(testRigaOrdine, foundRiga.get());
        verify(rigaOrdineRepository, times(1)).findById(testRigaOrdine.getId());
    }

    @Test
    void testGetRigaOrdineById_NonEsistente() {
        when(rigaOrdineRepository.findById(999)).thenReturn(Optional.empty());

        Optional<RigaOrdine> foundRiga = rigaOrdineService.getRigaOrdineById(999);

        assertFalse(foundRiga.isPresent());
        verify(rigaOrdineRepository, times(1)).findById(999);
    }

    @Test
    void testGetAllRigheOrdine_ListaNonVuota() {
        List<RigaOrdine> allRighe = Arrays.asList(testRigaOrdine,
                new RigaOrdine(2, 1, 10.0f, testPiatto2, null, "Senza variazioni", testOrdine));
        when(rigaOrdineRepository.findAll()).thenReturn(allRighe);

        List<RigaOrdine> result = rigaOrdineService.getAllRigheOrdine();

        assertNotNull(result);
        assertFalse(result.isEmpty());
        assertEquals(2, result.size());
        assertTrue(result.contains(testRigaOrdine));
        verify(rigaOrdineRepository, times(1)).findAll();
    }

    @Test
    void testGetAllRigheOrdine_ListaVuota() {
        when(rigaOrdineRepository.findAll()).thenReturn(Collections.emptyList());

        List<RigaOrdine> result = rigaOrdineService.getAllRigheOrdine();

        assertNotNull(result);
        assertTrue(result.isEmpty());
        verify(rigaOrdineRepository, times(1)).findAll();
    }

    @Test
    void testAggiornaQuantitaRigaOrdine_Successo() {
        int rigaId = testRigaOrdine.getId();
        int nuovaQuantita = 5;

        when(rigaOrdineRepository.findById(rigaId)).thenReturn(Optional.of(testRigaOrdine));
        when(rigaOrdineRepository.save(any(RigaOrdine.class))).thenAnswer(invocation -> invocation.getArgument(0));

        RigaOrdine updatedRiga = rigaOrdineService.aggiornaQuantitaRigaOrdine(rigaId, nuovaQuantita);

        assertNotNull(updatedRiga);
        assertEquals(nuovaQuantita, updatedRiga.getQuantita());
        verify(rigaOrdineRepository, times(1)).findById(rigaId);
        verify(rigaOrdineRepository, times(1)).save(testRigaOrdine);
    }

    @Test
    void testAggiornaQuantitaRigaOrdine_RigaNonTrovata_ThrowsException() {
        int rigaId = 999;
        int nuovaQuantita = 5;

        when(rigaOrdineRepository.findById(rigaId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.aggiornaQuantitaRigaOrdine(rigaId, nuovaQuantita));

        assertEquals("Riga Ordine non trovata con ID: " + rigaId, thrown.getMessage());
        verify(rigaOrdineRepository, times(1)).findById(rigaId);
        verify(rigaOrdineRepository, never()).save(any(RigaOrdine.class));
    }

    @Test
    void testAggiornaQuantitaRigaOrdine_NuovaQuantitaNonValida_ThrowsException() {
        int rigaId = testRigaOrdine.getId();
        int nuovaQuantita = 0;

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.aggiornaQuantitaRigaOrdine(rigaId, nuovaQuantita));

        assertEquals("La nuova quantità deve essere maggiore di zero.", thrown.getMessage());
        verifyNoInteractions(rigaOrdineRepository);
    }

    @Test
    void testAggiungiVariazioneARigaOrdine_Successo() {
        RigaOrdine rigaSenzaVariazione = new RigaOrdine(testRigaOrdine.getId(), 1, 8.0f, testPiatto, new ArrayList<>(), "Note", testOrdine);
        Variazione nuovaVariazione = new Variazione(203, "Senza Lattosio", 0.00f);

        when(rigaOrdineRepository.findById(rigaSenzaVariazione.getId())).thenReturn(Optional.of(rigaSenzaVariazione));
        when(variazioneRepository.findById(nuovaVariazione.getId())).thenReturn(Optional.of(nuovaVariazione));
        when(rigaOrdineRepository.save(any(RigaOrdine.class))).thenAnswer(invocation -> invocation.getArgument(0));

        RigaOrdine updatedRiga = rigaOrdineService.aggiungiVariazioneARigaOrdine(rigaSenzaVariazione.getId(), nuovaVariazione.getId());

        assertNotNull(updatedRiga);
        assertTrue(updatedRiga.getVariazioni().contains(nuovaVariazione));
        assertEquals(1, updatedRiga.getVariazioni().size());
        verify(rigaOrdineRepository, times(1)).findById(rigaSenzaVariazione.getId());
        verify(variazioneRepository, times(1)).findById(nuovaVariazione.getId());
        verify(rigaOrdineRepository, times(1)).save(rigaSenzaVariazione);
    }

    @Test
    void testAggiungiVariazioneARigaOrdine_VariazioneGiaPresente_NonAggiunge() {
        RigaOrdine rigaConVariazione = new RigaOrdine(testRigaOrdine.getId(), 1, 8.0f, testPiatto, Arrays.asList(testVariazione1), "Note", testOrdine);
        int initialVariazioniSize = rigaConVariazione.getVariazioni().size();

        when(rigaOrdineRepository.findById(rigaConVariazione.getId())).thenReturn(Optional.of(rigaConVariazione));
        when(variazioneRepository.findById(testVariazione1.getId())).thenReturn(Optional.of(testVariazione1));
        when(rigaOrdineRepository.save(any(RigaOrdine.class))).thenAnswer(invocation -> invocation.getArgument(0));

        RigaOrdine updatedRiga = rigaOrdineService.aggiungiVariazioneARigaOrdine(rigaConVariazione.getId(), testVariazione1.getId());

        assertNotNull(updatedRiga);
        assertTrue(updatedRiga.getVariazioni().contains(testVariazione1));
        assertEquals(initialVariazioniSize, updatedRiga.getVariazioni().size());
        verify(rigaOrdineRepository, times(1)).findById(rigaConVariazione.getId());
        verify(variazioneRepository, times(1)).findById(testVariazione1.getId());
        verify(rigaOrdineRepository, times(1)).save(rigaConVariazione);
    }


    @Test
    void testAggiungiVariazioneARigaOrdine_RigaNonTrovata_ThrowsException() {
        int rigaId = 999;
        int variazioneId = testVariazione1.getId();

        when(rigaOrdineRepository.findById(rigaId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.aggiungiVariazioneARigaOrdine(rigaId, variazioneId));

        assertEquals("Riga Ordine non trovata con ID: " + rigaId, thrown.getMessage());
        verify(rigaOrdineRepository, times(1)).findById(rigaId);
        verifyNoInteractions(variazioneRepository);
    }

    @Test
    void testAggiungiVariazioneARigaOrdine_VariazioneNonTrovata_ThrowsException() {
        int rigaId = testRigaOrdine.getId();
        int variazioneId = 999;

        when(rigaOrdineRepository.findById(rigaId)).thenReturn(Optional.of(testRigaOrdine));
        when(variazioneRepository.findById(variazioneId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.aggiungiVariazioneARigaOrdine(rigaId, variazioneId));

        assertEquals("Variazione non trovata con ID: " + variazioneId, thrown.getMessage());
        verify(rigaOrdineRepository, times(1)).findById(rigaId);
        verify(variazioneRepository, times(1)).findById(variazioneId);
        verify(rigaOrdineRepository, never()).save(any(RigaOrdine.class));
    }

    @Test
    void testRimuoviVariazioneDaRigaOrdine_Successo() {
        int rigaId = testRigaOrdine.getId();
        int variazioneId = testVariazione1.getId();

        when(rigaOrdineRepository.findById(rigaId)).thenReturn(Optional.of(testRigaOrdine));
        when(variazioneRepository.findById(variazioneId)).thenReturn(Optional.of(testVariazione1));
        when(rigaOrdineRepository.save(any(RigaOrdine.class))).thenAnswer(invocation -> invocation.getArgument(0));

        RigaOrdine updatedRiga = rigaOrdineService.rimuoviVariazioneDaRigaOrdine(rigaId, variazioneId);

        assertNotNull(updatedRiga);
        assertFalse(updatedRiga.getVariazioni().contains(testVariazione1));
        assertTrue(updatedRiga.getVariazioni().isEmpty());
        verify(rigaOrdineRepository, times(1)).findById(rigaId);
        verify(variazioneRepository, times(1)).findById(variazioneId);
        verify(rigaOrdineRepository, times(1)).save(testRigaOrdine);
    }

    @Test
    void testRimuoviVariazioneDaRigaOrdine_VariazioneNonPresente_NonRimuove() {
        RigaOrdine rigaSenzaVariazione = new RigaOrdine(testRigaOrdine.getId(), 1, 8.0f, testPiatto, Arrays.asList(testVariazione1), "Note", testOrdine);
        int initialVariazioniSize = rigaSenzaVariazione.getVariazioni().size();

        when(rigaOrdineRepository.findById(rigaSenzaVariazione.getId())).thenReturn(Optional.of(rigaSenzaVariazione));
        when(variazioneRepository.findById(testVariazione2.getId())).thenReturn(Optional.of(testVariazione2));
        when(rigaOrdineRepository.save(any(RigaOrdine.class))).thenAnswer(invocation -> invocation.getArgument(0));

        RigaOrdine updatedRiga = rigaOrdineService.rimuoviVariazioneDaRigaOrdine(rigaSenzaVariazione.getId(), testVariazione2.getId());

        assertNotNull(updatedRiga);
        assertFalse(updatedRiga.getVariazioni().contains(testVariazione2));
        assertEquals(initialVariazioniSize, updatedRiga.getVariazioni().size());
        verify(rigaOrdineRepository, times(1)).findById(rigaSenzaVariazione.getId());
        verify(variazioneRepository, times(1)).findById(testVariazione2.getId());
        verify(rigaOrdineRepository, times(1)).save(rigaSenzaVariazione);
    }


    @Test
    void testRimuoviVariazioneDaRigaOrdine_RigaNonTrovata_ThrowsException() {
        int rigaId = 999;
        int variazioneId = testVariazione1.getId();

        when(rigaOrdineRepository.findById(rigaId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.rimuoviVariazioneDaRigaOrdine(rigaId, variazioneId));

        assertEquals("Riga Ordine non trovata con ID: " + rigaId, thrown.getMessage());
        verify(rigaOrdineRepository, times(1)).findById(rigaId);
        verifyNoInteractions(variazioneRepository);
    }

    @Test
    void testRimuoviVariazioneDaRigaOrdine_VariazioneNonTrovata_ThrowsException() {
        int rigaId = testRigaOrdine.getId();
        int variazioneId = 999;

        when(rigaOrdineRepository.findById(rigaId)).thenReturn(Optional.of(testRigaOrdine));
        when(variazioneRepository.findById(variazioneId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.rimuoviVariazioneDaRigaOrdine(rigaId, variazioneId));

        assertEquals("Variazione non trovata con ID: " + variazioneId, thrown.getMessage());
        verify(rigaOrdineRepository, times(1)).findById(rigaId);
        verify(variazioneRepository, times(1)).findById(variazioneId);
        verify(rigaOrdineRepository, never()).save(any(RigaOrdine.class));
    }

    @Test
    void testEliminaRigaOrdine_Successo() {
        int idToDelete = testRigaOrdine.getId();
        doNothing().when(rigaOrdineRepository).deleteById(idToDelete);

        rigaOrdineService.eliminaRigaOrdine(idToDelete);

        verify(rigaOrdineRepository, times(1)).deleteById(idToDelete);
    }

    @Test
    void testEliminaRigaOrdine_IdNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.eliminaRigaOrdine(0), "ID Riga Ordine non valido per l'eliminazione.");
        assertThrows(IllegalArgumentException.class, () ->
                rigaOrdineService.eliminaRigaOrdine(-5), "ID Riga Ordine non valido per l'eliminazione.");
        verifyNoInteractions(rigaOrdineRepository);
    }
}
