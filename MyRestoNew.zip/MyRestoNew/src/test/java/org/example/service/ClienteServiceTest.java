package org.example.service;

import org.example.model.Cliente;
import org.example.repository.ClienteRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

class ClienteServiceTest {

    private ClienteService clienteService;
    private ClienteRepository mockClienteRepository;
    private int nextId;

    @BeforeEach
    void setUp() {
        nextId = 1;
        mockClienteRepository = new ClienteRepository() {
            private final HashMap<Integer, Cliente> clients = new HashMap<>();

            @Override
            public Optional<Cliente> findById(Integer id) {
                return Optional.ofNullable(clients.get(id));
            }

            @Override
            public List<Cliente> findAll() {
                return new ArrayList<>(clients.values());
            }

            @Override
            public Cliente save(Cliente entity) {
                clients.put(entity.getId(), entity);
                return entity;
            }

            @Override
            public void deleteById(Integer id) {
                clients.remove(id);
            }

            @Override
            public Integer getNextId() {
                return nextId++;
            }

            @Override
            public Optional<Cliente> findByEmail(String email) {
                return clients.values().stream()
                        .filter(c -> c.getEmail().equals(email))
                        .findFirst();
            }

            @Override
            public List<Cliente> findByNomeContainsIgnoreCase(String nome) {
                return clients.values().stream()
                        .filter(c -> c.getNome().toLowerCase().contains(nome.toLowerCase()))
                        .collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
            }
        };
        clienteService = new ClienteService(mockClienteRepository);
    }


    @Test
    @DisplayName("Dovrebbe registrare un nuovo cliente con successo")
    void shouldRegisterNewClienteSuccessfully() {
        Cliente cliente = clienteService.registraNuovoCliente("Mario", "Rossi", "mario.rossi@example.com");

        assertNotNull(cliente);
        assertEquals("Mario", cliente.getNome());
        assertEquals("Rossi", cliente.getCognome());
        assertEquals("mario.rossi@example.com", cliente.getEmail());
        assertNotNull(cliente.getId());
        assertEquals(1, cliente.getId());
    }

    @Test
    @DisplayName("Dovrebbe lanciare eccezione se nome o cognome sono vuoti durante la registrazione")
    void shouldThrowExceptionIfNomeOrCognomeAreEmptyOnRegistration() {
        IllegalArgumentException thrownNome = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.registraNuovoCliente("", "Rossi", "test@example.com");
        });
        assertEquals("Nome e cognome del cliente non possono essere vuoti.", thrownNome.getMessage());

        IllegalArgumentException thrownCognome = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.registraNuovoCliente("Mario", " ", "test2@example.com");
        });
        assertEquals("Nome e cognome del cliente non possono essere vuoti.", thrownCognome.getMessage());
    }


    @Test
    @DisplayName("Dovrebbe lanciare eccezione se l'email non è valida durante la registrazione")
    void shouldThrowExceptionIfEmailIsInvalidOnRegistration() {
        IllegalArgumentException thrownNull = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.registraNuovoCliente("Mario", "Rossi", null);
        });
        assertEquals("Email non valida.", thrownNull.getMessage());

        IllegalArgumentException thrownNoAt = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.registraNuovoCliente("Mario", "Rossi", "mario.rossi.example.com");
        });
        assertEquals("Email non valida.", thrownNoAt.getMessage());
    }

    @Test
    @DisplayName("Dovrebbe lanciare eccezione se l'email esiste già durante la registrazione")
    void shouldThrowExceptionIfEmailAlreadyExistsOnRegistration() {
        clienteService.registraNuovoCliente("Mario", "Rossi", "mario.rossi@example.com");

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.registraNuovoCliente("Luigi", "Verdi", "mario.rossi@example.com");
        });

        assertEquals("Esiste già un cliente con questa email.", thrown.getMessage());
    }


    @Test
    @DisplayName("Dovrebbe trovare un cliente per ID")
    void shouldFindClienteById() {
        Cliente cliente = clienteService.registraNuovoCliente("Mario", "Rossi", "mario.rossi@example.com");
        Optional<Cliente> foundCliente = clienteService.getClienteById(cliente.getId());

        assertTrue(foundCliente.isPresent());
        assertEquals(cliente.getId(), foundCliente.get().getId());
        assertEquals("Mario", foundCliente.get().getNome());
    }

    @Test
    @DisplayName("Non dovrebbe trovare un cliente per ID inesistente")
    void shouldNotFindClienteByNonExistentId() {
        Optional<Cliente> foundCliente = clienteService.getClienteById(999);
        assertFalse(foundCliente.isPresent());
    }

    @Test
    @DisplayName("Dovrebbe trovare un cliente per email")
    void shouldFindClienteByEmail() {
        clienteService.registraNuovoCliente("Mario", "Rossi", "mario.rossi@example.com");
        Optional<Cliente> foundCliente = clienteService.getClienteByEmail("mario.rossi@example.com");

        assertTrue(foundCliente.isPresent());
        assertEquals("Mario", foundCliente.get().getNome());
    }

    @Test
    @DisplayName("Non dovrebbe trovare un cliente per email inesistente")
    void shouldNotFindClienteByNonExistentEmail() {
        Optional<Cliente> foundCliente = clienteService.getClienteByEmail("inesistente@example.com");
        assertFalse(foundCliente.isPresent());
    }

    @Test
    @DisplayName("Dovrebbe trovare tutti i clienti")
    void shouldFindAllClienti() {
        clienteService.registraNuovoCliente("Mario", "Rossi", "mario.rossi@example.com");
        clienteService.registraNuovoCliente("Luigi", "Verdi", "luigi.verdi@example.com");

        List<Cliente> clienti = clienteService.getAllClienti();
        assertEquals(2, clienti.size());
    }


    @Test
    @DisplayName("Dovrebbe aggiornare un cliente esistente")
    void shouldUpdateExistingCliente() {
        Cliente cliente = clienteService.registraNuovoCliente("Mario", "Rossi", "mario.rossi@example.com");
        // Aggiorniamo alcuni campi del cliente
        cliente.setNome("Paolo");
        cliente.setCognome("Bianchi");
        cliente.setEmail("paolo.bianchi@example.com");

        Cliente updatedCliente = clienteService.aggiornaCliente(cliente);

        assertNotNull(updatedCliente);
        assertEquals("Paolo", updatedCliente.getNome());
        assertEquals("Bianchi", updatedCliente.getCognome());
        assertEquals("paolo.bianchi@example.com", updatedCliente.getEmail());

        Optional<Cliente> foundCliente = clienteService.getClienteById(cliente.getId());
        assertTrue(foundCliente.isPresent());
        assertEquals("Paolo", foundCliente.get().getNome());
        assertEquals("paolo.bianchi@example.com", foundCliente.get().getEmail());
    }

    @Test
    @DisplayName("Dovrebbe lanciare eccezione se si tenta di aggiornare un cliente non valido")
    void shouldThrowExceptionWhenUpdatingInvalidCliente() {
        IllegalArgumentException thrownNull = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.aggiornaCliente(null);
        });
        assertEquals("Cliente non valido per l'aggiornamento.", thrownNull.getMessage());

        Cliente clienteConIdNonValido = new Cliente(0, "Nome", "Cognome", "email@test.com");
        IllegalArgumentException thrownInvalidId = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.aggiornaCliente(clienteConIdNonValido);
        });
        assertEquals("Cliente non valido per l'aggiornamento.", thrownInvalidId.getMessage());
    }

    @Test
    @DisplayName("Dovrebbe lanciare eccezione se l'email aggiornata esiste già per un altro cliente")
    void shouldThrowExceptionIfUpdatedEmailAlreadyExistsForAnotherClient() {
        clienteService.registraNuovoCliente("Mario", "Rossi", "mario.rossi@example.com");
        Cliente cliente2 = clienteService.registraNuovoCliente("Luigi", "Verdi", "luigi.verdi@example.com");

        cliente2.setEmail("mario.rossi@example.com");

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.aggiornaCliente(cliente2);
        });

        assertEquals("Email già associata ad un altro cliente.", thrown.getMessage());
    }


    @Test
    @DisplayName("Dovrebbe eliminare un cliente per ID")
    void shouldDeleteClienteById() {
        Cliente cliente = clienteService.registraNuovoCliente("Mario", "Rossi", "mario.rossi@example.com");
        int clienteId = cliente.getId();

        clienteService.eliminaCliente(clienteId);

        Optional<Cliente> foundCliente = clienteService.getClienteById(clienteId);
        assertFalse(foundCliente.isPresent());
    }

    @Test
    @DisplayName("Dovrebbe lanciare eccezione se l'ID cliente per l'eliminazione non è valido")
    void shouldThrowExceptionIfInvalidIdForDeletion() {
        IllegalArgumentException thrownZero = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.eliminaCliente(0);
        });
        assertEquals("ID cliente non valido per l'eliminazione.", thrownZero.getMessage());

        IllegalArgumentException thrownNegative = assertThrows(IllegalArgumentException.class, () -> {
            clienteService.eliminaCliente(-5);
        });
        assertEquals("ID cliente non valido per l'eliminazione.", thrownNegative.getMessage());
    }

    @Test
    @DisplayName("Dovrebbe gestire l'eliminazione di un cliente inesistente senza errori (ma non elimina nulla)")
    void shouldHandleDeletionOfNonExistentCliente() {
        assertDoesNotThrow(() -> clienteService.eliminaCliente(999));

        clienteService.registraNuovoCliente("Test", "Cliente", "test@test.com");
        int initialSize = clienteService.getAllClienti().size();
        clienteService.eliminaCliente(999);
        assertEquals(initialSize, clienteService.getAllClienti().size());
    }
}