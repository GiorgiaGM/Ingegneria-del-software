package org.example.service;

import org.example.model.Cliente;
import org.example.model.Ordine;
import org.example.model.Piatto;
import org.example.model.Tavolo;
import org.example.repository.ClienteRepository;
import org.example.repository.OrdineRepository;
import org.example.repository.TavoloRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class OrdineServiceTest {

    @Mock
    private OrdineRepository ordineRepository;
    @Mock
    private ClienteRepository clienteRepository;
    @Mock
    private TavoloRepository tavoloRepository;

    @InjectMocks
    private OrdineService ordineService;

    private Cliente testCliente;
    private Tavolo testTavoloLibero;
    private Tavolo testTavoloOccupato;
    private Ordine testOrdine1;
    private Ordine testOrdine2;

    @BeforeEach
    void setUp() {
        testCliente = new Cliente(1, "Mario", "Rossi", "mario.rossi@example.com");

        testTavoloLibero = new Tavolo(10, 4, Tavolo.STATO_LIBERO);
        testTavoloOccupato = new Tavolo(11, 2, Tavolo.STATO_OCCUPATO);

        testOrdine1 = new Ordine(1, testCliente, testTavoloLibero, OrdineService.STATO_IN_PREPARAZIONE);
        testOrdine2 = new Ordine(2, testCliente, testTavoloOccupato, OrdineService.STATO_SERVITO);

        reset(ordineRepository, clienteRepository, tavoloRepository);
    }

    @Test
    void testCreaNuovoOrdine_Successo() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(testTavoloLibero.getNumeroTavolo())).thenReturn(Optional.of(testTavoloLibero));
        when(ordineRepository.getNextId()).thenReturn(1);
        when(ordineRepository.save(any(Ordine.class))).thenAnswer(invocation -> {
            Ordine savedOrdine = invocation.getArgument(0);
            assertEquals(1, savedOrdine.getIdOrdine());
            assertEquals(testCliente.getId(), savedOrdine.getCliente().getId());
            assertEquals(testTavoloLibero.getNumeroTavolo(), savedOrdine.getTavolo().getNumeroTavolo());
            assertEquals(OrdineService.STATO_IN_PREPARAZIONE, savedOrdine.getStatoOrdine());
            return savedOrdine;
        });
        when(tavoloRepository.save(any(Tavolo.class))).thenAnswer(invocation -> {
            Tavolo savedTavolo = invocation.getArgument(0);
            assertEquals(Tavolo.STATO_OCCUPATO, savedTavolo.getStato());
            return savedTavolo;
        });

        Ordine nuovoOrdine = ordineService.creaNuovoOrdine(testCliente.getId(), testTavoloLibero.getNumeroTavolo());

        assertNotNull(nuovoOrdine);
        assertEquals(testCliente.getId(), nuovoOrdine.getCliente().getId());
        assertEquals(testTavoloLibero.getNumeroTavolo(), nuovoOrdine.getTavolo().getNumeroTavolo());
        assertEquals(OrdineService.STATO_IN_PREPARAZIONE, nuovoOrdine.getStatoOrdine());
        assertEquals(Tavolo.STATO_OCCUPATO, testTavoloLibero.getStato());

        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(testTavoloLibero.getNumeroTavolo());
        verify(tavoloRepository, times(1)).save(testTavoloLibero);
        verify(ordineRepository, times(1)).getNextId();
        verify(ordineRepository, times(1)).save(any(Ordine.class));
    }

    @Test
    void testCreaNuovoOrdine_ClienteNonTrovato_ThrowsException() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ordineService.creaNuovoOrdine(testCliente.getId(), testTavoloLibero.getNumeroTavolo());
        });

        assertEquals("Cliente non trovato con ID: " + testCliente.getId(), thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verifyNoInteractions(tavoloRepository, ordineRepository);
    }

    @Test
    void testCreaNuovoOrdine_TavoloNonTrovato_ThrowsException() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(testTavoloLibero.getNumeroTavolo())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ordineService.creaNuovoOrdine(testCliente.getId(), testTavoloLibero.getNumeroTavolo());
        });

        assertEquals("Tavolo non trovato con numero: " + testTavoloLibero.getNumeroTavolo(), thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(testTavoloLibero.getNumeroTavolo());
        verifyNoInteractions(ordineRepository);
    }

    @Test
    void testCreaNuovoOrdine_TavoloGiaOccupato_ThrowsException() {
        when(clienteRepository.findById(testCliente.getId())).thenReturn(Optional.of(testCliente));
        when(tavoloRepository.findByNumeroTavolo(testTavoloOccupato.getNumeroTavolo())).thenReturn(Optional.of(testTavoloOccupato));

        IllegalStateException thrown = assertThrows(IllegalStateException.class, () -> {
            ordineService.creaNuovoOrdine(testCliente.getId(), testTavoloOccupato.getNumeroTavolo());
        });

        assertEquals("Il tavolo " + testTavoloOccupato.getNumeroTavolo() + " è già occupato.", thrown.getMessage());
        verify(clienteRepository, times(1)).findById(testCliente.getId());
        verify(tavoloRepository, times(1)).findByNumeroTavolo(testTavoloOccupato.getNumeroTavolo());
        verifyNoMoreInteractions(tavoloRepository);
        verifyNoInteractions(ordineRepository);
    }

    @Test
    void testGetOrdineById_Esistente() {
        when(ordineRepository.findById(testOrdine1.getIdOrdine())).thenReturn(Optional.of(testOrdine1));

        Optional<Ordine> foundOrdine = ordineService.getOrdineById(testOrdine1.getIdOrdine());

        assertTrue(foundOrdine.isPresent());
        assertEquals(testOrdine1, foundOrdine.get());
        verify(ordineRepository, times(1)).findById(testOrdine1.getIdOrdine());
    }

    @Test
    void testGetOrdineById_NonEsistente() {
        when(ordineRepository.findById(99)).thenReturn(Optional.empty());

        Optional<Ordine> foundOrdine = ordineService.getOrdineById(99);

        assertFalse(foundOrdine.isPresent());
        verify(ordineRepository, times(1)).findById(99);
    }

    @Test
    void testGetAllOrdini_Successo() {
        when(ordineRepository.findAll()).thenReturn(Arrays.asList(testOrdine1, testOrdine2));

        List<Ordine> allOrdini = ordineService.getAllOrdini();

        assertNotNull(allOrdini);
        assertEquals(2, allOrdini.size());
        assertTrue(allOrdini.contains(testOrdine1));
        assertTrue(allOrdini.contains(testOrdine2));
        verify(ordineRepository, times(1)).findAll();
    }

    @Test
    void testGetAllOrdini_NessunOrdine() {
        when(ordineRepository.findAll()).thenReturn(Collections.emptyList());

        List<Ordine> allOrdini = ordineService.getAllOrdini();

        assertNotNull(allOrdini);
        assertTrue(allOrdini.isEmpty());
        verify(ordineRepository, times(1)).findAll();
    }

    @Test
    void testAggiornaStatoOrdine_AInPreparazione_Successo() {
        when(ordineRepository.findById(testOrdine1.getIdOrdine())).thenReturn(Optional.of(testOrdine1));
        when(ordineRepository.save(testOrdine1)).thenReturn(testOrdine1);

        Ordine updatedOrdine = ordineService.aggiornaStatoOrdine(testOrdine1.getIdOrdine(), OrdineService.STATO_PRONTO);

        assertNotNull(updatedOrdine);
        assertEquals(OrdineService.STATO_PRONTO, updatedOrdine.getStatoOrdine());
        verify(tavoloRepository, never()).save(any(Tavolo.class));
        verify(ordineRepository, times(1)).findById(testOrdine1.getIdOrdine());
        verify(ordineRepository, times(1)).save(testOrdine1);
    }

    @Test
    void testAggiornaStatoOrdine_ACompletato_Successo() {
        Ordine ordineDaCompletare = new Ordine(3, testCliente, testTavoloOccupato, OrdineService.STATO_SERVITO);
        testTavoloOccupato.setStato(Tavolo.STATO_OCCUPATO);

        when(ordineRepository.findById(ordineDaCompletare.getIdOrdine())).thenReturn(Optional.of(ordineDaCompletare));
        when(ordineRepository.save(ordineDaCompletare)).thenReturn(ordineDaCompletare);
        when(tavoloRepository.save(testTavoloOccupato)).thenReturn(testTavoloOccupato);

        Ordine updatedOrdine = ordineService.aggiornaStatoOrdine(ordineDaCompletare.getIdOrdine(), OrdineService.STATO_COMPLETATO);

        assertNotNull(updatedOrdine);
        assertEquals(OrdineService.STATO_COMPLETATO, updatedOrdine.getStatoOrdine());
        assertEquals(Tavolo.STATO_LIBERO, testTavoloOccupato.getStato());
        verify(ordineRepository, times(1)).findById(ordineDaCompletare.getIdOrdine());
        verify(ordineRepository, times(1)).save(ordineDaCompletare);
        verify(tavoloRepository, times(1)).save(testTavoloOccupato);
    }

    @Test
    void testAggiornaStatoOrdine_Annullato_Successo() {
        Ordine ordineDaAnnullare = new Ordine(4, testCliente, testTavoloOccupato, OrdineService.STATO_IN_PREPARAZIONE);
        testTavoloOccupato.setStato(Tavolo.STATO_OCCUPATO);

        when(ordineRepository.findById(ordineDaAnnullare.getIdOrdine())).thenReturn(Optional.of(ordineDaAnnullare));
        when(ordineRepository.save(ordineDaAnnullare)).thenReturn(ordineDaAnnullare);
        when(tavoloRepository.save(testTavoloOccupato)).thenReturn(testTavoloOccupato);

        Ordine updatedOrdine = ordineService.aggiornaStatoOrdine(ordineDaAnnullare.getIdOrdine(), OrdineService.STATO_ANNULLATO);

        assertNotNull(updatedOrdine);
        assertEquals(OrdineService.STATO_ANNULLATO, updatedOrdine.getStatoOrdine());
        assertEquals(Tavolo.STATO_LIBERO, testTavoloOccupato.getStato());
        verify(ordineRepository, times(1)).findById(ordineDaAnnullare.getIdOrdine());
        verify(ordineRepository, times(1)).save(ordineDaAnnullare);
        verify(tavoloRepository, times(1)).save(testTavoloOccupato);
    }

    @Test
    void testAggiornaStatoOrdine_OrdineNonTrovato_ThrowsException() {
        when(ordineRepository.findById(999)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ordineService.aggiornaStatoOrdine(999, OrdineService.STATO_PRONTO);
        });

        assertEquals("Ordine non trovato con ID: 999", thrown.getMessage());
        verify(ordineRepository, times(1)).findById(999);
        verifyNoInteractions(tavoloRepository);
        verify(ordineRepository, never()).save(any(Ordine.class));
    }

    @Test
    void testAggiornaStatoOrdine_StatoNonValido_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ordineService.aggiornaStatoOrdine(testOrdine1.getIdOrdine(), "StatoInesistente");
        });

        assertEquals("Stato ordine non valido: StatoInesistente", thrown.getMessage());
        verifyNoInteractions(ordineRepository, tavoloRepository);
    }

    @Test
    void testEliminaOrdine_SuccessoConTavolo() {
        when(ordineRepository.findById(testOrdine1.getIdOrdine())).thenReturn(Optional.of(testOrdine1));
        testOrdine1.getTavolo().setStato(Tavolo.STATO_OCCUPATO);
        doNothing().when(ordineRepository).deleteById(testOrdine1.getIdOrdine());
        when(tavoloRepository.save(testOrdine1.getTavolo())).thenReturn(testOrdine1.getTavolo());

        ordineService.eliminaOrdine(testOrdine1.getIdOrdine());

        assertEquals(Tavolo.STATO_LIBERO, testOrdine1.getTavolo().getStato());

        verify(ordineRepository, times(1)).findById(testOrdine1.getIdOrdine());
        verify(ordineRepository, times(1)).deleteById(testOrdine1.getIdOrdine());
        verify(tavoloRepository, times(1)).save(testOrdine1.getTavolo());
    }

    @Test
    void testEliminaOrdine_SuccessoSenzaTavolo() {
        Ordine ordineSenzaTavolo = new Ordine(5, testCliente, null, OrdineService.STATO_COMPLETATO);
        when(ordineRepository.findById(ordineSenzaTavolo.getIdOrdine())).thenReturn(Optional.of(ordineSenzaTavolo));
        doNothing().when(ordineRepository).deleteById(ordineSenzaTavolo.getIdOrdine());

        ordineService.eliminaOrdine(ordineSenzaTavolo.getIdOrdine());

        verify(ordineRepository, times(1)).findById(ordineSenzaTavolo.getIdOrdine());
        verify(ordineRepository, times(1)).deleteById(ordineSenzaTavolo.getIdOrdine());
        verifyNoInteractions(tavoloRepository);
    }

    @Test
    void testEliminaOrdine_IdNonValido_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ordineService.eliminaOrdine(0);
        });

        assertEquals("ID Ordine non valido per l'eliminazione.", thrown.getMessage());
        verifyNoInteractions(ordineRepository, clienteRepository, tavoloRepository);
    }

    @Test
    void testEliminaOrdine_OrdineNonTrovato_ThrowsException() {
        when(ordineRepository.findById(999)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ordineService.eliminaOrdine(999);
        });

        assertEquals("Ordine non trovato con ID: 999 per l'eliminazione.", thrown.getMessage());
        verify(ordineRepository, times(1)).findById(999);
        verify(ordineRepository, never()).deleteById(anyInt());
        verifyNoInteractions(tavoloRepository);
    }

    @Test
    void testCalcolaTotaleOrdine_Successo() {
        Piatto piatto1 = new Piatto(201, "Pasta al Pesto", "Pasta con pesto genovese", 12.00f);
        Piatto piatto2 = new Piatto(202, "Tiramisù", "Dessert al cucchiaio", 6.50f);

        Ordine ordineConTotaleMock = spy(new Ordine(1, testCliente, testTavoloLibero, OrdineService.STATO_SERVITO));
        doReturn(18.50).when(ordineConTotaleMock).calcolaTotale();

        when(ordineRepository.findById(ordineConTotaleMock.getIdOrdine())).thenReturn(Optional.of(ordineConTotaleMock));

        double totale = ordineService.calcolaTotaleOrdine(ordineConTotaleMock.getIdOrdine());

        assertEquals(18.50, totale, 0.001);
        verify(ordineRepository, times(1)).findById(ordineConTotaleMock.getIdOrdine());
        verify(ordineConTotaleMock, times(1)).calcolaTotale();
    }

    @Test
    void testCalcolaTotaleOrdine_OrdineNonTrovato_ThrowsException() {
        when(ordineRepository.findById(999)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ordineService.calcolaTotaleOrdine(999);
        });

        assertEquals("Ordine non trovato con ID: 999", thrown.getMessage());
        verify(ordineRepository, times(1)).findById(999);
    }

    @Test
    void testGetOrdiniByStato_Successo() {
        when(ordineRepository.findByStato(OrdineService.STATO_IN_PREPARAZIONE)).thenReturn(Collections.singletonList(testOrdine1));

        List<Ordine> ordiniInPreparazione = ordineService.getOrdiniByStato(OrdineService.STATO_IN_PREPARAZIONE);

        assertNotNull(ordiniInPreparazione);
        assertEquals(1, ordiniInPreparazione.size());
        assertTrue(ordiniInPreparazione.contains(testOrdine1));
        verify(ordineRepository, times(1)).findByStato(OrdineService.STATO_IN_PREPARAZIONE);
    }

    @Test
    void testGetOrdiniByStato_StatoNonValido_ThrowsException() {
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            ordineService.getOrdiniByStato("StatoFalso");
        });

        assertEquals("Stato ordine non valido: StatoFalso", thrown.getMessage());
        verifyNoInteractions(ordineRepository);
    }

    @Test
    void testGetOrdiniByStato_NessunOrdinePerStato() {
        when(ordineRepository.findByStato(OrdineService.STATO_PRONTO)).thenReturn(Collections.emptyList());

        List<Ordine> ordiniPronti = ordineService.getOrdiniByStato(OrdineService.STATO_PRONTO);

        assertNotNull(ordiniPronti);
        assertTrue(ordiniPronti.isEmpty());
        verify(ordineRepository, times(1)).findByStato(OrdineService.STATO_PRONTO);
    }
}
