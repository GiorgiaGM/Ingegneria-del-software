package org.example.service;

import org.example.model.Ingrediente;
import org.example.model.Piatto;
import org.example.repository.IngredienteRepository;
import org.example.repository.PiattoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PiattoServiceTest {

    @Mock
    private PiattoRepository piattoRepository;
    @Mock
    private IngredienteRepository ingredienteRepository;

    @InjectMocks
    private PiattoService piattoService;
    private Ingrediente ingrediente1;
    private Ingrediente ingrediente2;
    private Piatto piattoPasta;
    private Piatto piattoPizza;

    @BeforeEach
    void setUp() {
        ingrediente1 = new Ingrediente(1, "Pomodoro", 1.50f);
        ingrediente2 = new Ingrediente(2, "Mozzarella", 3.20f);

        piattoPasta = new Piatto(1, "Pasta al ragù", "Classico piatto di pasta con ragù di carne", 12.50f, new ArrayList<>());
        piattoPizza = new Piatto(2, "Pizza Margherita", "La classica pizza napoletana", 8.00f, Arrays.asList(ingrediente1, ingrediente2));

        reset(piattoRepository, ingredienteRepository);
    }

    @Test
    void testCreaPiatto_SuccessoConIngredienti() {
        String nome = "Carbonara";
        String descrizione = "Piatto di pasta con uova, guanciale, pecorino e pepe";
        float prezzo = 14.00f;
        List<Integer> ingredientiIds = Arrays.asList(1, 2);

        when(ingredienteRepository.findById(1)).thenReturn(Optional.of(ingrediente1));
        when(ingredienteRepository.findById(2)).thenReturn(Optional.of(ingrediente2));
        when(piattoRepository.findByNome(nome)).thenReturn(Optional.empty());
        when(piattoRepository.getNextId()).thenReturn(3);
        when(piattoRepository.save(any(Piatto.class))).thenAnswer(invocation -> {
            Piatto savedPiatto = invocation.getArgument(0);
            assertEquals(3, savedPiatto.getId());
            assertEquals(nome, savedPiatto.getNome());
            assertEquals(descrizione, savedPiatto.getDescrizione());
            assertEquals(prezzo, savedPiatto.getPrezzo(), 0.001f);
            assertEquals(2, savedPiatto.getIngredienti().size());
            return savedPiatto;
        });

        Piatto nuovoPiatto = piattoService.creaPiatto(nome, descrizione, prezzo, ingredientiIds);

        assertNotNull(nuovoPiatto);
        assertEquals(nome, nuovoPiatto.getNome());
        assertEquals(prezzo, nuovoPiatto.getPrezzo(), 0.001f);
        assertEquals(2, nuovoPiatto.getIngredienti().size());
        assertTrue(nuovoPiatto.getIngredienti().contains(ingrediente1));
        assertTrue(nuovoPiatto.getIngredienti().contains(ingrediente2));

        verify(piattoRepository, times(1)).findByNome(nome);
        verify(ingredienteRepository, times(1)).findById(1);
        verify(ingredienteRepository, times(1)).findById(2);
        verify(piattoRepository, times(1)).getNextId();
        verify(piattoRepository, times(1)).save(any(Piatto.class));
    }

    @Test
    void testCreaPiatto_SuccessoSenzaIngredienti() {
        String nome = "Insalata Mista";
        String descrizione = "Semplice insalata con lattuga e pomodoro";
        float prezzo = 7.00f;

        when(piattoRepository.findByNome(nome)).thenReturn(Optional.empty());
        when(piattoRepository.getNextId()).thenReturn(3);
        when(piattoRepository.save(any(Piatto.class))).thenAnswer(invocation -> {
            Piatto savedPiatto = invocation.getArgument(0);
            assertEquals(3, savedPiatto.getId());
            assertEquals(nome, savedPiatto.getNome());
            assertEquals(prezzo, savedPiatto.getPrezzo(), 0.001f);
            assertTrue(savedPiatto.getIngredienti().isEmpty());
            return savedPiatto;
        });

        Piatto nuovoPiatto = piattoService.creaPiatto(nome, descrizione, prezzo, null);

        assertNotNull(nuovoPiatto);
        assertEquals(nome, nuovoPiatto.getNome());
        assertEquals(prezzo, nuovoPiatto.getPrezzo(), 0.001f);
        assertTrue(nuovoPiatto.getIngredienti().isEmpty());

        verify(piattoRepository, times(1)).findByNome(nome);
        verifyNoInteractions(ingredienteRepository);
        verify(piattoRepository, times(1)).getNextId();
        verify(piattoRepository, times(1)).save(any(Piatto.class));
    }

    @Test
    void testCreaPiatto_NomeNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                        piattoService.creaPiatto(null, "desc", 10.0f, null),
                "Nome o prezzo del piatto non validi.");
        assertThrows(IllegalArgumentException.class, () ->
                        piattoService.creaPiatto("", "desc", 10.0f, null),
                "Nome o prezzo del piatto non validi.");
        assertThrows(IllegalArgumentException.class, () ->
                        piattoService.creaPiatto("   ", "desc", 10.0f, null),
                "Nome o prezzo del piatto non validi.");
        verifyNoInteractions(piattoRepository, ingredienteRepository);
    }

    @Test
    void testCreaPiatto_PrezzoNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                        piattoService.creaPiatto("Piatto Test", "desc", 0.0f, null),
                "Nome o prezzo del piatto non validi.");
        assertThrows(IllegalArgumentException.class, () ->
                        piattoService.creaPiatto("Piatto Test", "desc", -5.0f, null),
                "Nome o prezzo del piatto non validi.");
        verifyNoInteractions(piattoRepository, ingredienteRepository);
    }

    @Test
    void testCreaPiatto_NomeDuplicato_ThrowsException() {
        String nomeDuplicato = "Pizza Margherita";
        when(piattoRepository.findByNome(nomeDuplicato)).thenReturn(Optional.of(piattoPizza));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                piattoService.creaPiatto(nomeDuplicato, "desc", 15.0f, null));

        assertEquals("Esiste già un piatto con questo nome: " + nomeDuplicato, thrown.getMessage());
        verify(piattoRepository, times(1)).findByNome(nomeDuplicato);
        verifyNoMoreInteractions(piattoRepository, ingredienteRepository);
    }

    @Test
    void testCreaPiatto_IngredienteNonTrovato_ThrowsException() {
        String nome = "Nuovo Piatto";
        List<Integer> ingredientiIds = Arrays.asList(1, 999);

        when(piattoRepository.findByNome(nome)).thenReturn(Optional.empty());
        when(ingredienteRepository.findById(1)).thenReturn(Optional.of(ingrediente1));
        when(ingredienteRepository.findById(999)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                piattoService.creaPiatto(nome, "desc", 10.0f, ingredientiIds));

        assertEquals("Ingrediente non trovato con ID: 999", thrown.getMessage());
        verify(piattoRepository, times(1)).findByNome(nome);
        verify(ingredienteRepository, times(1)).findById(1);
        verify(ingredienteRepository, times(1)).findById(999);
        verifyNoMoreInteractions(piattoRepository); // Save non dovrebbe essere chiamato
    }

    @Test
    void testGetPiattoById_Esistente() {
        when(piattoRepository.findById(piattoPasta.getId())).thenReturn(Optional.of(piattoPasta));

        Optional<Piatto> foundPiatto = piattoService.getPiattoById(piattoPasta.getId());

        assertTrue(foundPiatto.isPresent());
        assertEquals(piattoPasta, foundPiatto.get());
        verify(piattoRepository, times(1)).findById(piattoPasta.getId());
    }

    @Test
    void testGetPiattoById_NonEsistente() {
        when(piattoRepository.findById(999)).thenReturn(Optional.empty());

        Optional<Piatto> foundPiatto = piattoService.getPiattoById(999);

        assertFalse(foundPiatto.isPresent());
        verify(piattoRepository, times(1)).findById(999);
    }

    @Test
    void testGetPiattoByNome_Esistente() {
        when(piattoRepository.findByNome(piattoPizza.getNome())).thenReturn(Optional.of(piattoPizza));

        Optional<Piatto> foundPiatto = piattoService.getPiattoByNome(piattoPizza.getNome());

        assertTrue(foundPiatto.isPresent());
        assertEquals(piattoPizza, foundPiatto.get());
        verify(piattoRepository, times(1)).findByNome(piattoPizza.getNome());
    }

    @Test
    void testGetPiattoByNome_NonEsistente() {
        when(piattoRepository.findByNome("Piatto Inesistente")).thenReturn(Optional.empty());

        Optional<Piatto> foundPiatto = piattoService.getPiattoByNome("Piatto Inesistente");

        assertFalse(foundPiatto.isPresent());
        verify(piattoRepository, times(1)).findByNome("Piatto Inesistente");
    }

    @Test
    void testGetAllPiatti_ListaNonVuota() {
        when(piattoRepository.findAll()).thenReturn(Arrays.asList(piattoPasta, piattoPizza));

        List<Piatto> allPiatti = piattoService.getAllPiatti();

        assertNotNull(allPiatti);
        assertEquals(2, allPiatti.size());
        assertTrue(allPiatti.contains(piattoPasta));
        assertTrue(allPiatti.contains(piattoPizza));
        verify(piattoRepository, times(1)).findAll();
    }

    @Test
    void testGetAllPiatti_ListaVuota() {
        when(piattoRepository.findAll()).thenReturn(Collections.emptyList());

        List<Piatto> allPiatti = piattoService.getAllPiatti();

        assertNotNull(allPiatti);
        assertTrue(allPiatti.isEmpty());
        verify(piattoRepository, times(1)).findAll();
    }

    @Test
    void testGetPiattiSottoPrezzo_Successo() {
        float prezzoMax = 10.0f;
        when(piattoRepository.findByPrezzoLessThanEqual(prezzoMax)).thenReturn(Collections.singletonList(piattoPizza));

        List<Piatto> piatti = piattoService.getPiattiSottoPrezzo(prezzoMax);

        assertNotNull(piatti);
        assertEquals(1, piatti.size());
        assertEquals(piattoPizza, piatti.get(0));
        verify(piattoRepository, times(1)).findByPrezzoLessThanEqual(prezzoMax);
    }

    @Test
    void testGetPiattiSottoPrezzo_NessunPiatto() {
        float prezzoMax = 5.0f;
        when(piattoRepository.findByPrezzoLessThanEqual(prezzoMax)).thenReturn(Collections.emptyList());

        List<Piatto> piatti = piattoService.getPiattiSottoPrezzo(prezzoMax);

        assertNotNull(piatti);
        assertTrue(piatti.isEmpty());
        verify(piattoRepository, times(1)).findByPrezzoLessThanEqual(prezzoMax);
    }

    @Test
    void testGetPiattiSottoPrezzo_PrezzoNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                piattoService.getPiattiSottoPrezzo(0.0f), "Il prezzo massimo deve essere maggiore di zero.");
        assertThrows(IllegalArgumentException.class, () ->
                piattoService.getPiattiSottoPrezzo(-10.0f), "Il prezzo massimo deve essere maggiore di zero.");
        verifyNoInteractions(piattoRepository);
    }

    @Test
    void testAggiornaPiatto_Successo() {
        Piatto piattoDaAggiornare = new Piatto(piattoPasta.getId(), "Pasta al ragù rivisitata", "Nuova descrizione", 13.00f, new ArrayList<>());
        when(piattoRepository.findByNome(piattoDaAggiornare.getNome())).thenReturn(Optional.empty());
        when(piattoRepository.save(piattoDaAggiornare)).thenReturn(piattoDaAggiornare);
        Piatto piattoAggiornato = piattoService.aggiornaPiatto(piattoDaAggiornare);

        assertNotNull(piattoAggiornato);
        assertEquals(piattoDaAggiornare.getNome(), piattoAggiornato.getNome());
        assertEquals(piattoDaAggiornare.getPrezzo(), piattoAggiornato.getPrezzo(), 0.001f);
        verify(piattoRepository, times(1)).findByNome(piattoDaAggiornare.getNome());
        verify(piattoRepository, times(1)).save(piattoDaAggiornare);
    }

    @Test
    void testAggiornaPiatto_PiattoNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                piattoService.aggiornaPiatto(null), "Piatto non valido per l'aggiornamento.");
        assertThrows(IllegalArgumentException.class, () ->
                piattoService.aggiornaPiatto(new Piatto(0, "Invalid", "", 10.0f, null)), "Piatto non valido per l'aggiornamento.");
        verifyNoInteractions(piattoRepository, ingredienteRepository);
    }

    @Test
    void testAggiornaPiatto_PrezzoNonValido_ThrowsException() {
        Piatto piattoConPrezzoZero = new Piatto(piattoPasta.getId(), "Pasta al ragù", "desc", 0.0f, new ArrayList<>());
        Piatto piattoConPrezzoNegativo = new Piatto(piattoPasta.getId(), "Pasta al ragù", "desc", -5.0f, new ArrayList<>());

        IllegalArgumentException thrownZero = assertThrows(IllegalArgumentException.class, () ->
                piattoService.aggiornaPiatto(piattoConPrezzoZero));
        assertEquals("Il prezzo del piatto deve essere maggiore di zero.", thrownZero.getMessage());

        IllegalArgumentException thrownNegative = assertThrows(IllegalArgumentException.class, () ->
                piattoService.aggiornaPiatto(piattoConPrezzoNegativo));
        assertEquals("Il prezzo del piatto deve essere maggiore di zero.", thrownNegative.getMessage());

        verifyNoInteractions(piattoRepository, ingredienteRepository);
    }

    @Test
    void testAggiornaPiatto_NomeDuplicatoDuranteAggiornamento_ThrowsException() {
        Piatto piattoDaAggiornare = new Piatto(piattoPasta.getId(), piattoPizza.getNome(), "desc", 15.0f, new ArrayList<>());

        when(piattoRepository.findByNome(piattoDaAggiornare.getNome())).thenReturn(Optional.of(piattoPizza));

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                piattoService.aggiornaPiatto(piattoDaAggiornare));

        assertEquals("Esiste già un altro piatto con questo nome.", thrown.getMessage());
        verify(piattoRepository, times(1)).findByNome(piattoDaAggiornare.getNome());
        verifyNoMoreInteractions(piattoRepository, ingredienteRepository);
    }

    @Test
    void testAggiornaPiatto_NomeNonDuplicatoStessoID_Successo() {
        Piatto piattoAggiornatoStessoNome = new Piatto(piattoPasta.getId(), piattoPasta.getNome(), "Descrizione aggiornata", 13.00f, new ArrayList<>());
        when(piattoRepository.findByNome(piattoAggiornatoStessoNome.getNome())).thenReturn(Optional.of(piattoPasta));
        when(piattoRepository.save(piattoAggiornatoStessoNome)).thenReturn(piattoAggiornatoStessoNome);
        Piatto resultPiatto = piattoService.aggiornaPiatto(piattoAggiornatoStessoNome);

        assertNotNull(resultPiatto);
        assertEquals(piattoAggiornatoStessoNome.getNome(), resultPiatto.getNome());
        assertEquals(piattoAggiornatoStessoNome.getDescrizione(), resultPiatto.getDescrizione());
        assertEquals(piattoAggiornatoStessoNome.getPrezzo(), resultPiatto.getPrezzo(), 0.001f);

        verify(piattoRepository, times(1)).findByNome(piattoAggiornatoStessoNome.getNome());
        verify(piattoRepository, times(1)).save(piattoAggiornatoStessoNome);
    }

    @Test
    void testAggiornaPiatto_IngredienteAssociatoNonTrovato_ThrowsException() {
        Ingrediente ingredienteNonEsistente = new Ingrediente(999, "Ingrediente Falso", 10.0f); // Prezzo per l'ingrediente
        Piatto piattoConIngredienteNonEsistente = new Piatto(piattoPasta.getId(), "Pasta Test", "desc", 10.0f, Arrays.asList(ingredienteNonEsistente));

        when(piattoRepository.findByNome(piattoConIngredienteNonEsistente.getNome())).thenReturn(Optional.of(piattoPasta));
        when(ingredienteRepository.findById(ingredienteNonEsistente.getId())).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                piattoService.aggiornaPiatto(piattoConIngredienteNonEsistente));

        assertEquals("Ingrediente associato con ID " + ingredienteNonEsistente.getId() + " non trovato.", thrown.getMessage());
        verify(piattoRepository, times(1)).findByNome(piattoConIngredienteNonEsistente.getNome());
        verify(ingredienteRepository, times(1)).findById(ingredienteNonEsistente.getId());
        verifyNoMoreInteractions(piattoRepository);
    }

    @Test
    void testEliminaPiatto_Successo() {
        int idToDelete = piattoPasta.getId();

        piattoService.eliminaPiatto(idToDelete);

        verify(piattoRepository, times(1)).deleteById(idToDelete);
    }

    @Test
    void testEliminaPiatto_IdNonValido_ThrowsException() {
        assertThrows(IllegalArgumentException.class, () ->
                piattoService.eliminaPiatto(0), "ID piatto non valido per l'eliminazione.");
        assertThrows(IllegalArgumentException.class, () ->
                piattoService.eliminaPiatto(-5), "ID piatto non valido per l'eliminazione.");
        verifyNoInteractions(piattoRepository);
    }

    @Test
    void testAggiungiIngredienteAPiatto_Successo() {
        Piatto piattoCopy = new Piatto(piattoPasta.getId(), piattoPasta.getNome(), piattoPasta.getDescrizione(), piattoPasta.getPrezzo(), new ArrayList<>(piattoPasta.getIngredienti()));
        Ingrediente nuovoIngrediente = new Ingrediente(3, "Basilico", 0.50f);
        when(piattoRepository.findById(piattoCopy.getId())).thenReturn(Optional.of(piattoCopy));
        when(ingredienteRepository.findById(nuovoIngrediente.getId())).thenReturn(Optional.of(nuovoIngrediente));
        when(piattoRepository.save(any(Piatto.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Piatto updatedPiatto = piattoService.aggiungiIngredienteAPiatto(piattoCopy.getId(), nuovoIngrediente.getId());

        assertNotNull(updatedPiatto);
        assertEquals(piattoCopy.getId(), updatedPiatto.getId());
        assertTrue(updatedPiatto.getIngredienti().contains(nuovoIngrediente));
        assertEquals(1, updatedPiatto.getIngredienti().size());

        verify(piattoRepository, times(1)).findById(piattoCopy.getId());
        verify(ingredienteRepository, times(1)).findById(nuovoIngrediente.getId());
        verify(piattoRepository, times(1)).save(any(Piatto.class));
    }

    @Test
    void testAggiungiIngredienteAPiatto_PiattoNonTrovato_ThrowsException() {
        int nonExistingPiattoId = 999;
        when(piattoRepository.findById(nonExistingPiattoId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                piattoService.aggiungiIngredienteAPiatto(nonExistingPiattoId, ingrediente1.getId()));

        assertEquals("Piatto non trovato con ID: " + nonExistingPiattoId, thrown.getMessage());
        verify(piattoRepository, times(1)).findById(nonExistingPiattoId);
        verifyNoInteractions(ingredienteRepository);
        verifyNoMoreInteractions(piattoRepository);
    }

    @Test
    void testAggiungiIngredienteAPiatto_IngredienteNonTrovato_ThrowsException() {
        int nonExistingIngredienteId = 999;
        when(piattoRepository.findById(piattoPasta.getId())).thenReturn(Optional.of(piattoPasta));
        when(ingredienteRepository.findById(nonExistingIngredienteId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                piattoService.aggiungiIngredienteAPiatto(piattoPasta.getId(), nonExistingIngredienteId));

        assertEquals("Ingrediente non trovato con ID: " + nonExistingIngredienteId, thrown.getMessage());
        verify(piattoRepository, times(1)).findById(piattoPasta.getId());
        verify(ingredienteRepository, times(1)).findById(nonExistingIngredienteId);
        verifyNoMoreInteractions(piattoRepository);
    }

    @Test
    void testRimuoviIngredienteDaPiatto_Successo() {
        Piatto piattoCopy = new Piatto(piattoPizza.getId(), piattoPizza.getNome(), piattoPizza.getDescrizione(), piattoPizza.getPrezzo(), new ArrayList<>(piattoPizza.getIngredienti()));
        when(piattoRepository.findById(piattoCopy.getId())).thenReturn(Optional.of(piattoCopy));
        when(ingredienteRepository.findById(ingrediente1.getId())).thenReturn(Optional.of(ingrediente1));
        when(piattoRepository.save(any(Piatto.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Piatto updatedPiatto = piattoService.rimuoviIngredienteDaPiatto(piattoCopy.getId(), ingrediente1.getId());

        assertNotNull(updatedPiatto);
        assertEquals(piattoCopy.getId(), updatedPiatto.getId());
        assertFalse(updatedPiatto.getIngredienti().contains(ingrediente1));
        assertEquals(1, updatedPiatto.getIngredienti().size());

        verify(piattoRepository, times(1)).findById(piattoCopy.getId());
        verify(ingredienteRepository, times(1)).findById(ingrediente1.getId());
        verify(piattoRepository, times(1)).save(any(Piatto.class));
    }

    @Test
    void testRimuoviIngredienteDaPiatto_PiattoNonTrovato_ThrowsException() {
        int nonExistingPiattoId = 999;
        when(piattoRepository.findById(nonExistingPiattoId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                piattoService.rimuoviIngredienteDaPiatto(nonExistingPiattoId, ingrediente1.getId()));

        assertEquals("Piatto non trovato con ID: " + nonExistingPiattoId, thrown.getMessage());
        verify(piattoRepository, times(1)).findById(nonExistingPiattoId);
        verifyNoInteractions(ingredienteRepository);
        verifyNoMoreInteractions(piattoRepository);
    }

    @Test
    void testRimuoviIngredienteDaPiatto_IngredienteNonTrovato_ThrowsException() {
        int nonExistingIngredienteId = 999;
        when(piattoRepository.findById(piattoPizza.getId())).thenReturn(Optional.of(piattoPizza));
        when(ingredienteRepository.findById(nonExistingIngredienteId)).thenReturn(Optional.empty());

        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () ->
                piattoService.rimuoviIngredienteDaPiatto(piattoPizza.getId(), nonExistingIngredienteId));

        assertEquals("Ingrediente non trovato con ID: " + nonExistingIngredienteId, thrown.getMessage());
        verify(piattoRepository, times(1)).findById(piattoPizza.getId());
        verify(ingredienteRepository, times(1)).findById(nonExistingIngredienteId);
        verifyNoMoreInteractions(piattoRepository);
    }
}