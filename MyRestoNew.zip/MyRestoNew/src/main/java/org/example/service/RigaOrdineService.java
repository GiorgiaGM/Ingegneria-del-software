package org.example.service;

import org.example.model.RigaOrdine;
import org.example.model.Piatto;
import org.example.model.Variazione;
import org.example.model.Ordine;
import org.example.repository.RigaOrdineRepository;
import org.example.repository.PiattoRepository;
import org.example.repository.VariazioneRepository;
import org.example.repository.OrdineRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RigaOrdineService {
    private final RigaOrdineRepository rigaOrdineRepository;
    private final PiattoRepository piattoRepository;
    private final VariazioneRepository variazioneRepository;
    private final OrdineRepository ordineRepository;

    public RigaOrdineService(RigaOrdineRepository rigaOrdineRepository, PiattoRepository piattoRepository, VariazioneRepository variazioneRepository, OrdineRepository ordineRepository) {
        this.rigaOrdineRepository = rigaOrdineRepository;
        this.piattoRepository = piattoRepository;
        this.variazioneRepository = variazioneRepository;
        this.ordineRepository = ordineRepository;
    }

    public RigaOrdine creaRigaOrdine(int idOrdine, int piattoId, int quantita, String note, List<Integer> variazioniIds) {
        if (quantita <= 0) {
            throw new IllegalArgumentException("La quantità deve essere maggiore di zero.");
        }

        Ordine ordine = ordineRepository.findById(idOrdine)
                .orElseThrow(() -> new IllegalArgumentException("Ordine non trovato con ID: " + idOrdine));

        Piatto piatto = piattoRepository.findById(piattoId)
                .orElseThrow(() -> new IllegalArgumentException("Piatto non trovato con ID: " + piattoId));

        List<Variazione> variazioni = new ArrayList<>();
        if (variazioniIds != null) {
            for (Integer varId : variazioniIds) {
                Variazione variazione = variazioneRepository.findById(varId)
                        .orElseThrow(() -> new IllegalArgumentException("Variazione non trovata con ID: " + varId));
                variazioni.add(variazione);
            }
        }

        RigaOrdine riga = new RigaOrdine(
                rigaOrdineRepository.getNextId(),
                quantita,
                (float) piatto.getPrezzo(),
                piatto,
                variazioni,
                note,
                ordine
        );
        rigaOrdineRepository.save(riga);

        ordine.addRigaOrdine(riga);
        ordineRepository.save(ordine);

        return riga;
    }

    public Optional<RigaOrdine> getRigaOrdineById(int id) {
        return rigaOrdineRepository.findById(id);
    }

    public List<RigaOrdine> getAllRigheOrdine() {
        return rigaOrdineRepository.findAll();
    }

    public RigaOrdine aggiornaQuantitaRigaOrdine(int rigaId, int nuovaQuantita) {
        if (nuovaQuantita <= 0) {
            throw new IllegalArgumentException("La nuova quantità deve essere maggiore di zero.");
        }
        RigaOrdine riga = rigaOrdineRepository.findById(rigaId)
                .orElseThrow(() -> new IllegalArgumentException("Riga Ordine non trovata con ID: " + rigaId));

        riga.setQuantita(nuovaQuantita);
        return rigaOrdineRepository.save(riga);
    }

    public RigaOrdine aggiungiVariazioneARigaOrdine(int rigaId, int variazioneId) {
        RigaOrdine riga = rigaOrdineRepository.findById(rigaId)
                .orElseThrow(() -> new IllegalArgumentException("Riga Ordine non trovata con ID: " + rigaId));
        Variazione variazione = variazioneRepository.findById(variazioneId)
                .orElseThrow(() -> new IllegalArgumentException("Variazione non trovata con ID: " + variazioneId));

        riga.addVariazione(variazione);
        return rigaOrdineRepository.save(riga);
    }

    public RigaOrdine rimuoviVariazioneDaRigaOrdine(int rigaId, int variazioneId) {
        RigaOrdine riga = rigaOrdineRepository.findById(rigaId)
                .orElseThrow(() -> new IllegalArgumentException("Riga Ordine non trovata con ID: " + rigaId));
        Variazione variazione = variazioneRepository.findById(variazioneId)
                .orElseThrow(() -> new IllegalArgumentException("Variazione non trovata con ID: " + variazioneId));

        riga.removeVariazione(variazione);
        return rigaOrdineRepository.save(riga);
    }

    public void eliminaRigaOrdine(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID Riga Ordine non valido per l'eliminazione.");
        }
        rigaOrdineRepository.deleteById(id);
    }
}