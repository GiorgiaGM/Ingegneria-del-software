package org.example.service;

import org.example.model.FidelityCard;
import org.example.model.Ordine;
import org.example.model.Pagamento;
import org.example.repository.FidelityCardRepository;
import org.example.repository.OrdineRepository;
import org.example.repository.PagamentoRepository;
import java.util.List;

import java.time.LocalDateTime;
import java.util.Optional;

public class PagamentoService {
    private final PagamentoRepository pagamentoRepository;
    private final OrdineRepository ordineRepository;
    private final FidelityCardRepository fidelityCardRepository;
    private final FidelityCardService fidelityCardService;

    private final OrdineService ordineService;

    public PagamentoService(PagamentoRepository pagamentoRepository,
                            OrdineRepository ordineRepository,
                            FidelityCardRepository fidelityCardRepository,
                            FidelityCardService fidelityCardService,
                            OrdineService ordineService) {
        this.pagamentoRepository = pagamentoRepository;
        this.ordineRepository = ordineRepository;
        this.fidelityCardRepository = fidelityCardRepository;
        this.fidelityCardService = fidelityCardService;
        this.ordineService = ordineService;
    }

    public Pagamento registraPagamento(int idOrdine, double importo, Optional<Integer> idFidelityCard) {
        Ordine ordine = ordineRepository.findById(idOrdine)
                .orElseThrow(() -> new IllegalArgumentException("Ordine non trovato con ID: " + idOrdine));

        if (!ordine.getStatoOrdine().equals(OrdineService.STATO_SERVITO) && !ordine.getStatoOrdine().equals(OrdineService.STATO_PRONTO)) {
            throw new IllegalStateException("L'ordine " + idOrdine + " non è nello stato corretto per il pagamento (" + ordine.getStatoOrdine() + "). Deve essere '" + OrdineService.STATO_SERVITO + "' o '" + OrdineService.STATO_PRONTO + "'.");
        }

        if (importo <= 0) {
            throw new IllegalArgumentException("L'importo del pagamento deve essere positivo.");
        }

        FidelityCard fidelityCard = null;
        if (idFidelityCard.isPresent()) {
            fidelityCard = fidelityCardRepository.findById(idFidelityCard.get())
                    .orElseThrow(() -> new IllegalArgumentException("Fidelity Card non trovata con ID: " + idFidelityCard.get()));
            int puntiGuadagnati = (int) (importo / 10);
            fidelityCardService.aggiungiPunti(fidelityCard.getIdCard(), puntiGuadagnati);
        }

        Pagamento pagamento = new Pagamento(pagamentoRepository.getNextId(), ordine, importo, LocalDateTime.now(), fidelityCard);

        ordineService.aggiornaStatoOrdine(idOrdine, OrdineService.STATO_COMPLETATO);

        return pagamentoRepository.save(pagamento);
    }

    public Optional<Pagamento> getPagamentoById(int id) {
        return pagamentoRepository.findById(id);
    }

    public List<Pagamento> getAllPagamenti() {
        return pagamentoRepository.findAll();
    }
}