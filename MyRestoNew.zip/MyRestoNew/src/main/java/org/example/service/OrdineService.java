package org.example.service;

import org.example.model.Ordine;
import org.example.model.Cliente;
import org.example.model.Tavolo;
import org.example.repository.OrdineRepository;
import org.example.repository.ClienteRepository;
import org.example.repository.TavoloRepository;
import org.example.repository.PiattoRepository;
import org.example.repository.RigaOrdineRepository;
import org.example.repository.VariazioneRepository;
import java.util.List;
import java.util.Optional;


public class OrdineService {
    private final OrdineRepository ordineRepository;
    private final ClienteRepository clienteRepository;
    private final TavoloRepository tavoloRepository;
    private final PiattoRepository piattoRepository;
    private final RigaOrdineRepository rigaOrdineRepository;
    private final VariazioneRepository variazioneRepository;

    public static final String STATO_IN_PREPARAZIONE = "In Preparazione";
    public static final String STATO_PRONTO = "Pronto";
    public static final String STATO_SERVITO = "Servito";
    public static final String STATO_COMPLETATO = "Completato";
    public static final String STATO_ANNULLATO = "Annullato";

    public OrdineService(OrdineRepository ordineRepository, ClienteRepository clienteRepository,
                         TavoloRepository tavoloRepository, PiattoRepository piattoRepository,
                         RigaOrdineRepository rigaOrdineRepository, VariazioneRepository variazioneRepository) {
        this.ordineRepository = ordineRepository;
        this.clienteRepository = clienteRepository;
        this.tavoloRepository = tavoloRepository;
        this.piattoRepository = piattoRepository;
        this.rigaOrdineRepository = rigaOrdineRepository;
        this.variazioneRepository = variazioneRepository;
    }

    public Ordine creaNuovoOrdine(int clienteId, int numeroTavolo) {
        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente non trovato con ID: " + clienteId));

        Tavolo tavolo = tavoloRepository.findByNumeroTavolo(numeroTavolo)
                .orElseThrow(() -> new IllegalArgumentException("Tavolo non trovato con numero: " + numeroTavolo));


        if (tavolo.isOccupato()) {
            throw new IllegalStateException("Il tavolo " + numeroTavolo + " è già occupato.");
        }

        Ordine ordine = new Ordine(ordineRepository.getNextId(), cliente, tavolo, STATO_IN_PREPARAZIONE);
        tavolo.setStato(Tavolo.STATO_OCCUPATO);
        tavoloRepository.save(tavolo);

        return ordineRepository.save(ordine);
    }

    public Optional<Ordine> getOrdineById(int id) {
        return ordineRepository.findById(id);
    }

    public List<Ordine> getAllOrdini() {
        return ordineRepository.findAll();
    }

    public Ordine aggiornaStatoOrdine(int ordineId, String nuovoStato) {
        if (!isValidStatoOrdine(nuovoStato)) {
            throw new IllegalArgumentException("Stato ordine non valido: " + nuovoStato);
        }

        Ordine ordine = ordineRepository.findById(ordineId)
                .orElseThrow(() -> new IllegalArgumentException("Ordine non trovato con ID: " + ordineId));

        ordine.setStatoOrdine(nuovoStato);
        if (nuovoStato.equals(STATO_COMPLETATO) || nuovoStato.equals(STATO_ANNULLATO)) {
            Tavolo tavolo = ordine.getTavolo();
            if (tavolo != null) {
                tavolo.setStato(Tavolo.STATO_LIBERO);
                tavoloRepository.save(tavolo);
            }
        }
        return ordineRepository.save(ordine);
    }

    public void eliminaOrdine(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID Ordine non valido per l'eliminazione.");
        }
        Optional<Ordine> ordineOpt = ordineRepository.findById(id);
        if (ordineOpt.isPresent()) {
            Ordine ordine = ordineOpt.get();
            Tavolo tavolo = ordine.getTavolo();
            if (tavolo != null) {
                tavolo.setStato(Tavolo.STATO_LIBERO);
                tavoloRepository.save(tavolo);
            }
            ordineRepository.deleteById(id);
        } else {
            throw new IllegalArgumentException("Ordine non trovato con ID: " + id + " per l'eliminazione.");
        }
    }

    public double calcolaTotaleOrdine(int ordineId) {
        Ordine ordine = ordineRepository.findById(ordineId)
                .orElseThrow(() -> new IllegalArgumentException("Ordine non trovato con ID: " + ordineId));
        return ordine.calcolaTotale();
    }

    public List<Ordine> getOrdiniByStato(String stato) {
        if (!isValidStatoOrdine(stato)) {
            throw new IllegalArgumentException("Stato ordine non valido: " + stato);
        }
        return ordineRepository.findByStato(stato);
    }

    private boolean isValidStatoOrdine(String stato) {
        return stato.equals(STATO_IN_PREPARAZIONE) ||
                stato.equals(STATO_PRONTO) ||
                stato.equals(STATO_SERVITO) ||
                stato.equals(STATO_COMPLETATO) ||
                stato.equals(STATO_ANNULLATO);
    }
}