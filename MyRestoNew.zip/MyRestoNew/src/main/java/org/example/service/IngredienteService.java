package org.example.service;

import org.example.model.Ingrediente;
import org.example.repository.IngredienteRepository;

import java.util.List;
import java.util.Optional;

public class IngredienteService {
    private final IngredienteRepository ingredienteRepository;

    public IngredienteService(IngredienteRepository ingredienteRepository) {
        this.ingredienteRepository = ingredienteRepository;
    }

    public Ingrediente aggiungiNuovoIngrediente(String nome, float prezzo) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Il nome dell'ingrediente non può essere vuoto.");
        }
        if (prezzo < 0) {
            throw new IllegalArgumentException("Il prezzo dell'ingrediente non può essere negativo.");
        }
        if (ingredienteRepository.findByNome(nome).isPresent()) {
            throw new IllegalArgumentException("Esiste già un ingrediente con questo nome: " + nome);
        }
        Ingrediente ingrediente = new Ingrediente(ingredienteRepository.getNextId(), nome, prezzo);
        return ingredienteRepository.save(ingrediente);
    }

    public Optional<Ingrediente> getIngredienteById(int id) {
        return ingredienteRepository.findById(id);
    }

    public Optional<Ingrediente> getIngredienteByNome(String nome) {
        return ingredienteRepository.findByNome(nome);
    }

    public List<Ingrediente> getAllIngredienti() {
        return ingredienteRepository.findAll();
    }

    public Ingrediente aggiornaIngrediente(Ingrediente ingrediente) {
        if (ingrediente == null || ingrediente.getId() <= 0) {
            throw new IllegalArgumentException("Ingrediente non valido per l'aggiornamento.");
        }
        if (ingrediente.getPrezzo() < 0) {
            throw new IllegalArgumentException("Il prezzo dell'ingrediente non può essere negativo.");
        }
        Optional<Ingrediente> existingIng = ingredienteRepository.findByNome(ingrediente.getNome());
        if (existingIng.isPresent() && existingIng.get().getId() != ingrediente.getId()) {
            throw new IllegalArgumentException("Esiste già un altro ingrediente con questo nome.");
        }
        return ingredienteRepository.save(ingrediente);
    }

    public void eliminaIngrediente(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID ingrediente non valido per l'eliminazione.");
        }
        ingredienteRepository.deleteById(id);
    }
}
