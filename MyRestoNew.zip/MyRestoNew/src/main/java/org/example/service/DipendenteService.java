package org.example.service;

import org.example.model.Dipendente;
import org.example.repository.DipendenteRepository;

import java.util.List;
import java.util.Optional;

public class DipendenteService {
    private final DipendenteRepository dipendenteRepository;

    public DipendenteService(DipendenteRepository dipendenteRepository) {
        this.dipendenteRepository = dipendenteRepository;
    }

    public Dipendente aggiungiNuovoDipendente(String nome, String cognome, String ruolo) {
        if (nome == null || nome.trim().isEmpty() || cognome == null || cognome.trim().isEmpty() || ruolo == null || ruolo.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome, cognome e ruolo del dipendente non possono essere vuoti.");
        }
        Dipendente dipendente = new Dipendente(dipendenteRepository.getNextId(), nome, cognome, ruolo);
        return dipendenteRepository.save(dipendente);
    }

    public Optional<Dipendente> getDipendenteById(int id) {
        return dipendenteRepository.findById(id);
    }

    public List<Dipendente> getAllDipendenti() {
        return dipendenteRepository.findAll();
    }

    public List<Dipendente> getDipendentiByRuolo(String ruolo) {
        if (ruolo == null || ruolo.trim().isEmpty()) {
            throw new IllegalArgumentException("Il ruolo non può essere vuoto.");
        }
        return dipendenteRepository.findByRuolo(ruolo);
    }

    public Dipendente aggiornaDipendente(Dipendente dipendente) {
        if (dipendente == null || dipendente.getId() <= 0) {
            throw new IllegalArgumentException("Dipendente non valido per l'aggiornamento.");
        }
        return dipendenteRepository.save(dipendente);
    }

    public void eliminaDipendente(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID dipendente non valido per l'eliminazione.");
        }
        dipendenteRepository.deleteById(id);
    }
}
