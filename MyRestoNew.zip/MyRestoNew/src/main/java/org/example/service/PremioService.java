package org.example.service;

import org.example.model.Premio;
import org.example.model.FidelityCard;
import org.example.model.PremioRiscattato;
import org.example.repository.PremioRepository;
import org.example.repository.FidelityCardRepository;
import org.example.repository.PremioRiscattatoRepository;

import java.util.List;
import java.util.Optional;

public class PremioService {
    private final PremioRepository premioRepository;
    private final FidelityCardRepository fidelityCardRepository;
    private final PremioRiscattatoRepository premioRiscattatoRepository;
    private final FidelityCardService fidelityCardService;

    public PremioService(PremioRepository premioRepository, FidelityCardRepository fidelityCardRepository,
                         PremioRiscattatoRepository premioRiscattatoRepository, FidelityCardService fidelityCardService) {
        this.premioRepository = premioRepository;
        this.fidelityCardRepository = fidelityCardRepository;
        this.premioRiscattatoRepository = premioRiscattatoRepository;
        this.fidelityCardService = fidelityCardService;
    }

    public Premio creaNuovoPremio(String nome, String descrizione, int puntiNecessari) {
        if (nome == null || nome.trim().isEmpty() || puntiNecessari <= 0) {
            throw new IllegalArgumentException("Nome o punti necessari del premio non validi.");
        }
        if (premioRepository.findByNome(nome).isPresent()) {
            throw new IllegalArgumentException("Esiste già un premio con questo nome: " + nome);
        }
        Premio premio = new Premio(premioRepository.getNextId(), nome, descrizione, puntiNecessari);
        return premioRepository.save(premio);
    }

    public Optional<Premio> getPremioById(int id) {
        return premioRepository.findById(id);
    }

    public Optional<Premio> getPremioByNome(String nome) {
        return premioRepository.findByNome(nome);
    }

    public List<Premio> getAllPremi() {
        return premioRepository.findAll();
    }

    public Premio aggiornaPremio(Premio premio) {
        if (premio == null || premio.getId() <= 0) {
            throw new IllegalArgumentException("Premio non valido per l'aggiornamento.");
        }
        if (premio.getPuntiNecessari() <= 0) {
            throw new IllegalArgumentException("I punti necessari per il premio devono essere maggiori di zero.");
        }
        Optional<Premio> existingPremio = premioRepository.findByNome(premio.getNome());
        if (existingPremio.isPresent() && existingPremio.get().getId() != premio.getId()) {
            throw new IllegalArgumentException("Esiste già un altro premio con questo nome.");
        }
        return premioRepository.save(premio);
    }

    public void eliminaPremio(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID premio non valido per l'eliminazione.");
        }
        premioRepository.deleteById(id);
    }

    public PremioRiscattato riscattaPremio(int clienteId, int premioId) {
        Premio premio = premioRepository.findById(premioId)
                .orElseThrow(() -> new IllegalArgumentException("Premio non trovato con ID: " + premioId));

        FidelityCard fidelityCard = fidelityCardRepository.findByClienteId(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Fidelity Card non trovata per il cliente con ID: " + clienteId));

        if (fidelityCard.getPuntiAccumulati() < premio.getPuntiNecessari()) {
            throw new IllegalStateException("Punti insufficienti (" + fidelityCard.getPuntiAccumulati() + ") per riscattare il premio '" + premio.getNome() + "' (necessari: " + premio.getPuntiNecessari() + ").");
        }

        fidelityCardService.rimuoviPunti(fidelityCard.getIdCard(), premio.getPuntiNecessari());

        PremioRiscattato riscattato = new PremioRiscattato(premioRiscattatoRepository.getNextId(), fidelityCard.getCliente(), premio, java.time.LocalDateTime.now());
        return premioRiscattatoRepository.save(riscattato);
    }
}
