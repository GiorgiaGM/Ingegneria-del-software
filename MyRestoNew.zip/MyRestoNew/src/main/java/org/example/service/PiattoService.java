package org.example.service;

import org.example.model.Piatto;
import org.example.model.Ingrediente;
import org.example.repository.PiattoRepository;
import org.example.repository.IngredienteRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class PiattoService {
    private final PiattoRepository piattoRepository;
    private final IngredienteRepository ingredienteRepository;

    public PiattoService(PiattoRepository piattoRepository, IngredienteRepository ingredienteRepository) {
        this.piattoRepository = piattoRepository;
        this.ingredienteRepository = ingredienteRepository;
    }

    public Piatto creaPiatto(String nome, String descrizione, float prezzo, List<Integer> ingredientiIds) {
        if (nome == null || nome.trim().isEmpty() || prezzo <= 0) {
            throw new IllegalArgumentException("Nome o prezzo del piatto non validi.");
        }
        if (piattoRepository.findByNome(nome).isPresent()) {
            throw new IllegalArgumentException("Esiste già un piatto con questo nome: " + nome);
        }

        List<Ingrediente> ingredienti = new ArrayList<>();
        if (ingredientiIds != null) {
            for (Integer ingId : ingredientiIds) {
                Ingrediente ingrediente = ingredienteRepository.findById(ingId)
                        .orElseThrow(() -> new IllegalArgumentException("Ingrediente non trovato con ID: " + ingId));
                ingredienti.add(ingrediente);
            }
        }

        Piatto piatto = new Piatto(piattoRepository.getNextId(), nome, descrizione, prezzo, ingredienti);
        return piattoRepository.save(piatto);
    }

    public Optional<Piatto> getPiattoById(int id) {
        return piattoRepository.findById(id);
    }

    public Optional<Piatto> getPiattoByNome(String nome) {
        return piattoRepository.findByNome(nome);
    }

    public List<Piatto> getAllPiatti() {
        return piattoRepository.findAll();
    }

    public List<Piatto> getPiattiSottoPrezzo(float prezzoMax) {
        if (prezzoMax <= 0) {
            throw new IllegalArgumentException("Il prezzo massimo deve essere maggiore di zero.");
        }
        return piattoRepository.findByPrezzoLessThanEqual(prezzoMax);
    }

    public Piatto aggiornaPiatto(Piatto piatto) {
        if (piatto == null || piatto.getId() <= 0) {
            throw new IllegalArgumentException("Piatto non valido per l'aggiornamento.");
        }
        if (piatto.getPrezzo() <= 0) {
            throw new IllegalArgumentException("Il prezzo del piatto deve essere maggiore di zero.");
        }
        Optional<Piatto> existingPiatto = piattoRepository.findByNome(piatto.getNome());
        if (existingPiatto.isPresent() && existingPiatto.get().getId() != piatto.getId()) {
            throw new IllegalArgumentException("Esiste già un altro piatto con questo nome.");
        }
        if (piatto.getIngredienti() != null) {
            for (Ingrediente ing : piatto.getIngredienti()) {
                ingredienteRepository.findById(ing.getId())
                        .orElseThrow(() -> new IllegalArgumentException("Ingrediente associato con ID " + ing.getId() + " non trovato."));
            }
        }
        return piattoRepository.save(piatto);
    }

    public void eliminaPiatto(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID piatto non valido per l'eliminazione.");
        }
        piattoRepository.deleteById(id);
    }

    public Piatto aggiungiIngredienteAPiatto(int piattoId, int ingredienteId) {
        Piatto piatto = piattoRepository.findById(piattoId)
                .orElseThrow(() -> new IllegalArgumentException("Piatto non trovato con ID: " + piattoId));
        Ingrediente ingrediente = ingredienteRepository.findById(ingredienteId)
                .orElseThrow(() -> new IllegalArgumentException("Ingrediente non trovato con ID: " + ingredienteId));

        piatto.addIngrediente(ingrediente);
        return piattoRepository.save(piatto);
    }

    public Piatto rimuoviIngredienteDaPiatto(int piattoId, int ingredienteId) {
        Piatto piatto = piattoRepository.findById(piattoId)
                .orElseThrow(() -> new IllegalArgumentException("Piatto non trovato con ID: " + piattoId));
        Ingrediente ingrediente = ingredienteRepository.findById(ingredienteId)
                .orElseThrow(() -> new IllegalArgumentException("Ingrediente non trovato con ID: " + ingredienteId));

        piatto.removeIngrediente(ingrediente);
        return piattoRepository.save(piatto);
    }
}