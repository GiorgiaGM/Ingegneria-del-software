package org.example.service;

import org.example.model.Feedback;
import org.example.model.Cliente;
import org.example.model.Piatto;
import org.example.repository.FeedbackRepository;
import org.example.repository.ClienteRepository;
import org.example.repository.PiattoRepository;

import java.util.List;
import java.util.Optional;

public class FeedbackService {
    private final FeedbackRepository feedbackRepository;
    private final ClienteRepository clienteRepository;
    private final PiattoRepository piattoRepository;

    public FeedbackService(FeedbackRepository feedbackRepository, ClienteRepository clienteRepository, PiattoRepository piattoRepository) {
        this.feedbackRepository = feedbackRepository;
        this.clienteRepository = clienteRepository;
        this.piattoRepository = piattoRepository;
    }

    public Feedback aggiungiFeedback(int clienteId, Optional<Integer> piattoId, String commento, int valutazione) {
        if (commento == null || commento.trim().isEmpty()) {
            throw new IllegalArgumentException("Il commento non può essere vuoto.");
        }
        if (valutazione < 1 || valutazione > 5) {
            throw new IllegalArgumentException("La valutazione deve essere tra 1 e 5.");
        }

        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente non trovato con ID: " + clienteId));

        Piatto piatto = null;
        if (piattoId.isPresent()) {
            piatto = piattoRepository.findById(piattoId.get())
                    .orElseThrow(() -> new IllegalArgumentException("Piatto non trovato con ID: " + piattoId.get()));
        }

        Feedback feedback = new Feedback(feedbackRepository.getNextId(), cliente, piatto, valutazione, commento);
        return feedbackRepository.save(feedback);
    }

    public Optional<Feedback> getFeedbackById(int id) {
        return feedbackRepository.findById(id);
    }

    public List<Feedback> getAllFeedback() {
        return feedbackRepository.findAll();
    }

    public List<Feedback> getFeedbackByPiatto(int piattoId) {
        Piatto piatto = piattoRepository.findById(piattoId)
                .orElseThrow(() -> new IllegalArgumentException("Piatto non trovato con ID: " + piattoId));
        return feedbackRepository.findByPiatto(piatto);
    }

    public List<Feedback> getFeedbackByCliente(int clienteId) {
        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente non trovato con ID: " + clienteId));
        return feedbackRepository.findByCliente(cliente);
    }

    public List<Feedback> getFeedbackByValutazioneGreaterThanEqual(int valutazioneMin) {
        if (valutazioneMin < 1 || valutazioneMin > 5) {
            throw new IllegalArgumentException("La valutazione minima deve essere tra 1 e 5.");
        }
        return feedbackRepository.findByValutazioneGreaterThanEqual(valutazioneMin);
    }

    public Feedback aggiornaFeedback(Feedback feedback) {
        if (feedback == null || feedback.getId() <= 0) {
            throw new IllegalArgumentException("Feedback non valido per l'aggiornamento.");
        }
        if (feedback.getValutazione() < 1 || feedback.getValutazione() > 5) {
            throw new IllegalArgumentException("La valutazione deve essere tra 1 e 5.");
        }
        clienteRepository.findById(feedback.getCliente().getId())
                .orElseThrow(() -> new IllegalArgumentException("Cliente associato non trovato."));
        if (feedback.getPiatto() != null) {
            piattoRepository.findById(feedback.getPiatto().getId())
                    .orElseThrow(() -> new IllegalArgumentException("Piatto associato non trovato."));
        }
        return feedbackRepository.save(feedback);
    }

    public void eliminaFeedback(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID feedback non valido per l'eliminazione.");
        }
        feedbackRepository.deleteById(id);
    }
}