package org.example.service;

import org.example.model.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public class MyRestoService {
    private final ClienteService clienteService;
    private final PiattoService piattoService;
    private final TavoloService tavoloService;
    private final PrenotazioneService prenotazioneService;
    private final OrdineService ordineService;
    private final PagamentoService pagamentoService;
    private final FeedbackService feedbackService;
    private final FidelityCardService fidelityCardService;
    private final PremioService premioService;
    private final IngredienteService ingredienteService;
    private final DipendenteService dipendenteService;
    private final TurnoService turnoService;
    private final RigaOrdineService rigaOrdineService;
    private final VariazioneService variazioneService;
    private final ReportService reportService;
    private final MenuService menuService;


    public MyRestoService(ClienteService clienteService, PiattoService piattoService, TavoloService tavoloService,
                          PrenotazioneService prenotazioneService, OrdineService ordineService, PagamentoService pagamentoService,
                          FeedbackService feedbackService, FidelityCardService fidelityCardService, PremioService premioService,
                          IngredienteService ingredienteService, DipendenteService dipendenteService, TurnoService turnoService,
                          RigaOrdineService rigaOrdineService, VariazioneService variazioneService, ReportService reportService, MenuService menuService) {
        this.clienteService = clienteService;
        this.piattoService = piattoService;
        this.tavoloService = tavoloService;
        this.prenotazioneService = prenotazioneService;
        this.ordineService = ordineService;
        this.pagamentoService = pagamentoService;
        this.feedbackService = feedbackService;
        this.fidelityCardService = fidelityCardService;
        this.premioService = premioService;
        this.ingredienteService = ingredienteService;
        this.dipendenteService = dipendenteService;
        this.turnoService = turnoService;
        this.rigaOrdineService = rigaOrdineService;
        this.variazioneService = variazioneService;
        this.reportService = reportService;
        this.menuService = menuService;
    }

    public Cliente registraNuovoCliente(String nome, String cognome, String email) {
        return clienteService.registraNuovoCliente(nome, cognome, email);
    }

    public Optional<Cliente> cercaClientePerId(int id) {
        return clienteService.getClienteById(id);
    }

    public Optional<Cliente> cercaClientePerEmail(String email) {
        return clienteService.getClienteByEmail(email);
    }

    public List<Cliente> getAllClienti() {
        return clienteService.getAllClienti();
    }

    public Cliente aggiornaCliente(Cliente cliente) {
        return clienteService.aggiornaCliente(cliente);
    }

    public void eliminaCliente(int id) {
        clienteService.eliminaCliente(id);
    }

    public Piatto creaPiatto(String nome, String descrizione, float prezzo, List<Integer> ingredientiIds) {
        return piattoService.creaPiatto(nome, descrizione, prezzo, ingredientiIds);
    }

    public Optional<Piatto> cercaPiattoPerId(int id) {
        return piattoService.getPiattoById(id);
    }

    public List<Piatto> getAllPiatti() {
        return piattoService.getAllPiatti();
    }

    public Ingrediente aggiungiNuovoIngrediente(String nome, float prezzo) {
        return ingredienteService.aggiungiNuovoIngrediente(nome, prezzo);
    }

    public Optional<Ingrediente> cercaIngredientePerId(int id) {
        return ingredienteService.getIngredienteById(id);
    }

    public List<Ingrediente> getAllIngredienti() {
        return ingredienteService.getAllIngredienti();
    }

    public Piatto aggiungiIngredienteAPiatto(int piattoId, int ingredienteId) {
        return piattoService.aggiungiIngredienteAPiatto(piattoId, ingredienteId);
    }
    public RigaOrdine aggiungiRigaOrdine(int ordineId, int piattoId, int quantita, String note, List<Integer> variazioniIds) {
        return rigaOrdineService.creaRigaOrdine(ordineId, piattoId, quantita, note, variazioniIds);
    }
    public Tavolo creaTavolo(int numeroTavolo, int numPosti) {
        return tavoloService.creaTavolo(numeroTavolo, numPosti);
    }

    public Optional<Tavolo> cercaTavoloPerNumero(int numeroTavolo) {
        return tavoloService.getTavoloByNumero(numeroTavolo);
    }

    public List<Tavolo> getTavoliDisponibiliPerPosti(int postiRichiesti) {
        return tavoloService.getTavoliDisponibiliPerPosti(postiRichiesti);
    }

    public Tavolo aggiornaStatoTavolo(int numeroTavolo, String nuovoStato) {
        return tavoloService.aggiornaStatoTavolo(numeroTavolo, nuovoStato);
    }

    public FidelityCardService getFidelityCardService() {
        return fidelityCardService;
    }

    public Prenotazione creaPrenotazione(int clienteId, LocalDate data, LocalTime ora, int numeroPersone, Optional<Integer> numeroTavoloAssegnato) {
        return prenotazioneService.creaPrenotazione(clienteId, data, ora, numeroPersone, numeroTavoloAssegnato);
    }

    public Optional<Prenotazione> cercaPrenotazionePerCodice(String codicePrenotazione) {
        return prenotazioneService.getPrenotazioneByCodice(codicePrenotazione);
    }

    public List<Prenotazione> getPrenotazioniPerData(LocalDate data) {
        return prenotazioneService.getPrenotazioniPerData(data);
    }

    public void eliminaPrenotazione(String codicePrenotazione) {
        prenotazioneService.eliminaPrenotazione(codicePrenotazione);
    }

    public Menu getFullMenu() {
        return menuService.getFullMenu();
    }

    public List<Piatto> getAllPiattiFromMenu() {
        return menuService.getAllPiattiFromMenu();
    }

    public List<Ingrediente> getAllIngredientiFromMenu() {
        return menuService.getAllIngredientiFromMenu();
    }

    public Ordine creaNuovoOrdine(int clienteId, int numeroTavolo) {
        return ordineService.creaNuovoOrdine(clienteId, numeroTavolo);
    }

    public Optional<Ordine> cercaOrdinePerId(int id) {
        return ordineService.getOrdineById(id);
    }

    public Ordine aggiornaStatoOrdine(int ordineId, String nuovoStato) {
        return ordineService.aggiornaStatoOrdine(ordineId, nuovoStato);
    }

    public double calcolaTotaleOrdine(int ordineId) {
        return ordineService.calcolaTotaleOrdine(ordineId);
    }

    public Pagamento registraPagamento(int ordineId, double importoPagato, Optional<Integer> fidelityCardId) {
        return pagamentoService.registraPagamento(ordineId, importoPagato, fidelityCardId);
    }

    public Feedback aggiungiFeedback(int clienteId, int piattoId, String commento, int valutazione) {
        return feedbackService.aggiungiFeedback(clienteId, Optional.of(piattoId), commento, valutazione);
    }

    public FidelityCard creaFidelityCardPerCliente(int clienteId) {
        return fidelityCardService.creaFidelityCardPerCliente(clienteId);
    }

    public FidelityCard aggiungiPuntiAFidelityCard(int cardId, int punti) {
        return fidelityCardService.aggiungiPunti(cardId, punti);
    }

    public Premio creaNuovoPremio(String nome, String descrizione, int puntiNecessari) {
        return premioService.creaNuovoPremio(nome, descrizione, puntiNecessari);
    }

    public PremioRiscattato riscattaPremio(int clienteId, int premioId) {
        return premioService.riscattaPremio(clienteId, premioId);
    }

    public Dipendente aggiungiNuovoDipendente(String nome, String cognome, String ruolo) {
        return dipendenteService.aggiungiNuovoDipendente(nome, cognome, ruolo);
    }

    public Turno assegnaTurno(int dipendenteId, LocalDate data, LocalTime ora, String tipoTurno) {
        return turnoService.assegnaTurno(dipendenteId, data, ora, tipoTurno);
    }

    public Report generaReportIncassi(LocalDate dataInizio, LocalDate dataFine) {
        return reportService.generaReportIncassi(dataInizio, dataFine);
    }

    public Report generaReportPiattiPiuVenduti(LocalDate dataInizio, LocalDate dataFine) {
        return reportService.generaReportPiattiPiuVenduti(dataInizio, dataFine);
    }

    public RigaOrdine aggiornaQuantitaRigaOrdine(int rigaId, int nuovaQuantita) {
        return rigaOrdineService.aggiornaQuantitaRigaOrdine(rigaId, nuovaQuantita);
    }

    public Variazione creaVariazione(String tipo, float costo) {
        return variazioneService.creaVariazione(tipo, costo);
    }

}
