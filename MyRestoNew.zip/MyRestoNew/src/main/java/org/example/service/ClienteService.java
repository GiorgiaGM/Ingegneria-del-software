package org.example.service;

import org.example.model.Cliente;
import org.example.repository.ClienteRepository;

import java.util.List;
import java.util.Optional;

public class ClienteService {
    private final ClienteRepository clienteRepository;

    public ClienteService(ClienteRepository clienteRepository) {
        this.clienteRepository = clienteRepository;
    }

    public Cliente registraNuovoCliente(String nome, String cognome, String email) {
        if (nome == null || nome.trim().isEmpty() || cognome == null || cognome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome e cognome del cliente non possono essere vuoti.");
        }
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("Email non valida.");
        }
        if (clienteRepository.findByEmail(email).isPresent()) {
            throw new IllegalArgumentException("Esiste già un cliente con questa email.");
        }
        Cliente cliente = new Cliente(clienteRepository.getNextId(), nome, cognome, email);
        return clienteRepository.save(cliente);
    }

    public Optional<Cliente> getClienteById(int id) {
        return clienteRepository.findById(id);
    }

    public Optional<Cliente> getClienteByEmail(String email) {
        return clienteRepository.findByEmail(email);
    }

    public List<Cliente> getAllClienti() {
        return clienteRepository.findAll();
    }

    public Cliente aggiornaCliente(Cliente cliente) {
        if (cliente == null || cliente.getId() <= 0) {
            throw new IllegalArgumentException("Cliente non valido per l'aggiornamento.");
        }
        Optional<Cliente> existingClient = clienteRepository.findByEmail(cliente.getEmail());
        if (existingClient.isPresent() && existingClient.get().getId() != cliente.getId()) {
            throw new IllegalArgumentException("Email già associata ad un altro cliente.");
        }
        return clienteRepository.save(cliente);
    }

    public void eliminaCliente(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID cliente non valido per l'eliminazione.");
        }
        clienteRepository.deleteById(id);
    }
}