package org.example.service;

import org.example.model.Turno;
import org.example.model.Dipendente;
import org.example.repository.TurnoRepository;
import org.example.repository.DipendenteRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.time.LocalTime;

public class TurnoService {
    private final TurnoRepository turnoRepository;
    private final DipendenteRepository dipendenteRepository;

    public TurnoService(TurnoRepository turnoRepository, DipendenteRepository dipendenteRepository) {
        this.turnoRepository = turnoRepository;
        this.dipendenteRepository = dipendenteRepository;
    }

    public Turno assegnaTurno(int dipendenteId, LocalDate data, LocalTime ora, String tipoTurno) {
        if (data == null || ora == null) {
            throw new IllegalArgumentException("Dati turno non validi: data o ora non possono essere null.");
        }
        if (tipoTurno == null || tipoTurno.trim().isEmpty()) {
            throw new IllegalArgumentException("Il tipo di turno non può essere vuoto.");
        }

        Dipendente dipendente = dipendenteRepository.findById(dipendenteId)
                .orElseThrow(() -> new IllegalArgumentException("Dipendente non trovato con ID: " + dipendenteId));

        List<Turno> turniEsistentiDelDipendenteInData = turnoRepository.findByDipendenteAndData(dipendente, data);
        if (!turniEsistentiDelDipendenteInData.isEmpty()) {
            throw new IllegalStateException("Il dipendente " + dipendente.getNome() + " ha già un turno assegnato per la data " + data + ".");
        }

        Turno turno = new Turno(turnoRepository.getNextId(), dipendente, data, ora, tipoTurno);
        return turnoRepository.save(turno);
    }

    public Optional<Turno> getTurnoById(int id) {
        return turnoRepository.findById(id);
    }

    public List<Turno> getAllTurni() {
        return turnoRepository.findAll();
    }

    public List<Turno> getTurniByDipendente(int dipendenteId) {
        Dipendente dipendente = dipendenteRepository.findById(dipendenteId)
                .orElseThrow(() -> new IllegalArgumentException("Dipendente non trovato con ID: " + dipendenteId));
        return turnoRepository.findByDipendente(dipendente);
    }

    public List<Turno> getTurniByData(LocalDate data) {
        return turnoRepository.findByData(data);
    }

    public Turno aggiornaTurno(Turno turno) {
        if (turno == null || turno.getId() <= 0) {
            throw new IllegalArgumentException("Turno non valido per l'aggiornamento.");
        }
        if (turno.getData() == null || turno.getOra() == null) {
            throw new IllegalArgumentException("La data o l'ora del turno non possono essere nulle.");
        }

        dipendenteRepository.findById(turno.getDipendente().getId())
                .orElseThrow(() -> new IllegalArgumentException("Dipendente associato non trovato per l'aggiornamento del turno."));

        List<Turno> turniEsistentiDelDipendenteExcludingCurrent = turnoRepository.findByDipendente(turno.getDipendente()).stream()
                .filter(t -> t.getId() != turno.getId())
                .collect(Collectors.toList());

        for (Turno t : turniEsistentiDelDipendenteExcludingCurrent) {
            if (t.getData().isEqual(turno.getData())) {
                throw new IllegalStateException("L'aggiornamento del turno per il dipendente " + turno.getDipendente().getNome() +
                        " causa una sovrapposizione con il turno esistente in data " + t.getData() + ".");
            }
        }

        return turnoRepository.save(turno);
    }

    public void eliminaTurno(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID turno non valido per l'eliminazione.");
        }
        turnoRepository.deleteById(id);
    }
}