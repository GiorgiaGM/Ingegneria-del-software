package org.example.service;

import org.example.model.Ingrediente;
import org.example.model.Menu;
import org.example.model.Piatto;
import org.example.repository.MenuRepository;

import java.util.List;

public class MenuService {

    private final MenuRepository menuRepository;

    public MenuService(MenuRepository menuRepository) {
        this.menuRepository = menuRepository;
    }

    public Menu getFullMenu() {
        List<Piatto> piatti = menuRepository.findAllPiatti();
        List<Ingrediente> ingredienti = menuRepository.findAllIngredienti();

        Menu menu = new Menu();
        menu.setPiatti(piatti);
        menu.setIngredientiDisponibili(ingredienti);
        return menu;
    }

    public List<Piatto> getAllPiattiFromMenu() {
        return menuRepository.findAllPiatti();
    }

    public List<Ingrediente> getAllIngredientiFromMenu() {
        return menuRepository.findAllIngredienti();
    }
}