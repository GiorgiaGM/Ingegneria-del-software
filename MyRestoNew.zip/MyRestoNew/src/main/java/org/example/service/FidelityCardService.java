package org.example.service;

import org.example.model.Cliente;
import org.example.model.FidelityCard;
import org.example.repository.FidelityCardRepository;
import org.example.repository.ClienteRepository;

import java.util.List;
import java.util.Optional;

public class FidelityCardService {

    private final FidelityCardRepository fidelityCardRepository;
    private final ClienteRepository clienteRepository;

    public FidelityCardService(FidelityCardRepository fidelityCardRepository, ClienteRepository clienteRepository) {
        this.fidelityCardRepository = fidelityCardRepository;
        this.clienteRepository = clienteRepository;
    }

    public FidelityCard creaFidelityCardPerCliente(int clienteId) {
        Optional<Cliente> clienteOpt = clienteRepository.findById(clienteId);
        if (clienteOpt.isEmpty()) {
            throw new IllegalArgumentException("Cliente non trovato con ID: " + clienteId);
        }
        Cliente cliente = clienteOpt.get();

        if (fidelityCardRepository.findByClienteId(clienteId).isPresent()) {
            throw new IllegalArgumentException("Il cliente " + cliente.getNome() + " ha già una Fidelity Card.");
        }

        int newId = fidelityCardRepository.getNextId();

        FidelityCard newCard = new FidelityCard(newId, cliente, 0); // Punti iniziali a 0
        return fidelityCardRepository.save(newCard);
    }

    public Optional<FidelityCard> getFidelityCardById(int idCard) {
        return fidelityCardRepository.findById(idCard);
    }

    public Optional<FidelityCard> getFidelityCardByCliente(int clienteId) {
        Optional<Cliente> clienteOpt = clienteRepository.findById(clienteId);
        if (clienteOpt.isEmpty()) {
            throw new IllegalArgumentException("Cliente non trovato con ID: " + clienteId);
        }
        return fidelityCardRepository.findByClienteId(clienteId);
    }

    public List<FidelityCard> getAllFidelityCards() {
        return fidelityCardRepository.findAll();
    }

    public FidelityCard aggiungiPunti(int cardId, int puntiDaAggiungere) {
        if (puntiDaAggiungere <= 0) {
            throw new IllegalArgumentException("I punti da aggiungere devono essere positivi.");
        }
        Optional<FidelityCard> cardOpt = fidelityCardRepository.findById(cardId);
        if (cardOpt.isEmpty()) {
            throw new IllegalArgumentException("Fidelity Card non trovata con ID: " + cardId);
        }
        FidelityCard card = cardOpt.get();
        card.setPuntiAccumulati(card.getPuntiAccumulati() + puntiDaAggiungere);
        return fidelityCardRepository.save(card);
    }

    public FidelityCard rimuoviPunti(int cardId, int puntiDaRimuovere) {
        if (puntiDaRimuovere <= 0) {
            throw new IllegalArgumentException("I punti da rimuovere devono essere positivi.");
        }
        Optional<FidelityCard> cardOpt = fidelityCardRepository.findById(cardId);
        if (cardOpt.isEmpty()) {
            throw new IllegalArgumentException("Fidelity Card non trovata con ID: " + cardId);
        }
        FidelityCard card = cardOpt.get();
        if (card.getPuntiAccumulati() < puntiDaRimuovere) {
            throw new IllegalArgumentException("Non ci sono abbastanza punti sulla card per questa operazione.");
        }
        card.setPuntiAccumulati(card.getPuntiAccumulati() - puntiDaRimuovere);
        return fidelityCardRepository.save(card);
    }

    public FidelityCard aggiornaFidelityCard(FidelityCard card) {
        if (card == null || card.getIdCard() <= 0) {
            throw new IllegalArgumentException("Fidelity Card non valida per l'aggiornamento.");
        }
        if (card.getCliente() != null) {
            Optional<Cliente> clienteOpt = clienteRepository.findById(card.getCliente().getId());
            if (clienteOpt.isEmpty()) {
                throw new IllegalArgumentException("Cliente associato non trovato.");
            }
        }
        return fidelityCardRepository.save(card);
    }

    public void eliminaFidelityCard(int idCard) {
        if (idCard <= 0) {
            throw new IllegalArgumentException("ID Fidelity Card non valido per l'eliminazione.");
        }
        fidelityCardRepository.deleteById(idCard);
    }
}