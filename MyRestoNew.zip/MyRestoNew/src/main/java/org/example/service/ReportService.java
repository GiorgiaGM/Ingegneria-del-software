package org.example.service;

import org.example.model.Report;
import org.example.model.Ordine;
import org.example.model.Pagamento;
import org.example.model.RigaOrdine;
import org.example.model.Piatto;
import org.example.repository.ReportRepository;
import org.example.repository.OrdineRepository;
import org.example.repository.PagamentoRepository;
import org.example.repository.RigaOrdineRepository;
import org.example.repository.PiattoRepository;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.Locale;

public class ReportService {
    private final ReportRepository reportRepository;
    private final OrdineRepository ordineRepository;
    private final PagamentoRepository pagamentoRepository;
    private final RigaOrdineRepository rigaOrdineRepository;
    private final PiattoRepository piattoRepository;


    public ReportService(ReportRepository reportRepository, OrdineRepository ordineRepository,
                         PagamentoRepository pagamentoRepository, RigaOrdineRepository rigaOrdineRepository,
                         PiattoRepository piattoRepository) {
        this.reportRepository = reportRepository;
        this.ordineRepository = ordineRepository;
        this.pagamentoRepository = pagamentoRepository;
        this.rigaOrdineRepository = rigaOrdineRepository;
        this.piattoRepository = piattoRepository;
    }

    public Report generaReportIncassi(LocalDate dataInizio, LocalDate dataFine) {
        if (dataInizio == null || dataFine == null || dataInizio.isAfter(dataFine)) {
            throw new IllegalArgumentException("Date di inizio e fine non valide per il report degli incassi.");
        }

        LocalDateTime inizioPeriodo = dataInizio.atStartOfDay();
        LocalDateTime finePeriodo = dataFine.atTime(LocalTime.MAX);

        List<Pagamento> pagamentiNelPeriodo = pagamentoRepository.findByDataPagamentoBetween(inizioPeriodo, finePeriodo);

        double incassoTotale = pagamentiNelPeriodo.stream()
                .mapToDouble(Pagamento::getTotale)
                .sum();

        String contenutoReport = String.format(
                Locale.US,
                "--- Report Incassi ---\n" +
                        "Periodo: dal %s al %s\n" +
                        "Numero di Pagamenti: %d\n" +
                        "Incasso Totale: %.2f EUR\n" +
                        "-----------------------",
                dataInizio.format(DateTimeFormatter.ISO_DATE),
                dataFine.format(DateTimeFormatter.ISO_DATE),
                pagamentiNelPeriodo.size(),
                incassoTotale
        );

        String tipoReport = "INCASSI";

        Report report = new Report(reportRepository.getNextId(), tipoReport, dataInizio, dataFine, contenutoReport);
        return reportRepository.save(report);
    }

    public Report generaReportPiattiPiuVenduti(LocalDate dataInizio, LocalDate dataFine) {
        if (dataInizio == null || dataFine == null || dataInizio.isAfter(dataFine)) {
            throw new IllegalArgumentException("Date di inizio e fine non valide per il report dei piatti più venduti.");
        }

        LocalDateTime inizioPeriodo = dataInizio.atStartOfDay();
        LocalDateTime finePeriodo = dataFine.atTime(LocalTime.MAX);

        List<Ordine> ordiniNelPeriodo = ordineRepository.findAll().stream()
                .filter(ordine -> {
                    LocalDateTime dataOrdine = ordine.getDataOraCreazione();
                    return !dataOrdine.isBefore(inizioPeriodo) && !dataOrdine.isAfter(finePeriodo);
                })
                .collect(Collectors.toList());

        Map<String, Integer> conteggioVendite = new HashMap<>();

        for (Ordine ordine : ordiniNelPeriodo) {
            List<RigaOrdine> righeOrdine = rigaOrdineRepository.findByOrdineId(ordine.getIdOrdine());

            for (RigaOrdine riga : righeOrdine) {
                Piatto piatto = riga.getPiatto();
                if (piatto != null) {
                    conteggioVendite.merge(piatto.getNome(), riga.getQuantita(), Integer::sum);
                } else {
                    System.err.println("Avviso: RigaOrdine con ID " + riga.getId() + " non ha un Piatto associato valido. Potrebbe esserci un problema di deserializzazione.");
                }
            }
        }

        LinkedHashMap<String, Integer> piattiOrdinati = conteggioVendite.entrySet().stream()
                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
                .collect(Collectors.toMap(
                        Map.Entry::getKey,
                        Map.Entry::getValue,
                        (e1, e2) -> e1,
                        LinkedHashMap::new
                ));

        StringBuilder contenutoReport = new StringBuilder();
        contenutoReport.append("--- Report Piatti Più Venduti ---\n");
        contenutoReport.append(String.format("Periodo: dal %s al %s\n",
                dataInizio.format(DateTimeFormatter.ISO_DATE),
                dataFine.format(DateTimeFormatter.ISO_DATE)));
        contenutoReport.append("----------------------------------\n");

        if (piattiOrdinati.isEmpty()) {
            contenutoReport.append("Nessun piatto venduto nel periodo selezionato.\n");
        } else {
            piattiOrdinati.forEach((nomePiatto, quantita) ->
                    contenutoReport.append(String.format("%s: %d unità\n", nomePiatto, quantita))
            );
        }
        contenutoReport.append("----------------------------------\n");

        String tipoReport = "PIATTI_PIU_VENDUTI";

        Report report = new Report(reportRepository.getNextId(), tipoReport, dataInizio, dataFine, contenutoReport.toString());
        return reportRepository.save(report);
    }


    public Optional<Report> getReportById(int id) {
        return reportRepository.findById(id);
    }

    public List<Report> getAllReports() {
        return reportRepository.findAll();
    }

    public List<Report> getReportsByTipo(String tipo) {
        if (tipo == null || tipo.trim().isEmpty()) {
            throw new IllegalArgumentException("Il tipo di report non può essere vuoto.");
        }
        return reportRepository.findByTipo(tipo);
    }

    public void eliminaReport(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID report non valido per l'eliminazione.");
        }
        reportRepository.deleteById(id);
    }
}