package org.example.service;

import org.example.model.Prenotazione;
import org.example.model.Cliente;
import org.example.model.Tavolo;
import org.example.repository.PrenotazioneRepository;
import org.example.repository.ClienteRepository;
import org.example.repository.TavoloRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;


public class PrenotazioneService {
    private final PrenotazioneRepository prenotazioneRepository;
    private final ClienteRepository clienteRepository;
    private final TavoloRepository tavoloRepository;

    public PrenotazioneService(PrenotazioneRepository prenotazioneRepository, ClienteRepository clienteRepository, TavoloRepository tavoloRepository) {
        this.prenotazioneRepository = prenotazioneRepository;
        this.clienteRepository = clienteRepository;
        this.tavoloRepository = tavoloRepository;
    }

    public Prenotazione creaPrenotazione(int clienteId, LocalDate data, LocalTime ora, int numeroPersone, Optional<Integer> numeroTavoloAssegnato) {
        // Validazioni iniziali
        if (data == null || ora == null || numeroPersone <= 0) {
            throw new IllegalArgumentException("Data, ora o numero di persone non validi.");
        }
        if (data.isBefore(LocalDate.now()) || (data.isEqual(LocalDate.now()) && ora.isBefore(LocalTime.now()))) {
            throw new IllegalArgumentException("Impossibile creare una prenotazione nel passato.");
        }

        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente non trovato con ID: " + clienteId));

        Tavolo tavolo = null;
        if (numeroTavoloAssegnato.isPresent()) {
            tavolo = tavoloRepository.findByNumeroTavolo(numeroTavoloAssegnato.get())
                    .orElseThrow(() -> new IllegalArgumentException("Tavolo non trovato con numero: " + numeroTavoloAssegnato.get()));

            if (prenotazioneRepository.findByDataOraTavolo(data, ora, tavolo).isPresent() ||
                    tavolo.isOccupato() ||
                    tavolo.isRiservato()) {
                throw new IllegalStateException("Il tavolo " + numeroTavoloAssegnato.get() + " non è disponibile per l'orario richiesto o è già occupato/riservato.");
            }
        } else {
            List<Tavolo> tavoliDisponibili = tavoloRepository.findByStato(Tavolo.STATO_LIBERO);
            Optional<Tavolo> trovatoTavolo = tavoliDisponibili.stream()
                    .filter(t -> t.getNumPosti() >= numeroPersone)
                    .filter(t -> prenotazioneRepository.findByDataOraTavolo(data, ora, t).isEmpty())
                    .findFirst();

            if (trovatoTavolo.isPresent()) {
                tavolo = trovatoTavolo.get();
            } else {
                throw new IllegalStateException("Nessun tavolo disponibile per " + numeroPersone + " persone all'orario specificato.");
            }
        }

        String codicePrenotazione = prenotazioneRepository.getNextId();

        Prenotazione prenotazione = new Prenotazione(codicePrenotazione, cliente, data, ora, numeroPersone, tavolo, Prenotazione.STATO_ATTIVA);

        if(tavolo != null) {
            tavolo.setStato(Tavolo.STATO_RISERVATO);
            tavoloRepository.save(tavolo);
        }
        return prenotazioneRepository.save(prenotazione);
    }

    public Optional<Prenotazione> getPrenotazioneByCodice(String codicePrenotazione) {
        return prenotazioneRepository.findById(codicePrenotazione);
    }

    public List<Prenotazione> getAllPrenotazioni() {
        return prenotazioneRepository.findAll();
    }

    public List<Prenotazione> getPrenotazioniPerData(LocalDate data) {
        return prenotazioneRepository.findByData(data);
    }

    public List<Prenotazione> getPrenotazioniPerCliente(int clienteId) {
        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente non trovato con ID: " + clienteId));
        return prenotazioneRepository.findByCliente(cliente);
    }

    public Prenotazione aggiornaPrenotazione(Prenotazione prenotazione) {
        if (prenotazione == null || prenotazione.getCodicePrenotazione() == null || prenotazione.getCodicePrenotazione().trim().isEmpty()) {
            throw new IllegalArgumentException("Prenotazione non valida per l'aggiornamento (codice prenotazione mancante).");
        }
        clienteRepository.findById(prenotazione.getCliente().getId())
                .orElseThrow(() -> new IllegalArgumentException("Cliente associato non trovato."));
        if (prenotazione.getTavoloAssegnato() != null) {
            tavoloRepository.findByNumeroTavolo(prenotazione.getTavoloAssegnato().getNumeroTavolo())
                    .orElseThrow(() -> new IllegalArgumentException("Tavolo associato non trovato."));
        }
        return prenotazioneRepository.save(prenotazione);
    }

    public void eliminaPrenotazione(String codicePrenotazione) {
        if (codicePrenotazione == null || codicePrenotazione.trim().isEmpty()) {
            throw new IllegalArgumentException("Codice prenotazione non valido per l'eliminazione.");
        }
        Optional<Prenotazione> prenotazioneOpt = prenotazioneRepository.findById(codicePrenotazione);
        if (prenotazioneOpt.isPresent()) {
            Prenotazione prenotazione = prenotazioneOpt.get();
            if (prenotazione.getTavoloAssegnato() != null) {
                Tavolo tavolo = prenotazione.getTavoloAssegnato();
                boolean isOnlyReservationForTime = prenotazioneRepository.findByDataOraTavolo(prenotazione.getData(), prenotazione.getOra(), tavolo)
                        .map(p -> p.getCodicePrenotazione().equals(prenotazione.getCodicePrenotazione()))
                        .orElse(false);

                if (isOnlyReservationForTime && !tavolo.isOccupato()) {
                    tavolo.setStato(Tavolo.STATO_LIBERO);
                    tavoloRepository.save(tavolo);
                }
            }
        }
        prenotazioneRepository.deleteById(codicePrenotazione);
    }
}