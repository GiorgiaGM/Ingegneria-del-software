package org.example.service;

import org.example.model.PremioRiscattato;
import org.example.model.Cliente;
import org.example.model.Premio;
import org.example.repository.PremioRiscattatoRepository;
import org.example.repository.ClienteRepository;
import org.example.repository.PremioRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public class PremioRiscattatoService {
    private final PremioRiscattatoRepository premioRiscattatoRepository;
    private final ClienteRepository clienteRepository;
    private final PremioRepository premioRepository;

    public PremioRiscattatoService(PremioRiscattatoRepository premioRiscattatoRepository, ClienteRepository clienteRepository, PremioRepository premioRepository) {
        this.premioRiscattatoRepository = premioRiscattatoRepository;
        this.clienteRepository = clienteRepository;
        this.premioRepository = premioRepository;
    }

    public PremioRiscattato registraRiscossionePremio(int clienteId, int premioId) {
        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente non trovato con ID: " + clienteId));
        Premio premio = premioRepository.findById(premioId)
                .orElseThrow(() -> new IllegalArgumentException("Premio non trovato con ID: " + premioId));

        PremioRiscattato premioRiscattato = new PremioRiscattato(premioRiscattatoRepository.getNextId(), cliente, premio, LocalDateTime.now());
        return premioRiscattatoRepository.save(premioRiscattato);
    }

    public Optional<PremioRiscattato> getPremioRiscattatoById(int id) {
        return premioRiscattatoRepository.findById(id);
    }

    public List<PremioRiscattato> getAllPremiRiscattati() {
        return premioRiscattatoRepository.findAll();
    }

    public List<PremioRiscattato> getPremiRiscattatiByCliente(int clienteId) {
        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente non trovato con ID: " + clienteId));
        return premioRiscattatoRepository.findByCliente(cliente);
    }

    public List<PremioRiscattato> getPremiRiscattatiByPremio(int premioId) {
        Premio premio = premioRepository.findById(premioId)
                .orElseThrow(() -> new IllegalArgumentException("Premio non trovato con ID: " + premioId));
        return premioRiscattatoRepository.findByPremio(premio);
    }

    public void eliminaPremioRiscattato(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID Premio Riscattato non valido per l'eliminazione.");
        }
        premioRiscattatoRepository.deleteById(id);
    }
}