package org.example.service;

import org.example.model.Tavolo;
import org.example.repository.TavoloRepository;

import java.util.List;
import java.util.Optional;

public class TavoloService {
    private final TavoloRepository tavoloRepository;

    public TavoloService(TavoloRepository tavoloRepository) {
        this.tavoloRepository = tavoloRepository;
    }

    public Tavolo creaTavolo(int numeroTavolo, int numPosti) {
        if (tavoloRepository.findByNumeroTavolo(numeroTavolo).isPresent()) {
            throw new IllegalArgumentException("Tavolo con numero " + numeroTavolo + " esiste già.");
        }
        Tavolo nuovoTavolo = new Tavolo(numeroTavolo, numPosti, Tavolo.STATO_LIBERO);
        return tavoloRepository.save(nuovoTavolo);
    }

    public Optional<Tavolo> getTavoloByNumero(int numeroTavolo) {
        return tavoloRepository.findByNumeroTavolo(numeroTavolo);
    }

    public List<Tavolo> getAllTavoli() {
        return tavoloRepository.findAll();
    }

    public Tavolo aggiornaStatoTavolo(int numeroTavolo, String nuovoStato) {
        Tavolo tavolo = tavoloRepository.findByNumeroTavolo(numeroTavolo)
                .orElseThrow(() -> new IllegalArgumentException("Tavolo non trovato con numero: " + numeroTavolo));
        tavolo.setStato(nuovoStato);
        return tavoloRepository.save(tavolo);
    }
    public List<Tavolo> getTavoliDisponibiliPerPosti(int postiRichiesti) {
        return tavoloRepository.findByNumPostiAndStato(postiRichiesti, Tavolo.STATO_LIBERO);
    }

    public void eliminaTavolo(int numeroTavolo) {
        if (numeroTavolo <= 0) {
            throw new IllegalArgumentException("Numero Tavolo non valido per l'eliminazione.");
        }
        Tavolo tavolo = tavoloRepository.findByNumeroTavolo(numeroTavolo)
                .orElseThrow(() -> new IllegalArgumentException("Tavolo non trovato con numero: " + numeroTavolo));
        if (tavolo.isOccupato()) {
            throw new IllegalStateException("Impossibile eliminare il tavolo " + numeroTavolo + " perché è occupato.");
        }
        tavoloRepository.deleteById(numeroTavolo);
    }
}