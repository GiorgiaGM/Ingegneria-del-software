package org.example.service;

import org.example.model.Variazione;
import org.example.repository.VariazioneRepository;

import java.util.List;
import java.util.Optional;

public class VariazioneService {
    private final VariazioneRepository variazioneRepository;

    public VariazioneService(VariazioneRepository variazioneRepository) {
        this.variazioneRepository = variazioneRepository;
    }

    public Variazione creaVariazione(String tipo, float costo) {
        if (tipo == null || tipo.trim().isEmpty()) {
            throw new IllegalArgumentException("Il tipo di variazione non può essere vuoto.");
        }
        Variazione variazione = new Variazione(variazioneRepository.getNextId(), tipo, costo);
        return variazioneRepository.save(variazione);
    }

    public Optional<Variazione> getVariazioneById(int id) {
        return variazioneRepository.findById(id);
    }

    public List<Variazione> getAllVariazioni() {
        return variazioneRepository.findAll();
    }

    public Variazione aggiornaVariazione(Variazione variazione) {
        if (variazione == null || variazione.getId() <= 0) {
            throw new IllegalArgumentException("Variazione non valida per l'aggiornamento.");
        }
        if (variazione.getTipo() == null || variazione.getTipo().trim().isEmpty()) {
            throw new IllegalArgumentException("Il tipo di variazione non può essere vuoto.");
        }
        return variazioneRepository.save(variazione);
    }

    public void eliminaVariazione(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID variazione non valido per l'eliminazione.");
        }
        variazioneRepository.deleteById(id);
    }
}
