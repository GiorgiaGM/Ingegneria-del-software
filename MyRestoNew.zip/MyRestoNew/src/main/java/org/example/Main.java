package org.example;

import org.example.model.*;
import org.example.repository.*;
import org.example.repository.impl.*;
import org.example.service.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.example.exception.AuthenticationException;

public class Main {

    private static final String DATA_DIR = "src/main/resources/data/";

    private static void cleanDataDirectory() {
        System.out.println("Pulizia della directory dei dati...");
        try {
            Path dataDirPath = Paths.get(DATA_DIR);
            if (Files.exists(dataDirPath) && Files.isDirectory(dataDirPath)) {
                Files.walk(dataDirPath)
                        .filter(Files::isRegularFile)
                        .forEach(file -> {
                            try {
                                if (!file.getFileName().toString().equals("amministratori.dat")) {
                                    Files.delete(file);
                                    System.out.println("Eliminato: " + file.getFileName());
                                } else {
                                    System.out.println("Mantenuto: " + file.getFileName());
                                }
                            } catch (Exception e) {
                                System.err.println("Errore durante l'eliminazione del file " + file.getFileName() + ": " + e.getMessage());
                            }
                        });
            }
            System.out.println("Pulizia completata.");
        } catch (Exception e) {
            System.err.println("Errore critico durante la pulizia della directory dei dati: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        cleanDataDirectory();

        // --- 1. Inizializzazione dei Repository con Holder e Supplier ---
        final ClienteRepository[] clienteRepositoryHolder = new ClienteRepository[1];
        final DipendenteRepository[] dipendenteRepositoryHolder = new DipendenteRepository[1];
        final IngredienteRepository[] ingredienteRepositoryHolder = new IngredienteRepository[1];
        final TavoloRepository[] tavoloRepositoryHolder = new TavoloRepository[1];
        final PremioRepository[] premioRepositoryHolder = new PremioRepository[1];
        final ReportRepository[] reportRepositoryHolder = new ReportRepository[1];
        final PiattoRepository[] piattoRepositoryHolder = new PiattoRepository[1];
        final VariazioneRepository[] variazioneRepositoryHolder = new VariazioneRepository[1];
        final FidelityCardRepository[] fidelityCardRepositoryHolder = new FidelityCardRepository[1];
        final PremioRiscattatoRepository[] premioRiscattatoRepositoryHolder = new PremioRiscattatoRepository[1];
        final TurnoRepository[] turnoRepositoryHolder = new TurnoRepository[1];
        final RigaOrdineRepository[] rigaOrdineRepositoryHolder = new RigaOrdineRepository[1];
        final OrdineRepository[] ordineRepositoryHolder = new OrdineRepository[1];
        final PagamentoRepository[] pagamentoRepositoryHolder = new PagamentoRepository[1];
        final PrenotazioneRepository[] prenotazioneRepositoryHolder = new PrenotazioneRepository[1];
        final FeedbackRepository[] feedbackRepositoryHolder = new FeedbackRepository[1];
        final AmministratoreRepository[] amministratoreRepositoryHolder = new AmministratoreRepository[1];
        final MenuRepository[] menuRepositoryHolder = new MenuRepository[1];

        // --- Fase 1: Inizializzazione dei repository senza dipendenze a catena ---
        clienteRepositoryHolder[0] = new FileClienteRepository();
        dipendenteRepositoryHolder[0] = new FileDipendenteRepository();
        ingredienteRepositoryHolder[0] = new FileIngredienteRepository();
        tavoloRepositoryHolder[0] = new FileTavoloRepository();
        premioRepositoryHolder[0] = new FilePremioRepository();
        reportRepositoryHolder[0] = new FileReportRepository();
        amministratoreRepositoryHolder[0] = new FileAmministratoreRepository();

        // --- Fase 2: Inizializzazione dei repository con dipendenze semplici ---
        piattoRepositoryHolder[0] = new FilePiattoRepository(
                () -> {
                    if (ingredienteRepositoryHolder[0] == null) throw new IllegalStateException("IngredienteRepository non inizializzato");
                    return ingredienteRepositoryHolder[0];
                }
        );

        turnoRepositoryHolder[0] = new FileTurnoRepository(
                () -> {
                    if (dipendenteRepositoryHolder[0] == null) throw new IllegalStateException("DipendenteRepository non inizializzato");
                    return dipendenteRepositoryHolder[0];
                }
        );

        fidelityCardRepositoryHolder[0] = new FileFidelityCardRepository(
                () -> {
                    if (clienteRepositoryHolder[0] == null) throw new IllegalStateException("ClienteRepository non inizializzato");
                    return clienteRepositoryHolder[0];
                }
        );

        premioRiscattatoRepositoryHolder[0] = new FilePremioRiscattatoRepository(
                () -> clienteRepositoryHolder[0],
                () -> premioRepositoryHolder[0]
        );

        prenotazioneRepositoryHolder[0] = new FilePrenotazioneRepository(
                () -> clienteRepositoryHolder[0],
                () -> tavoloRepositoryHolder[0]
        );

        feedbackRepositoryHolder[0] = new FileFeedbackRepository(
                () -> clienteRepositoryHolder[0],
                () -> piattoRepositoryHolder[0]
        );

        // --- Fase 3: Gestione della Dipendenza Circolare ---
        variazioneRepositoryHolder[0] = new FileVariazioneRepository(
                () -> {
                    if (rigaOrdineRepositoryHolder[0] == null) {
                        throw new IllegalStateException("RigaOrdineRepository non ancora inizializzato per VariazioneRepository!");
                    }
                    return rigaOrdineRepositoryHolder[0];
                }
        );

        rigaOrdineRepositoryHolder[0] = new FileRigaOrdineRepository(
                () -> piattoRepositoryHolder[0],
                () -> variazioneRepositoryHolder[0],
                () -> {
                    if (ordineRepositoryHolder[0] == null) {
                        throw new IllegalStateException("OrdineRepository non ancora inizializzato per RigaOrdineRepository!");
                    }
                    return ordineRepositoryHolder[0];
                }
        );

        ordineRepositoryHolder[0] = new FileOrdineRepository(
                () -> clienteRepositoryHolder[0],
                () -> tavoloRepositoryHolder[0],
                () -> {
                    if (rigaOrdineRepositoryHolder[0] == null) {
                        throw new IllegalStateException("RigaOrdineRepository non ancora inizializzato per OrdineRepository!");
                    }
                    return rigaOrdineRepositoryHolder[0];
                }
        );

        // --- Fase 4: Inizializzazione dei repository che dipendono dai cicli ---
        pagamentoRepositoryHolder[0] = new FilePagamentoRepository(
                () -> ordineRepositoryHolder[0],
                () -> fidelityCardRepositoryHolder[0]
        );

        menuRepositoryHolder[0] = new FileMenuRepository(
                () -> {
                    if (piattoRepositoryHolder[0] == null) throw new IllegalStateException("PiattoRepository non inizializzato per MenuRepository!");
                    return piattoRepositoryHolder[0];
                },
                () -> {
                    if (ingredienteRepositoryHolder[0] == null) throw new IllegalStateException("IngredienteRepository non inizializzato per MenuRepository!");
                    return ingredienteRepositoryHolder[0];
                }
        );
        // --- Assegnazione dei riferimenti diretti per comodità ---
        ClienteRepository clienteRepository = clienteRepositoryHolder[0];
        DipendenteRepository dipendenteRepository = dipendenteRepositoryHolder[0];
        IngredienteRepository ingredienteRepository = ingredienteRepositoryHolder[0];
        TavoloRepository tavoloRepository = tavoloRepositoryHolder[0];
        PremioRepository premioRepository = premioRepositoryHolder[0];
        ReportRepository reportRepository = reportRepositoryHolder[0];
        PiattoRepository piattoRepository = piattoRepositoryHolder[0];
        VariazioneRepository variazioneRepository = variazioneRepositoryHolder[0];
        FidelityCardRepository fidelityCardRepository = fidelityCardRepositoryHolder[0];
        PremioRiscattatoRepository premioRiscattatoRepository = premioRiscattatoRepositoryHolder[0];
        TurnoRepository turnoRepository = turnoRepositoryHolder[0];
        RigaOrdineRepository rigaOrdineRepository = rigaOrdineRepositoryHolder[0];
        OrdineRepository ordineRepository = ordineRepositoryHolder[0];
        PagamentoRepository pagamentoRepository = pagamentoRepositoryHolder[0];
        PrenotazioneRepository prenotazioneRepository = prenotazioneRepositoryHolder[0];
        FeedbackRepository feedbackRepository = feedbackRepositoryHolder[0];
        AmministratoreRepository amministratoreRepository = amministratoreRepositoryHolder[0];
        MenuRepository menuRepository = menuRepositoryHolder[0];

        // --- 2. Inizializzazione dei Service ---
        ClienteService clienteService = new ClienteService(clienteRepository);
        PiattoService piattoService = new PiattoService(piattoRepository, ingredienteRepository);
        TavoloService tavoloService = new TavoloService(tavoloRepository);
        PrenotazioneService prenotazioneService = new PrenotazioneService(prenotazioneRepository, clienteRepository, tavoloRepository);

        RigaOrdineService rigaOrdineService = new RigaOrdineService(rigaOrdineRepository, piattoRepository, variazioneRepository, ordineRepository);

        OrdineService ordineService = new OrdineService(
                ordineRepository,
                clienteRepository,
                tavoloRepository,
                piattoRepository,
                rigaOrdineRepository,
                variazioneRepository
        );

        FidelityCardService fidelityCardService = new FidelityCardService(fidelityCardRepository, clienteRepository);
        PagamentoService pagamentoService = new PagamentoService(
                pagamentoRepository,
                ordineRepository,
                fidelityCardRepository,
                fidelityCardService,
                ordineService
        );
        FeedbackService feedbackService = new FeedbackService(feedbackRepository, clienteRepository, piattoRepository);
        PremioService premioService = new PremioService(premioRepository, fidelityCardRepository, premioRiscattatoRepository, fidelityCardService);
        IngredienteService ingredienteService = new IngredienteService(ingredienteRepository);
        DipendenteService dipendenteService = new DipendenteService(dipendenteRepository);
        TurnoService turnoService = new TurnoService(turnoRepository, dipendenteRepository);

        ReportService reportService = new ReportService(reportRepository, ordineRepository, pagamentoRepository,rigaOrdineRepository, piattoRepository);
        VariazioneService variazioneService = new VariazioneService(variazioneRepository);
        MenuService menuService = new MenuService(menuRepository);

        // --- 3. Inizializzazione di MyRestoService ---
        MyRestoService myRestoService = new MyRestoService(
                clienteService, piattoService, tavoloService, prenotazioneService,
                ordineService, pagamentoService, feedbackService, fidelityCardService,
                premioService, ingredienteService, dipendenteService, turnoService,
                rigaOrdineService, variazioneService, reportService, menuService
        );

        Scanner scanner = new Scanner(System.in);
        System.out.println("Benvenuto in MyResto!");

        // --- Autenticazione amministratore ---
        boolean isAdminLoggedIn = false;
        System.out.println("\n--- Accesso Amministratore ---");
        System.out.print("Username: ");
        String usernameInput = scanner.nextLine();
        System.out.print("Password: ");
        String passwordInput = scanner.nextLine();

        Optional<Amministratore> adminOptional = amministratoreRepository.findByUsername(usernameInput);
        if (adminOptional.isPresent()) {
            Amministratore admin = adminOptional.get();
            if (admin.getPasswordHash().equals(passwordInput)) {
                isAdminLoggedIn = true;
                System.out.println("Autenticazione amministratore riuscita! Benvenuto, " + admin.getUsername() + ".");
            } else {
                System.out.println("Password errata.");
                throw new AuthenticationException("Autenticazione fallita: password errata.");
            }
        } else {
            System.out.println("Username non trovato.");
            throw new AuthenticationException("Autenticazione fallita: username non trovato.");
        }


        // 1. Registrazione di un cliente
        System.out.println("\n--- Registrazione Cliente ---");
        Cliente cliente1 = null;
        try {
            cliente1 = myRestoService.registraNuovoCliente("Alice", "Bianchi", "alice.b@example.com");
            System.out.println("Cliente registrato: " + cliente1.getNome() + " " + cliente1.getCognome() + " (ID: " + cliente1.getId() + ")");
        } catch (IllegalArgumentException e) {
            System.err.println("Errore registrazione cliente: " + e.getMessage());
            cliente1 = clienteRepository.findByEmail("alice.b@example.com").orElse(null);
            if(cliente1 != null) {
                System.out.println("Cliente esistente recuperato: " + cliente1.getNome() + " " + cliente1.getCognome() + " (ID: " + cliente1.getId() + ")");
            } else {
                System.err.println("Impossibile recuperare cliente esistente. Uscita.");
                scanner.close();
                return;
            }
        }

        // Creazione della Fidelity Card
        System.out.println("\n--- Creazione Fidelity Card per Cliente ---");
        FidelityCard fidelityCard1 = myRestoService.creaFidelityCardPerCliente(cliente1.getId());
        System.out.println("Fidelity Card creata per " + cliente1.getNome() + " (ID Card: " + fidelityCard1.getIdCard() + ", Punti: " + fidelityCard1.getIdCard() + ")");


        // 2. Creazione dei tavoli
        System.out.println("\n--- Creazione Tavoli ---");
        Tavolo tavolo1 = myRestoService.creaTavolo(101, 4);
        Tavolo tavolo2 = myRestoService.creaTavolo(102, 2);
        System.out.println("Tavoli creati: " + tavolo1.getNumeroTavolo() + ", " + tavolo2.getNumeroTavolo());
        System.out.println("Tavoli disponibili per 3 persone: " + myRestoService.getTavoliDisponibiliPerPosti(3).size());

        Piatto pizzaMargherita = null;
        Piatto tiramisu = null;
        Premio caffeOmaggio = null;

        // Funzionalità che richiedono autenticazione amministratore
        if (isAdminLoggedIn) {
            System.out.println("\n--- Funzionalità Amministrative (Richiede Autenticazione) ---");

            // 1. Aggiunta di un dipendente (UC6: Pianificazione del personale)
            System.out.println("\n--- Aggiunta Dipendente ---");
            Dipendente dipendente1 = myRestoService.aggiungiNuovoDipendente("Luca", "Neri", "Cameriere");
            System.out.println("Dipendente aggiunto: " + dipendente1.getNome() + " " + dipendente1.getCognome() + " (ID: " + dipendente1.getId() + ")");

            // 2. Assegnazione di un turno al dipendente (UC6: Pianificazione del personale)
            System.out.println("\n--- Assegnazione Turno ---");
            LocalDate oggi = LocalDate.now();
            LocalTime oraMattina = LocalTime.of(9, 0);
            try {
                Turno turno1 = myRestoService.assegnaTurno(dipendente1.getId(), oggi, oraMattina, "Mattina");
                System.out.println("Turno assegnato: " + turno1);
            } catch (IllegalArgumentException e) {
                System.err.println("Errore nell'assegnazione turno: " + e.getMessage());
            }


            // 3. Creazione di ingredienti e piatti (UC4: Gestione Menu)
            System.out.println("\n--- Creazione Piatti e Ingredienti ---");
            Ingrediente pomodoro = myRestoService.aggiungiNuovoIngrediente("Pomodoro", 0.50f);
            Ingrediente mozzarella = myRestoService.aggiungiNuovoIngrediente("Mozzarella", 1.00f);
            Ingrediente basilico = myRestoService.aggiungiNuovoIngrediente("Basilico", 0.20f);
            Ingrediente pasta = myRestoService.aggiungiNuovoIngrediente("Pasta", 0.80f);
            Ingrediente uova = myRestoService.aggiungiNuovoIngrediente("Uova", 0.30f);
            Ingrediente pancetta = myRestoService.aggiungiNuovoIngrediente("Pancetta", 1.20f);
            Ingrediente pecorino = myRestoService.aggiungiNuovoIngrediente("Pecorino Romano", 0.70f);
            Ingrediente pepeNero = myRestoService.aggiungiNuovoIngrediente("Pepe Nero", 0.10f);
            Ingrediente riso = myRestoService.aggiungiNuovoIngrediente("Riso Arborio", 0.60f);
            Ingrediente funghi = myRestoService.aggiungiNuovoIngrediente("Funghi Porcini", 2.50f);
            Ingrediente brodoVegetale = myRestoService.aggiungiNuovoIngrediente("Brodo Vegetale", 0.40f);
            Ingrediente parmigiano = myRestoService.aggiungiNuovoIngrediente("Parmigiano Reggiano", 0.90f);
            Ingrediente burro = myRestoService.aggiungiNuovoIngrediente("Burro", 0.35f);
            Ingrediente salmone = myRestoService.aggiungiNuovoIngrediente("Salmone Fresco", 3.00f);
            Ingrediente avocado = myRestoService.aggiungiNuovoIngrediente("Avocado", 1.80f);
            Ingrediente insalata = myRestoService.aggiungiNuovoIngrediente("Misto Insalata", 0.70f);
            Ingrediente pollo = myRestoService.aggiungiNuovoIngrediente("Petto di Pollo", 2.00f);
            Ingrediente patate = myRestoService.aggiungiNuovoIngrediente("Patate", 0.40f);
            Ingrediente rosmarino = myRestoService.aggiungiNuovoIngrediente("Rosmarino", 0.05f);

            pizzaMargherita = myRestoService.creaPiatto("Pizza Margherita", "Classica pizza napoletana", 8.50f,
                    List.of(pomodoro.getId(), mozzarella.getId(), basilico.getId()));
            System.out.println("Piatto creato: " + pizzaMargherita.getNome() + " (ID: " + pizzaMargherita.getId() + ")");
            Piatto carbonara = myRestoService.creaPiatto("Spaghetti alla Carbonara", "Classico romano con guanciale e uova", 12.00f,
                    List.of(pasta.getId(), uova.getId(), pancetta.getId(), pecorino.getId(), pepeNero.getId()));
            System.out.println("Piatto creato: " + carbonara.getNome() + " (ID: " + carbonara.getId() + ")");

            Piatto risottoFunghi = myRestoService.creaPiatto("Risotto ai Funghi Porcini", "Risotto cremoso con funghi freschi", 15.00f,
                    List.of(riso.getId(), funghi.getId(), brodoVegetale.getId(), parmigiano.getId(), burro.getId()));
            System.out.println("Piatto creato: " + risottoFunghi.getNome() + " (ID: " + risottoFunghi.getId() + ")");

            Piatto insalataSalmone = myRestoService.creaPiatto("Insalata di Salmone e Avocado", "Insalata fresca con salmone affumicato e avocado", 14.50f,
                    List.of(salmone.getId(), avocado.getId(), insalata.getId()));
            System.out.println("Piatto creato: " + insalataSalmone.getNome() + " (ID: " + insalataSalmone.getId() + ")");

            Piatto polloPatate = myRestoService.creaPiatto("Pollo al Forno con Patate", "Cosce di pollo al forno con patate e rosmarino", 13.00f,
                    List.of(pollo.getId(), patate.getId(), rosmarino.getId()));
            System.out.println("Piatto creato: " + polloPatate.getNome() + " (ID: " + polloPatate.getId() + ")");

            tiramisu = myRestoService.creaPiatto("Tiramisù", "Dolce con caffè e mascarpone", 6.00f,
                    List.of(myRestoService.aggiungiNuovoIngrediente("Savoiardi", 0.50f).getId(),
                            myRestoService.aggiungiNuovoIngrediente("Mascarpone", 1.00f).getId(),
                            myRestoService.aggiungiNuovoIngrediente("Caffè", 0.20f).getId(),
                            myRestoService.aggiungiNuovoIngrediente("Cacao Amaro", 0.10f).getId()));
            System.out.println("Piatto creato: " + tiramisu.getNome() + " (ID: " + tiramisu.getId() + ")");


            System.out.println("\n--- Visualizzazione Menu Completo ---");
            Menu fullMenu = myRestoService.getFullMenu();
            System.out.println("Numero piatti nel menu: " + fullMenu.getPiatti().size());
            fullMenu.getPiatti().forEach(p -> System.out.println("  - " + p.getNome() + " (€" + p.getPrezzo() + ")"));
            System.out.println("Numero ingredienti disponibili: " + fullMenu.getIngredientiDisponibili().size());
            fullMenu.getIngredientiDisponibili().forEach(i -> System.out.println("  - " + i.getNome()));

            // 4. Creazione di un premio
            System.out.println("\n--- Creazione Premi ---");
            caffeOmaggio = myRestoService.creaNuovoPremio("Caffè Omaggio", "Un caffè offerto dalla casa", 2);
            Premio sconto10euro = myRestoService.creaNuovoPremio("Sconto 10 Euro", "Sconto di 10 Euro sul prossimo ordine", 500);
            System.out.println("Premi creati: " + caffeOmaggio.getNome() + " (" + caffeOmaggio.getPuntiNecessari() + " punti), " + sconto10euro.getNome() + " (" + sconto10euro.getPuntiNecessari() + " punti)");


        } else {
            System.out.println("\nNon sei autenticato come amministratore. Le funzionalità amministrative non sono disponibili.");
        }

        System.out.println("\n--- Funzionalità Generali (Non Richiede Autenticazione Admin) ---");

        // Crea un ordine (UC2: Gestione ordine)
        System.out.println("\n--- Creazione Ordine ---");
        Optional<Cliente> currentCliente = clienteRepository.findById(cliente1.getId());
        Optional<Tavolo> currentTavolo = tavoloRepository.findById(tavolo1.getNumeroTavolo());

        if (currentCliente.isPresent() && currentTavolo.isPresent()) {
            Ordine ordine1 = myRestoService.creaNuovoOrdine(currentCliente.get().getId(), currentTavolo.get().getNumeroTavolo());
            System.out.println("Ordine creato (ID: " + ordine1.getIdOrdine() + ") per Tavolo: " + ordine1.getTavolo().getNumeroTavolo());

            System.out.println("\n--- Aggiunta Righe Ordine ---");
            Variazione varExtraFormaggio = myRestoService.creaVariazione("Extra Formaggio", 1.50f);
            Variazione varSenzaCipolla = myRestoService.creaVariazione("Senza Cipolla", 0.00f);


            if (pizzaMargherita != null) {
                myRestoService.aggiungiRigaOrdine(ordine1.getIdOrdine(), pizzaMargherita.getId(), 2, "ben cotta", List.of(varExtraFormaggio.getId()));
                myRestoService.aggiungiRigaOrdine(ordine1.getIdOrdine(), pizzaMargherita.getId(), 1, "senza basilico", List.of(varSenzaCipolla.getId()));
                System.out.println("Pizze aggiunte all'ordine.");

                if (tiramisu != null) {
                    myRestoService.aggiungiRigaOrdine(ordine1.getIdOrdine(), tiramisu.getId(), 1, "con un po' di cacao in più", null);
                    System.out.println("Aggiunto Tiramisù all'ordine.");
                } else {
                    System.err.println("Impossibile aggiungere Tiramisù: piatto non disponibile.");
                }
            } else {
                System.err.println("Piatto per l'ordine non disponibile (non creato dall'amministratore o ID non valido). Le righe dell'ordine non saranno aggiunte.");
                System.out.println("Impossibile procedere con pagamento e feedback senza un ordine con righe.");
                scanner.close();
                return;
            }

            System.out.println("\n--- Aggiornamento Stato Ordine ---");
            myRestoService.aggiornaStatoOrdine(ordine1.getIdOrdine(), OrdineService.STATO_SERVITO);
            System.out.println("Stato ordine " + ordine1.getIdOrdine() + " aggiornato a '" + OrdineService.STATO_SERVITO + "'.");

            System.out.println("\n--- Totale Ordine ---");
            double totaleOrdine1 = myRestoService.calcolaTotaleOrdine(ordine1.getIdOrdine());
            System.out.printf("Totale Ordine %d: %.2f EUR%n", ordine1.getIdOrdine(), totaleOrdine1);

            System.out.println("\n--- Registrazione Pagamento ---");
            Pagamento pagamento1 = myRestoService.registraPagamento(ordine1.getIdOrdine(), totaleOrdine1, Optional.of(fidelityCard1.getIdCard()));
            System.out.println("Pagamento registrato (ID: " + pagamento1.getId() + ") per Ordine " + pagamento1.getOrdine().getIdOrdine());
            System.out.println("Stato Ordine dopo pagamento: " + myRestoService.cercaOrdinePerId(ordine1.getIdOrdine()).get().getStatoOrdine());

            System.out.println("\n--- Punti Fidelity Card dopo Pagamento ---");
            FidelityCard cardAggiornata = myRestoService.getFidelityCardService().getFidelityCardById(fidelityCard1.getIdCard())
                    .orElseThrow(() -> new IllegalStateException("Fidelity Card non trovata!"));
            System.out.println("Punti Fidelity Card per " + cliente1.getNome() + ": " + cardAggiornata.getPuntiAccumulati() + " punti.");


            System.out.println("\n--- Lascia Feedback per i piatto consumati ---");
            if (cliente1 != null && pizzaMargherita != null) {
                try {
                    Feedback feedbackPizza = myRestoService.aggiungiFeedback(cliente1.getId(), pizzaMargherita.getId(), "Ottima pizza, impasto leggero!", 5);
                    System.out.println("Feedback aggiunto da " + cliente1.getNome() + " per '" + pizzaMargherita.getNome() + "': " + feedbackPizza.getValutazione() + "/5 - \"" + feedbackPizza.getCommento() + "\"");
                } catch (IllegalArgumentException e) {
                    System.err.println("Errore durante l'aggiunta del feedback: " + e.getMessage());
                }
            } else {
                System.out.println("Impossibile aggiungere feedback: cliente o piatto non disponibili.");
            }

            System.out.println("\n--- Riscatto Premi ---");
            if (caffeOmaggio != null) {
                try {
                    System.out.println("Tentativo di riscatto: " + caffeOmaggio.getNome() + " (" + caffeOmaggio.getPuntiNecessari() + " punti)");
                    PremioRiscattato riscatto = myRestoService.riscattaPremio(cliente1.getId(), caffeOmaggio.getId());
                    System.out.println("Premio riscattato con successo! " + riscatto.getPremio().getNome() + " per " + riscatto.getCliente().getNome() + ".");

                    cardAggiornata = myRestoService.getFidelityCardService().getFidelityCardById(fidelityCard1.getIdCard())
                            .orElseThrow(() -> new IllegalStateException("Fidelity Card non trovata dopo riscatto!"));
                    System.out.println("Nuovi punti Fidelity Card per " + cliente1.getNome() + ": " + cardAggiornata.getPuntiAccumulati() + " punti.");

                } catch (IllegalArgumentException e) {
                    System.err.println("Impossibile riscattare il premio: " + e.getMessage());
                }
            } else {
                System.out.println("Nessun premio configurato dagli amministratori per il riscatto.");
            }


            // 4. Genera un report incassi
            if (isAdminLoggedIn) {
                LocalDate dataCorrentePerReport = LocalDate.now();
                Report reportIncassi = myRestoService.generaReportIncassi(dataCorrentePerReport.minusDays(7), dataCorrentePerReport);
                System.out.println(reportIncassi.getContenuto());

                Report reportPiattiPiuVenduti = myRestoService.generaReportPiattiPiuVenduti(dataCorrentePerReport.minusDays(7), dataCorrentePerReport);
                System.out.println(reportPiattiPiuVenduti.getContenuto());

            } else {
                System.out.println("\nNon sei autenticato come amministratore. I report non possono essere generati.");
            }


        } else {
            System.err.println("Impossibile creare ordine: cliente o tavolo non disponibili.");
        }


        System.out.println("\n--- Fine ---");
        scanner.close();
    }
}