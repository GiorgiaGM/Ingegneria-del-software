package org.example.repository;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class FileBasedCrudRepository<T, ID> implements CrudRepository<T, ID> {

    protected final Map<ID, T> entities = new LinkedHashMap<>();
    protected final String filePath;
    private AtomicInteger idCounter = new AtomicInteger(0);

    public FileBasedCrudRepository(String fileName) {
        String resourcesPath = "src/main/resources/data/";
        Path dir = Paths.get(resourcesPath);
        try {
            Files.createDirectories(dir);
        } catch (IOException e) {
            System.err.println("Errore nella creazione della directory dei dati: " + e.getMessage());
        }
        this.filePath = resourcesPath + fileName;
        loadAll();
    }

    protected abstract ID getEntityId(T entity);

    protected abstract String serialize(T entity);

    protected abstract T deserialize(String data);

    protected void loadAll() {
        entities.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            int maxId = 0;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                try {
                    T entity = deserialize(line);
                    if (entity != null) {
                        ID id = getEntityId(entity);
                        entities.put(id, entity);
                        if (id instanceof Integer) {
                            maxId = Math.max(maxId, (Integer) id);
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Errore durante la deserializzazione della riga: " + line + ". Errore: " + e.getMessage());
                }
            }
            if (idCounter.get() == 0 && maxId > 0) {
                idCounter.set(maxId + 1);
            } else if (idCounter.get() == 0 && maxId == 0) {
                idCounter.set(1);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File non trovato: " + filePath + ". Verrà creato al primo salvataggio.");
        } catch (IOException e) {
            System.err.println("Errore di I/O durante la lettura del file " + filePath + ": " + e.getMessage());
        }
    }

    protected void saveAll() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (T entity : entities.values()) {
                writer.write(serialize(entity));
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Errore di I/O durante la scrittura nel file " + filePath + ": " + e.getMessage());
        }
    }

    protected void saveAllEntitiesToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (T entity : entities.values()) {
                writer.write(serialize(entity));
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving entities to file " + filePath + ": " + e.getMessage());
        }
    }

    @Override
    public T save(T entity) {
        ID id = getEntityId(entity);
        if (id == null) {
            throw new IllegalArgumentException("L'ID dell'entità non può essere null durante il salvataggio.");
        }
        entities.put(id, entity);
        saveAll();
        return entity;
    }

    @Override
    public Optional<T> findById(ID id) {
        return Optional.ofNullable(entities.get(id));
    }

    @Override
    public List<T> findAll() {
        return new ArrayList<>(entities.values());
    }

    @Override
    public void deleteById(ID id) {
        if (entities.remove(id) != null) {
            saveAll();
        } else {
            System.out.println("Nessuna entità trovata con ID " + id + " da eliminare.");
        }
    }

    @Override
    public ID getNextId() {
        if (!(idCounter instanceof AtomicInteger)) {
            throw new UnsupportedOperationException("getNextId() non supporta ID non numerici. Sovrascrivere per ID String.");
        }
        return (ID) Integer.valueOf(idCounter.getAndIncrement());
    }
}