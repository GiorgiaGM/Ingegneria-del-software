package org.example.repository;

import org.example.model.Cliente;
import java.util.Optional;
import java.util.List;

public interface ClienteRepository extends CrudRepository<Cliente, Integer> {
    Optional<Cliente> findByEmail(String email);
    List<Cliente> findByNomeContainsIgnoreCase(String nome);
}