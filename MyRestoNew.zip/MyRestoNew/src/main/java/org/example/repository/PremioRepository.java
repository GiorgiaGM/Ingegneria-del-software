package org.example.repository;

import org.example.model.Premio;

import java.util.List;
import java.util.Optional;

public interface PremioRepository extends CrudRepository<Premio, Integer> {
    Optional<Premio> findByNome(String nome);
    List<Premio> findByPuntiNecessariLessThanEqual(int maxPunti);
}