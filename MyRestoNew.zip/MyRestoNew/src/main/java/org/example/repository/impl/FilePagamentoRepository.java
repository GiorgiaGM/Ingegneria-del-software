package org.example.repository.impl;

import org.example.model.Pagamento;
import org.example.model.Ordine;
import org.example.model.FidelityCard;
import org.example.repository.PagamentoRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.OrdineRepository;
import org.example.repository.FidelityCardRepository;
import java.util.function.Supplier;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

public class FilePagamentoRepository extends FileBasedCrudRepository<Pagamento, Integer> implements PagamentoRepository {

    private final Supplier<OrdineRepository> ordineRepositorySupplier;
    private final Supplier<FidelityCardRepository> fidelityCardRepositorySupplier;

    public FilePagamentoRepository(Supplier<OrdineRepository> ordineRepositorySupplier, Supplier<FidelityCardRepository> fidelityCardRepositorySupplier) {
        super("pagamenti.txt");
        this.ordineRepositorySupplier = ordineRepositorySupplier;
        this.fidelityCardRepositorySupplier = fidelityCardRepositorySupplier;
    }

    @Override
    protected Integer getEntityId(Pagamento pagamento) {
        return pagamento.getId();
    }

    @Override
    protected String serialize(Pagamento pagamento) {
        return pagamento.toTextString();
    }

    @Override
    protected Pagamento deserialize(String data) {
        OrdineRepository ordineRepo = ordineRepositorySupplier.get();
        FidelityCardRepository fidelityCardRepo = fidelityCardRepositorySupplier.get();
        return Pagamento.fromTextString(data, ordineRepo, fidelityCardRepo);
    }

    @Override
    public List<Pagamento> findByOrdine(Ordine ordine) {
        return entities.values().stream()
                .filter(p -> p.getOrdine() != null && p.getOrdine().getIdOrdine() == ordine.getIdOrdine())
                .collect(Collectors.toList());
    }

    @Override
    public List<Pagamento> findByFidelityCard(FidelityCard fidelityCard) {
        return entities.values().stream()
                .filter(p -> p.getFidelityCard() != null && p.getFidelityCard().getIdCard() == fidelityCard.getIdCard())
                .collect(Collectors.toList());
    }

    @Override
    public List<Pagamento> findByDataPagamentoBetween(LocalDateTime inizio, LocalDateTime fine) {
        return entities.values().stream()
                .filter(p -> p.getDataPagamento() != null &&
                        !p.getDataPagamento().isBefore(inizio) &&
                        !p.getDataPagamento().isAfter(fine))
                .collect(Collectors.toList());
    }
}