package org.example.repository.impl;

import org.example.model.Tavolo;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.TavoloRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class FileTavoloRepository extends FileBasedCrudRepository<Tavolo, Integer> implements TavoloRepository {

    public FileTavoloRepository() {
        super("tavoli.txt");
    }

    @Override
    protected Integer getEntityId(Tavolo tavolo) {
        return tavolo.getNumeroTavolo();
    }

    @Override
    protected String serialize(Tavolo tavolo) {
        return tavolo.toTextString();
    }

    @Override
    protected Tavolo deserialize(String data) {
        return Tavolo.fromTextString(data);
    }

    @Override
    public Optional<Tavolo> findByNumeroTavolo(int numeroTavolo) {
        return findById(numeroTavolo);
    }

    @Override
    public List<Tavolo> findByNumPostiAndStato(int numPostiMinimi, String statoRichiesto) {
        return entities.values().stream()
                .filter(t -> t.getNumPosti() >= numPostiMinimi && t.getStato().equalsIgnoreCase(statoRichiesto))
                .collect(Collectors.toList());
    }

    @Override
    public List<Tavolo> findByStato(String stato) {
        return entities.values().stream()
                .filter(t -> t.getStato().equalsIgnoreCase(stato))
                .collect(Collectors.toList());
    }
}