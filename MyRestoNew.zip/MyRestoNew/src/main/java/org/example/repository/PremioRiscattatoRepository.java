package org.example.repository;

import org.example.model.PremioRiscattato;
import org.example.model.Cliente;
import org.example.model.Premio;

import java.util.List;

public interface PremioRiscattatoRepository extends CrudRepository<PremioRiscattato, Integer> {
    List<PremioRiscattato> findByCliente(Cliente cliente);
    List<PremioRiscattato> findByPremio(Premio premio);
}