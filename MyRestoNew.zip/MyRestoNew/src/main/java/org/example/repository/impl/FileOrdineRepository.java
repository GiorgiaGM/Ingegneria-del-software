package org.example.repository.impl;

import org.example.model.Ordine;
import org.example.model.Cliente;
import org.example.model.Tavolo;
import org.example.repository.OrdineRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.ClienteRepository;
import org.example.repository.TavoloRepository;
import org.example.repository.RigaOrdineRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.function.Supplier;

public class FileOrdineRepository extends FileBasedCrudRepository<Ordine, Integer> implements OrdineRepository {

    private final Supplier<ClienteRepository> clienteRepositorySupplier;
    private final Supplier<TavoloRepository> tavoloRepositorySupplier;
    private final Supplier<RigaOrdineRepository> rigaOrdineRepositorySupplier;

    public FileOrdineRepository(Supplier<ClienteRepository> clienteRepositorySupplier, Supplier<TavoloRepository> tavoloRepositorySupplier, Supplier<RigaOrdineRepository> rigaOrdineRepositorySupplier) {
        super("ordini.txt");
        this.clienteRepositorySupplier = clienteRepositorySupplier;
        this.tavoloRepositorySupplier = tavoloRepositorySupplier;
        this.rigaOrdineRepositorySupplier = rigaOrdineRepositorySupplier;
    }

    @Override
    protected Integer getEntityId(Ordine ordine) {
        return ordine.getIdOrdine();
    }

    @Override
    protected String serialize(Ordine ordine) {
        return ordine.toTextString();
    }

    @Override
    protected Ordine deserialize(String data) {
        ClienteRepository clienteRepo = clienteRepositorySupplier.get();
        TavoloRepository tavoloRepo = tavoloRepositorySupplier.get();
        RigaOrdineRepository rigaOrdineRepo = rigaOrdineRepositorySupplier.get();

        return Ordine.fromTextString(data, clienteRepo, tavoloRepo, rigaOrdineRepo);
    }

    @Override
    public List<Ordine> findByCliente(Cliente cliente) {
        return entities.values().stream()
                .filter(o -> o.getCliente() != null && o.getCliente().getId() == cliente.getId())
                .collect(Collectors.toList());
    }

    @Override
    public List<Ordine> findByTavolo(Tavolo tavolo) {
        return entities.values().stream()
                .filter(o -> o.getTavolo() != null && o.getTavolo().getNumeroTavolo() == tavolo.getNumeroTavolo())
                .collect(Collectors.toList());
    }

    @Override
    public List<Ordine> findByStato(String stato) {
        return entities.values().stream()
                .filter(o -> o.getStatoOrdine().equalsIgnoreCase(stato))
                .collect(Collectors.toList());
    }

    @Override
    public void aggiornaStatoOrdine(int ordineId, String nuovoStato) {
        Optional<Ordine> ordineOpt = findById(ordineId);
        if (ordineOpt.isPresent()) {
            Ordine ordine = ordineOpt.get();
            ordine.setStatoOrdine(nuovoStato);
            save(ordine);
        } else {
            System.err.println("Errore: Ordine con ID " + ordineId + " non trovato per l'aggiornamento dello stato.");
        }
    }
}