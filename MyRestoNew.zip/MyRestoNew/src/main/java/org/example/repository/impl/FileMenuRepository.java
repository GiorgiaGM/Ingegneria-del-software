package org.example.repository.impl;

import org.example.model.Ingrediente;
import org.example.model.Piatto;
import org.example.repository.IngredienteRepository;
import org.example.repository.MenuRepository;
import org.example.repository.PiattoRepository;

import java.util.List;
import java.util.function.Supplier;

public class FileMenuRepository implements MenuRepository {

    private final Supplier<PiattoRepository> piattoRepositorySupplier;
    private final Supplier<IngredienteRepository> ingredienteRepositorySupplier;

    private PiattoRepository piattoRepository;
    private IngredienteRepository ingredienteRepository;

    public FileMenuRepository(Supplier<PiattoRepository> piattoRepositorySupplier,
                              Supplier<IngredienteRepository> ingredienteRepositorySupplier) {
        this.piattoRepositorySupplier = piattoRepositorySupplier;
        this.ingredienteRepositorySupplier = ingredienteRepositorySupplier;
    }

    private void ensureRepositoriesInitialized() {
        if (piattoRepository == null) {
            this.piattoRepository = piattoRepositorySupplier.get();
        }
        if (ingredienteRepository == null) {
            this.ingredienteRepository = ingredienteRepositorySupplier.get();
        }
    }

    @Override
    public List<Piatto> findAllPiatti() {
        ensureRepositoriesInitialized();
        return piattoRepository.findAll();
    }

    @Override
    public List<Ingrediente> findAllIngredienti() {
        ensureRepositoriesInitialized();
        return ingredienteRepository.findAll();
    }
}