package org.example.repository.impl;

import org.example.model.Prenotazione;
import org.example.model.Cliente;
import org.example.model.Tavolo;
import org.example.repository.PrenotazioneRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.ClienteRepository;
import org.example.repository.TavoloRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.function.Supplier;

public class FilePrenotazioneRepository extends FileBasedCrudRepository<Prenotazione, String> implements PrenotazioneRepository {

    private final Supplier<ClienteRepository> clienteRepositorySupplier;
    private final Supplier<TavoloRepository> tavoloRepositorySupplier;

    public FilePrenotazioneRepository(Supplier<ClienteRepository> clienteRepositorySupplier, Supplier<TavoloRepository> tavoloRepositorySupplier) {
        super("prenotazioni.txt");
        this.clienteRepositorySupplier = clienteRepositorySupplier;
        this.tavoloRepositorySupplier = tavoloRepositorySupplier;
    }

    @Override
    protected String getEntityId(Prenotazione prenotazione) {
        return prenotazione.getCodicePrenotazione();
    }

    @Override
    protected String serialize(Prenotazione prenotazione) {
        return prenotazione.toTextString();
    }

    @Override
    protected Prenotazione deserialize(String data) {
        ClienteRepository clienteRepo = clienteRepositorySupplier.get();
        TavoloRepository tavoloRepo = tavoloRepositorySupplier.get();
        return Prenotazione.fromTextString(data, clienteRepo, tavoloRepo);
    }

    @Override
    public String getNextId() {
        return UUID.randomUUID().toString();
    }

    @Override
    public Optional<Prenotazione> findByDataOraTavolo(LocalDate data, LocalTime ora, Tavolo tavolo) {
        return entities.values().stream()
                .filter(p -> p.getData().isEqual(data) && p.getOra().equals(ora) &&
                        p.getTavoloAssegnato() != null && p.getTavoloAssegnato().getNumeroTavolo() == tavolo.getNumeroTavolo())
                .findFirst();
    }

    @Override
    public List<Prenotazione> findByData(LocalDate data) {
        return entities.values().stream()
                .filter(p -> p.getData().isEqual(data))
                .collect(Collectors.toList());
    }

    @Override
    public List<Prenotazione> findByCliente(Cliente cliente) {
        return entities.values().stream()
                .filter(p -> p.getCliente() != null && p.getCliente().getId() == cliente.getId())
                .collect(Collectors.toList());
    }

    @Override
    public List<Prenotazione> findByTavolo(Tavolo tavolo) {
        return entities.values().stream()
                .filter(p -> p.getTavoloAssegnato() != null && p.getTavoloAssegnato().getNumeroTavolo() == tavolo.getNumeroTavolo())
                .collect(Collectors.toList());
    }
}