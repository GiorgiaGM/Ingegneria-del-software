package org.example.repository;

import org.example.model.Turno;
import org.example.model.Dipendente;

import java.time.LocalDate;
import java.util.List;

public interface TurnoRepository extends CrudRepository<Turno, Integer> {
    List<Turno> findByDipendente(Dipendente dipendente);
    List<Turno> findByData(LocalDate data);
    List<Turno> findByDipendenteAndData(Dipendente dipendente, LocalDate data);
}