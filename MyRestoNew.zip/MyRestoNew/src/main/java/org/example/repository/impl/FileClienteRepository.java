package org.example.repository.impl;

import org.example.model.Cliente;
import org.example.repository.ClienteRepository;
import org.example.repository.FileBasedCrudRepository;
import java.util.List;
import java.util.stream.Collectors;

import java.util.Optional;

public class FileClienteRepository extends FileBasedCrudRepository<Cliente, Integer> implements ClienteRepository {

    public FileClienteRepository() {
        super("clienti.txt");
    }

    @Override
    protected Integer getEntityId(Cliente cliente) {
        return cliente.getId();
    }

    @Override
    protected String serialize(Cliente cliente) {
        return cliente.toTextString();
    }

    @Override
    protected Cliente deserialize(String data) {
        return Cliente.fromTextString(data);
    }

    @Override
    public Optional<Cliente> findByEmail(String email) {
        return entities.values().stream()
                .filter(c -> c.getEmail().equalsIgnoreCase(email))
                .findFirst();
    }

    @Override
    public List<Cliente> findByNomeContainsIgnoreCase(String nome) {
        return super.findAll().stream()
                .filter(c -> c.getNome().toLowerCase().contains(nome.toLowerCase()))
                .collect(Collectors.toList());
    }
}