package org.example.repository.impl;

import org.example.model.Amministratore;
import org.example.repository.AmministratoreRepository;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.File;

public class FileAmministratoreRepository implements AmministratoreRepository {

    private static final String FILE_PATH = "src/main/resources/data/amministratore.txt";
    private Map<String, Amministratore> amministratoriCache = new HashMap<>();

    public FileAmministratoreRepository() {
        loadAmministratori();
        if (amministratoriCache.isEmpty()) {
            System.out.println("Nessun amministratore trovato, creazione amministratore di default: admin/adminpass");
            Amministratore defaultAdmin = new Amministratore(1, "admin", "adminpass");
            amministratoriCache.put(defaultAdmin.getUsername(), defaultAdmin);
            saveAmministratori();
        }
    }

    private void loadAmministratori() {
        File file = new File(FILE_PATH);
        if (file.exists() && file.length() > 0) {
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
                amministratoriCache = (Map<String, Amministratore>) ois.readObject();
                System.out.println("Amministratori caricati da " + FILE_PATH);
            } catch (IOException | ClassNotFoundException e) {
                System.err.println("Errore durante il caricamento degli amministratori: " + e.getMessage());
                amministratoriCache = new HashMap<>();
            }
        } else {
            System.out.println("File amministratori non trovato o vuoto: " + FILE_PATH);
            amministratoriCache = new HashMap<>();
        }
    }

    private void saveAmministratori() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_PATH))) {
            oos.writeObject(amministratoriCache);
            System.out.println("Amministratori salvati su " + FILE_PATH);
        } catch (IOException e) {
            System.err.println("Errore durante il salvataggio degli amministratori: " + e.getMessage());
        }
    }

    @Override
    public Optional<Amministratore> findByUsername(String username) {
        return Optional.ofNullable(amministratoriCache.get(username));
    }
}