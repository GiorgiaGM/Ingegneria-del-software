package org.example.repository.impl;

import org.example.model.PremioRiscattato;
import org.example.model.Cliente;
import org.example.model.Premio;
import org.example.repository.PremioRiscattatoRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.ClienteRepository;
import org.example.repository.PremioRepository;
import java.util.function.Supplier;

import java.util.List;
import java.util.stream.Collectors;

public class FilePremioRiscattatoRepository extends FileBasedCrudRepository<PremioRiscattato, Integer> implements PremioRiscattatoRepository {

    private final Supplier<ClienteRepository> clienteRepositorySupplier;
    private final Supplier<PremioRepository> premioRepositorySupplier;

    public FilePremioRiscattatoRepository(Supplier<ClienteRepository> clienteRepositorySupplier, Supplier<PremioRepository> premioRepositorySupplier) {
        super("premiriscattati.txt");
        this.clienteRepositorySupplier = clienteRepositorySupplier;
        this.premioRepositorySupplier = premioRepositorySupplier;
    }

    @Override
    protected Integer getEntityId(PremioRiscattato premioRiscattato) {
        return premioRiscattato.getId();
    }

    @Override
    protected String serialize(PremioRiscattato premioRiscattato) {
        return premioRiscattato.toTextString();
    }

    @Override
    protected PremioRiscattato deserialize(String data) {
        ClienteRepository clienteRepo = clienteRepositorySupplier.get();
        PremioRepository premioRepo = premioRepositorySupplier.get();
        return PremioRiscattato.fromTextString(data, clienteRepo, premioRepo);
    }

    @Override
    public List<PremioRiscattato> findByCliente(Cliente cliente) {
        return entities.values().stream()
                .filter(pr -> pr.getCliente() != null && pr.getCliente().getId() == cliente.getId())
                .collect(Collectors.toList());
    }

    @Override
    public List<PremioRiscattato> findByPremio(Premio premio) {
        return entities.values().stream()
                .filter(pr -> pr.getPremio() != null && pr.getPremio().getId() == premio.getId())
                .collect(Collectors.toList());
    }
}