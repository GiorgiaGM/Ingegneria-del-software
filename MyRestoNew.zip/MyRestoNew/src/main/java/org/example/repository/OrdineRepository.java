package org.example.repository;

import org.example.model.Ordine;
import org.example.model.Cliente;
import org.example.model.Tavolo;

import java.util.List;


public interface OrdineRepository extends CrudRepository<Ordine, Integer> {
    List<Ordine> findByCliente(Cliente cliente);
    List<Ordine> findByTavolo(Tavolo tavolo);
    List<Ordine> findByStato(String stato);
    void aggiornaStatoOrdine(int ordineId, String nuovoStato);
}