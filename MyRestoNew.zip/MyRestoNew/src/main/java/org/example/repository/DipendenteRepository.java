package org.example.repository;

import org.example.model.Dipendente;

import java.util.List;
import java.util.Optional;

public interface DipendenteRepository extends CrudRepository<Dipendente, Integer> {
    Optional<Dipendente> findByNomeAndCognome(String nome, String cognome);
    List<Dipendente> findByRuolo(String ruolo);
}