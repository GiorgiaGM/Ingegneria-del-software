package org.example.repository.impl;

import org.example.model.Dipendente;
import org.example.repository.DipendenteRepository;
import org.example.repository.FileBasedCrudRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class FileDipendenteRepository extends FileBasedCrudRepository<Dipendente, Integer> implements DipendenteRepository {

    public FileDipendenteRepository() {
        super("dipendenti.txt");
    }

    @Override
    protected Integer getEntityId(Dipendente dipendente) {
        return dipendente.getId();
    }

    @Override
    protected String serialize(Dipendente dipendente) {
        return dipendente.toTextString();
    }

    @Override
    protected Dipendente deserialize(String data) {
        return Dipendente.fromTextString(data);
    }

    @Override
    public Optional<Dipendente> findByNomeAndCognome(String nome, String cognome) {
        return entities.values().stream()
                .filter(d -> d.getNome().equalsIgnoreCase(nome) && d.getCognome().equalsIgnoreCase(cognome))
                .findFirst();
    }

    @Override
    public List<Dipendente> findByRuolo(String ruolo) {
        return entities.values().stream()
                .filter(d -> d.getRuolo().equalsIgnoreCase(ruolo))
                .collect(Collectors.toList());
    }
}