package org.example.repository;

import org.example.model.FidelityCard;
import org.example.model.Cliente;

import java.util.Optional;
import java.util.List;

public interface FidelityCardRepository extends CrudRepository<FidelityCard, Integer> {
    Optional<FidelityCard> findByCliente(Cliente cliente);
    Optional<FidelityCard> findByClienteId(int clienteId);
    FidelityCard update(FidelityCard card);
    List<FidelityCard> findByPuntiGreaterThanEqual(int minPunti);
}