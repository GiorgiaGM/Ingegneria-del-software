package org.example.repository;

import org.example.model.Feedback;
import org.example.model.Cliente;
import org.example.model.Piatto;

import java.util.List;

public interface FeedbackRepository extends CrudRepository<Feedback, Integer> {
    List<Feedback> findByCliente(Cliente cliente);
    List<Feedback> findByPiatto(Piatto piatto);
    List<Feedback> findByValutazioneGreaterThanEqual(int minValutazione);
}