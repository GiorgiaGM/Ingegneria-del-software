package org.example.repository;

import org.example.model.RigaOrdine;
import org.example.model.Piatto;
import org.example.model.Variazione;

import java.util.List;
import java.util.Optional;

public interface RigaOrdineRepository extends CrudRepository<RigaOrdine, Integer> {
    List<RigaOrdine> findByPiatto(Piatto piatto);
    List<RigaOrdine> findByVariazione(Variazione variazione);
    List<RigaOrdine> findByOrdineId(int ordineId);
    Optional<RigaOrdine> findByOrdineIdAndPiattoId(int ordineId, int piattoId);
}