package org.example.repository.impl;

import org.example.model.Premio;
import org.example.repository.PremioRepository;
import org.example.repository.FileBasedCrudRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class FilePremioRepository extends FileBasedCrudRepository<Premio, Integer> implements PremioRepository {

    public FilePremioRepository() {
        super("premi.txt");
    }

    @Override
    protected Integer getEntityId(Premio premio) {
        return premio.getId();
    }

    @Override
    protected String serialize(Premio premio) {
        return premio.toTextString();
    }

    @Override
    protected Premio deserialize(String data) {
        return Premio.fromTextString(data);
    }

    @Override
    public Optional<Premio> findByNome(String nome) {
        return entities.values().stream()
                .filter(p -> p.getNome().equalsIgnoreCase(nome))
                .findFirst();
    }

    @Override
    public List<Premio> findByPuntiNecessariLessThanEqual(int maxPunti) {
        return entities.values().stream()
                .filter(p -> p.getPuntiNecessari() <= maxPunti)
                .collect(Collectors.toList());
    }
}