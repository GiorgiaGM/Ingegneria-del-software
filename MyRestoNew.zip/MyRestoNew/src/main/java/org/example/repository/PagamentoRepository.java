package org.example.repository;

import org.example.model.Pagamento;
import org.example.model.Ordine;
import org.example.model.FidelityCard;
import java.time.LocalDateTime;
import java.util.List;

public interface PagamentoRepository extends CrudRepository<Pagamento, Integer> {
    List<Pagamento> findByOrdine(Ordine ordine);
    List<Pagamento> findByFidelityCard(FidelityCard fidelityCard);
    List<Pagamento> findByDataPagamentoBetween(LocalDateTime inizio, LocalDateTime fine);
}