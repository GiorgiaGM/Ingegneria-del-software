package org.example.repository;

import org.example.model.Amministratore;

import java.util.Optional;

public interface AmministratoreRepository {
    Optional<Amministratore> findByUsername(String username);
}