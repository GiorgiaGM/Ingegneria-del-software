package org.example.repository.impl;

import org.example.model.Turno;
import org.example.model.Dipendente;
import org.example.repository.TurnoRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.DipendenteRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.function.Supplier;

public class FileTurnoRepository extends FileBasedCrudRepository<Turno, Integer> implements TurnoRepository {

    private final Supplier<DipendenteRepository> dipendenteRepositorySupplier;

    public FileTurnoRepository(Supplier<DipendenteRepository> dipendenteRepositorySupplier) {
        super("turni.txt");
        this.dipendenteRepositorySupplier = dipendenteRepositorySupplier;
    }

    @Override
    protected Integer getEntityId(Turno turno) {
        return turno.getId();
    }

    @Override
    protected String serialize(Turno turno) {
        return turno.toTextString();
    }

    @Override
    protected Turno deserialize(String data) {
        DipendenteRepository dipendenteRepo = dipendenteRepositorySupplier.get();
        return Turno.fromTextString(data, dipendenteRepo);
    }


    @Override
    public List<Turno> findByDipendente(Dipendente dipendente) {
        return entities.values().stream()
                .filter(t -> t.getDipendente() != null && t.getDipendente().getId() == dipendente.getId())
                .collect(Collectors.toList());
    }

    @Override
    public List<Turno> findByData(LocalDate data) {
        return entities.values().stream()
                .filter(t -> t.getData().isEqual(data))
                .collect(Collectors.toList());
    }

    @Override
    public List<Turno> findByDipendenteAndData(Dipendente dipendente, LocalDate data) {
        // Modificato: Usa la singola 'data' del turno.
        return entities.values().stream()
                .filter(t -> t.getDipendente() != null && t.getDipendente().getId() == dipendente.getId() &&
                        t.getData().isEqual(data))
                .collect(Collectors.toList());
    }
}