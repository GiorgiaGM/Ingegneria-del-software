package org.example.repository;

import org.example.model.Prenotazione;
import org.example.model.Cliente;
import org.example.model.Tavolo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public interface PrenotazioneRepository extends CrudRepository<Prenotazione, String> {
    Optional<Prenotazione> findByDataOraTavolo(LocalDate data, LocalTime ora, Tavolo tavolo);
    List<Prenotazione> findByData(LocalDate data);
    List<Prenotazione> findByCliente(Cliente cliente);
    List<Prenotazione> findByTavolo(Tavolo tavolo);
}