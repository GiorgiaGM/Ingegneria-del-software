package org.example.repository.impl;

import org.example.model.FidelityCard;
import org.example.model.Cliente;
import org.example.repository.FidelityCardRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.ClienteRepository;
import java.util.function.Supplier;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class FileFidelityCardRepository extends FileBasedCrudRepository<FidelityCard, Integer> implements FidelityCardRepository {

    private final Supplier<ClienteRepository> clienteRepositorySupplier;

    public FileFidelityCardRepository(Supplier<ClienteRepository> clienteRepositorySupplier) {
        super("fidelitycards.txt");
        this.clienteRepositorySupplier = clienteRepositorySupplier;
    }

    @Override
    protected Integer getEntityId(FidelityCard card) {
        return card.getIdCard();
    }

    @Override
    protected String serialize(FidelityCard card) {
        return card.toTextString();
    }

    @Override
    protected FidelityCard deserialize(String data) {
        ClienteRepository clienteRepo = clienteRepositorySupplier.get();
        return FidelityCard.fromTextString(data, clienteRepo);
    }

    public FidelityCard update(FidelityCard card) {
        if (entities.containsKey(card.getIdCard())) {
            entities.put(card.getIdCard(), card);
            saveAllEntitiesToFile();
            return card;
        } else {
            System.out.println("Updating non-existent FidelityCard. Saving as new.");
            return save(card);
        }
    }

    @Override
    public Optional<FidelityCard> findByCliente(Cliente cliente) {
        return entities.values().stream()
                .filter(c -> c.getCliente() != null && c.getCliente().getId() == cliente.getId())
                .findFirst();
    }

    @Override
    public Optional<FidelityCard> findByClienteId(int clienteId) {
        return entities.values().stream()
                .filter(c -> c.getCliente() != null && c.getCliente().getId() == clienteId)
                .findFirst();
    }

    @Override
    public List<FidelityCard> findByPuntiGreaterThanEqual(int minPunti) {
        return entities.values().stream()
                .filter(card -> card.getPuntiAccumulati() >= minPunti)
                .collect(Collectors.toList());
    }
}