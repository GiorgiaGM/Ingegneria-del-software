package org.example.repository;

import org.example.model.Piatto;

import java.util.List;
import java.util.Optional;

public interface PiattoRepository extends CrudRepository<Piatto, Integer> {
    Optional<Piatto> findByNome(String nome);
    List<Piatto> findByPrezzoLessThanEqual(float prezzo);
    List<Piatto> findByIngredientiId(int ingredienteId);
}