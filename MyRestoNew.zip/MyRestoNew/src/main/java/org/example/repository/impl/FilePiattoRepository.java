package org.example.repository.impl;

import org.example.model.Piatto;
import org.example.repository.PiattoRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.IngredienteRepository;
import java.util.function.Supplier;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class FilePiattoRepository extends FileBasedCrudRepository<Piatto, Integer> implements PiattoRepository {

    private final Supplier<IngredienteRepository> ingredienteRepositorySupplier;

    public FilePiattoRepository(Supplier<IngredienteRepository> ingredienteRepositorySupplier) {
        super("piatti.txt");
        this.ingredienteRepositorySupplier = ingredienteRepositorySupplier;
    }

    @Override
    protected Integer getEntityId(Piatto piatto) {
        return piatto.getId();
    }

    @Override
    protected String serialize(Piatto piatto) {
        return piatto.toTextString();
    }

    @Override
    protected Piatto deserialize(String data) {
        IngredienteRepository ingredienteRepository = ingredienteRepositorySupplier.get();
        return Piatto.fromTextString(data, ingredienteRepository);
    }

    @Override
    public Optional<Piatto> findByNome(String nome) {
        return entities.values().stream()
                .filter(p -> p.getNome().equalsIgnoreCase(nome))
                .findFirst();
    }

    @Override
    public List<Piatto> findByPrezzoLessThanEqual(float prezzo) {
        return entities.values().stream()
                .filter(p -> p.getPrezzo() <= prezzo)
                .collect(Collectors.toList());
    }

    @Override
    public List<Piatto> findByIngredientiId(int ingredienteId) {
        return entities.values().stream()
                .filter(piatto -> piatto.getIngredienti().stream()
                        .anyMatch(ing -> ing.getId() == ingredienteId))
                .collect(Collectors.toList());
    }
}