package org.example.repository;

import org.example.model.Tavolo;

import java.util.List;
import java.util.Optional;

public interface TavoloRepository extends CrudRepository<Tavolo, Integer> {
    Optional<Tavolo> findByNumeroTavolo(int numeroTavolo);
    List<Tavolo> findByNumPostiAndStato(int numPostiMinimi, String statoRichiesto);
    List<Tavolo> findByStato(String stato);
}