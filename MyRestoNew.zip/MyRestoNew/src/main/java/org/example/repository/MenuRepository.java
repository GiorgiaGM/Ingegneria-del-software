package org.example.repository;

import org.example.model.Ingrediente;
import org.example.model.Piatto;

import java.util.List;

public interface MenuRepository {
    List<Piatto> findAllPiatti();
    List<Ingrediente> findAllIngredienti();
}