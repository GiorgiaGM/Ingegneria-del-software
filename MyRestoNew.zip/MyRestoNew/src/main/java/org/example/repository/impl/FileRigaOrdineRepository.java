package org.example.repository.impl;

import org.example.model.RigaOrdine;
import org.example.model.Piatto;
import org.example.model.Variazione;
import org.example.repository.RigaOrdineRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.VariazioneRepository;
import org.example.repository.PiattoRepository;
import org.example.repository.OrdineRepository;

import java.util.List;
import java.util.stream.Collectors;
import java.util.function.Supplier;

public class FileRigaOrdineRepository extends FileBasedCrudRepository<RigaOrdine, Integer> implements RigaOrdineRepository {

    private final Supplier<PiattoRepository> piattoRepositorySupplier;
    private final Supplier<VariazioneRepository> variazioneRepositorySupplier;
    private final Supplier<OrdineRepository> ordineRepositorySupplier;

    public FileRigaOrdineRepository(Supplier<PiattoRepository> piattoRepositorySupplier, Supplier<VariazioneRepository> variazioneRepositorySupplier, Supplier<OrdineRepository> ordineRepositorySupplier) {
        super("righe_ordine.txt");
        this.piattoRepositorySupplier = piattoRepositorySupplier;
        this.variazioneRepositorySupplier = variazioneRepositorySupplier;
        this.ordineRepositorySupplier = ordineRepositorySupplier;
    }

    @Override
    protected Integer getEntityId(RigaOrdine rigaOrdine) {
        return rigaOrdine.getId();
    }

    @Override
    protected String serialize(RigaOrdine rigaOrdine) {
        return rigaOrdine.toTextString();
    }

    @Override
    protected RigaOrdine deserialize(String data) {
        PiattoRepository piattoRepo = piattoRepositorySupplier.get();
        VariazioneRepository variazioneRepo = variazioneRepositorySupplier.get();
        OrdineRepository ordineRepo = ordineRepositorySupplier.get();

        return RigaOrdine.fromTextString(data, piattoRepo, variazioneRepo, () -> ordineRepo);
    }

    @Override
    public List<RigaOrdine> findByPiatto(Piatto piatto) {
        return entities.values().stream()
                .filter(r -> r.getPiatto() != null && r.getPiatto().getId() == piatto.getId())
                .collect(Collectors.toList());
    }

    @Override
    public List<RigaOrdine> findByVariazione(Variazione variazione) {
        return entities.values().stream()
                .filter(r -> r.getVariazioni().contains(variazione))
                .collect(Collectors.toList());
    }

    @Override
    public List<RigaOrdine> findByOrdineId(int ordineId) {
        OrdineRepository currentOrdineRepository = ordineRepositorySupplier.get();
        return entities.values().stream()
                .filter(r -> r.getOrdine() != null && r.getOrdine().getIdOrdine() == ordineId)
                .collect(Collectors.toList());
    }

    @Override
    public java.util.Optional<RigaOrdine> findByOrdineIdAndPiattoId(int ordineId, int piattoId) {
        return entities.values().stream()
                .filter(r -> r.getOrdine() != null && r.getOrdine().getIdOrdine() == ordineId &&
                        r.getPiatto() != null && r.getPiatto().getId() == piattoId)
                .findFirst();
    }
}