package org.example.repository.impl;

import org.example.model.Variazione;
import org.example.model.RigaOrdine;
import org.example.repository.VariazioneRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.RigaOrdineRepository;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.function.Supplier;

public class FileVariazioneRepository extends FileBasedCrudRepository<Variazione, Integer> implements VariazioneRepository {

    private final Supplier<RigaOrdineRepository> rigaOrdineRepositorySupplier;

    public FileVariazioneRepository(Supplier<RigaOrdineRepository> rigaOrdineRepositorySupplier) {
        super("variazioni.txt");
        this.rigaOrdineRepositorySupplier = rigaOrdineRepositorySupplier;
    }

    @Override
    protected Integer getEntityId(Variazione variazione) {
        return variazione.getId();
    }

    @Override
    protected String serialize(Variazione variazione) {
        return variazione.toTextString();
    }

    @Override
    protected Variazione deserialize(String data) {
        RigaOrdineRepository rigaOrdineRepo = rigaOrdineRepositorySupplier.get();
        return Variazione.fromTextString(data, rigaOrdineRepo);
    }

    @Override
    public Optional<Variazione> findByTipo(String tipo) {
        return entities.values().stream()
                .filter(v -> v.getTipo().equalsIgnoreCase(tipo))
                .findFirst();
    }

    @Override
    public List<Variazione> findByCostoLessThanEqual(float maxCosto) {
        return entities.values().stream()
                .filter(v -> v.getCosto() <= maxCosto)
                .collect(Collectors.toList());
    }

    @Override
    public List<Variazione> findByRigaOrdine(RigaOrdine rigaOrdine) {
        return entities.values().stream()
                .filter(v -> v.getRigaOrdine() != null && v.getRigaOrdine().getId() == rigaOrdine.getId())
                .collect(Collectors.toList());
    }
}