package org.example.repository;

import org.example.model.Report;
import java.time.LocalDate;
import java.util.List;

public interface ReportRepository extends CrudRepository<Report, Integer> {
    List<Report> findByTipo(String tipo);
    List<Report> findByPeriodoReportBetween(LocalDate inizio, LocalDate fine);
}