package org.example.repository.impl;

import org.example.model.Report;
import org.example.repository.ReportRepository;
import org.example.repository.FileBasedCrudRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

public class FileReportRepository extends FileBasedCrudRepository<Report, Integer> implements ReportRepository {

    public FileReportRepository() {
        super("reports.txt");
    }

    @Override
    protected Integer getEntityId(Report report) {
        return report.getId();
    }

    @Override
    protected String serialize(Report report) {
        return report.toTextString();
    }

    @Override
    protected Report deserialize(String data) {
        return Report.fromTextString(data);
    }

    @Override
    public List<Report> findByTipo(String tipo) {
        return entities.values().stream()
                .filter(r -> r.getTipoReport().equalsIgnoreCase(tipo))
                .collect(Collectors.toList());
    }

    @Override
    public List<Report> findByPeriodoReportBetween(LocalDate inizio, LocalDate fine) {
        return entities.values().stream()
                .filter(r -> (r.getDataInizio().isBefore(fine) || r.getDataInizio().isEqual(fine)) &&
                        (r.getDataFine().isAfter(inizio) || r.getDataFine().isEqual(inizio)))
                .collect(Collectors.toList());
    }
}