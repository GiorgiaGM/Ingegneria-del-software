package org.example.repository;

import org.example.model.Ingrediente;

import java.util.Optional;
import java.util.List;

public interface IngredienteRepository extends CrudRepository<Ingrediente, Integer> {
    Optional<Ingrediente> findByNome(String nome);
    List<Ingrediente> findByPrezzoLessThanEqual(float prezzoMax);
}