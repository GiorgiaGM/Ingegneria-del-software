package org.example.repository.impl;

import org.example.model.Feedback;
import org.example.model.Cliente;
import org.example.model.Piatto;
import org.example.repository.FeedbackRepository;
import org.example.repository.FileBasedCrudRepository;
import org.example.repository.ClienteRepository;
import org.example.repository.PiattoRepository;
import java.util.List;
import java.util.stream.Collectors;
import java.util.function.Supplier;

public class FileFeedbackRepository extends FileBasedCrudRepository<Feedback, Integer> implements FeedbackRepository {

    private final Supplier<ClienteRepository> clienteRepositorySupplier;
    private final Supplier<PiattoRepository> piattoRepositorySupplier;

    public FileFeedbackRepository(Supplier<ClienteRepository> clienteRepositorySupplier, Supplier<PiattoRepository> piattoRepositorySupplier) {
        super("feedback.txt");
        this.clienteRepositorySupplier = clienteRepositorySupplier;
        this.piattoRepositorySupplier = piattoRepositorySupplier;
    }

    @Override
    protected Integer getEntityId(Feedback feedback) {
        return feedback.getId();
    }

    @Override
    protected String serialize(Feedback feedback) {
        return feedback.toTextString();
    }

    @Override
    protected Feedback deserialize(String data) {
        ClienteRepository clienteRepo = clienteRepositorySupplier.get();
        PiattoRepository piattoRepo = piattoRepositorySupplier.get();
        return Feedback.fromTextString(data, clienteRepo, piattoRepo);
    }

    @Override
    public List<Feedback> findByCliente(Cliente cliente) {
        return entities.values().stream()
                .filter(f -> f.getCliente() != null && f.getCliente().getId() == cliente.getId())
                .collect(Collectors.toList());
    }

    @Override
    public List<Feedback> findByPiatto(Piatto piatto) {
        return entities.values().stream()
                .filter(f -> f.getPiatto() != null && f.getPiatto().getId() == piatto.getId())
                .collect(Collectors.toList());
    }

    @Override
    public List<Feedback> findByValutazioneGreaterThanEqual(int minValutazione) {
        return entities.values().stream()
                .filter(f -> f.getValutazione() >= minValutazione)
                .collect(Collectors.toList());
    }
}