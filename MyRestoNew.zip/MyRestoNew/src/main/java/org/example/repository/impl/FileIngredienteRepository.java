package org.example.repository.impl;

import org.example.model.Ingrediente;
import org.example.repository.IngredienteRepository;
import org.example.repository.FileBasedCrudRepository;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class FileIngredienteRepository extends FileBasedCrudRepository<Ingrediente, Integer> implements IngredienteRepository {

    public FileIngredienteRepository() {
        super("ingredienti.txt");
    }

    @Override
    protected Integer getEntityId(Ingrediente ingrediente) {
        return ingrediente.getId();
    }

    @Override
    protected String serialize(Ingrediente ingrediente) {
        return ingrediente.toTextString();
    }

    @Override
    protected Ingrediente deserialize(String data) {
        return Ingrediente.fromTextString(data);
    }

    @Override
    public Optional<Ingrediente> findByNome(String nome) {
        return entities.values().stream()
                .filter(i -> i.getNome().equalsIgnoreCase(nome))
                .findFirst();
    }

    @Override
    public List<Ingrediente> findByPrezzoLessThanEqual(float prezzoMax) {
        return entities.values().stream()
                .filter(i -> i.getPrezzo() <= prezzoMax)
                .collect(Collectors.toList());
    }
}