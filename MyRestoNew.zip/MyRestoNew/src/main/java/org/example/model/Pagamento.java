package org.example.model;

import org.example.repository.OrdineRepository;
import org.example.repository.FidelityCardRepository;

import java.time.LocalDateTime;

public class Pagamento {
    private int id;
    private Ordine ordine;
    private double totale;
    private LocalDateTime dataPagamento;
    private FidelityCard fidelityCard;

    // Costruttore
    public Pagamento(int id, Ordine ordine, double totale, LocalDateTime dataPagamento, FidelityCard fidelityCard) {
        this.id = id;
        this.ordine = ordine;
        this.totale = totale;
        this.dataPagamento = dataPagamento;
        this.fidelityCard = fidelityCard;
    }

    // --- Getter e Setter  ---
    public int getId() { return id; }
    public Ordine getOrdine() { return ordine; }
    public double getTotale() { return totale; }
    public LocalDateTime getDataPagamento() { return dataPagamento; }
    public FidelityCard getFidelityCard() { return fidelityCard; }

    public void setId(int id) { this.id = id; }
    public void setOrdine(Ordine ordine) { this.ordine = ordine; }
    public void setTotale(double totale) { this.totale = totale; }
    public void setDataPagamento(LocalDateTime dataPagamento) { this.dataPagamento = dataPagamento; }
    public void setFidelityCard(FidelityCard fidelityCard) { this.fidelityCard = fidelityCard; }


    public String toTextString() {
        int ordineId = (ordine != null) ? ordine.getIdOrdine() : -1;
        int fidelityCardId = (fidelityCard != null) ? fidelityCard.getIdCard() : -1;
        return id + "|" + ordineId + "|" + totale + "|" +
                dataPagamento.toString() + "|" + fidelityCardId;
    }

    // Metodo statico per deserializzare una stringa di testo in un oggetto Pagamento
    public static Pagamento fromTextString(String data, OrdineRepository ordineRepository, FidelityCardRepository fidelityCardRepository) {
        String[] parts = data.split("\\|");
        int id = Integer.parseInt(parts[0]);
        int ordineId = Integer.parseInt(parts[1]);
        double totale = Double.parseDouble(parts[2]);
        LocalDateTime dataPagamento = LocalDateTime.parse(parts[3]);
        int fidelityCardId = Integer.parseInt(parts[4]);

        Ordine ordine = null;
        if (ordineId != -1) {
            ordine = ordineRepository.findById(ordineId).orElse(null);
            if (ordine == null) {
                System.err.println("Avviso: Ordine con ID " + ordineId + " non trovato durante la deserializzazione del Pagamento " + id);
            }
        }

        FidelityCard fidelityCard = null;
        if (fidelityCardId != -1) {
            fidelityCard = fidelityCardRepository.findById(fidelityCardId).orElse(null);
            if (fidelityCard == null) {
                System.err.println("Avviso: Fidelity Card con ID " + fidelityCardId + " non trovata durante la deserializzazione del Pagamento " + id);
            }
        }
        return new Pagamento(id, ordine, totale, dataPagamento, fidelityCard);
    }
}