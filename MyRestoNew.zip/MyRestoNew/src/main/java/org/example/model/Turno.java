package org.example.model;

import org.example.repository.DipendenteRepository;

import java.time.LocalDate;
import java.util.Objects;
import java.time.LocalTime;
import java.util.Optional;

public class Turno {
    private int id;
    private Dipendente dipendente;
    private LocalDate data;
    private LocalTime ora;
    private String tipoTurno;

    public Turno(int id, Dipendente dipendente, LocalDate data, LocalTime ora, String tipoTurno) {
        if (dipendente == null) {
            throw new IllegalArgumentException("Il dipendente non può essere null.");
        }
        if (data == null) {
            throw new IllegalArgumentException("La data del turno non può essere null.");
        }
        if (ora == null) {
            throw new IllegalArgumentException("L'ora del turno non può essere null.");
        }
        if (tipoTurno == null || tipoTurno.trim().isEmpty()) {
            throw new IllegalArgumentException("Il tipo di turno non può essere nullo o vuoto.");
        }

        this.id = id;
        this.dipendente = dipendente;
        this.data = data;
        this.ora = ora;
        this.tipoTurno = tipoTurno;
    }

    // --- Getter e Setter ---

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Dipendente getDipendente() { return dipendente; }
    public void setDipendente(Dipendente dipendente) {
        Objects.requireNonNull(dipendente, "Il dipendente non può essere null.");
        this.dipendente = dipendente;
    }
    public LocalDate getData() {
        return data;
    }

    public LocalTime getOra() {
        return ora;
    }

    public String getTipoTurno() { return tipoTurno; }
    public void setTipoTurno(String tipoTurno) {
        if (tipoTurno == null || tipoTurno.trim().isEmpty()) {
            throw new IllegalArgumentException("Il tipo di turno non può essere vuoto.");
        }
        this.tipoTurno = tipoTurno;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public void setOra(LocalTime ora) {
        this.ora = ora;
    }

    public String toTextString() {
        int dipendenteId = (dipendente != null) ? dipendente.getId() : -1;
        String encodedTipoTurno = (tipoTurno != null) ? tipoTurno.replace("|", "&#124;") : "";

        return id + "|" +
                dipendenteId + "|" +
                data.toString() + "|" +
                ora.toString() + "|" +
                encodedTipoTurno;
    }

    public static Turno fromTextString(String dataLine, DipendenteRepository dipendenteRepository) {
        String[] parts = dataLine.split("\\|");
        if (parts.length != 5) {
            System.err.println("Errore di deserializzazione: Stringa Turno non valida. Trovate " + parts.length + " parti, attese 5. Stringa: " + dataLine);
            throw new IllegalArgumentException("Formato dati Turno non valido.");
        }

        int id = Integer.parseInt(parts[0]);
        int dipendenteId = Integer.parseInt(parts[1]);
        LocalDate localData = LocalDate.parse(parts[2]);
        LocalTime localOra = LocalTime.parse(parts[3]);
        String encodedTipoTurno = parts[4];

        String tipoTurno = encodedTipoTurno.replace("&#124;", "|");

        Optional<Dipendente> dipendenteOptional = dipendenteRepository.findById(dipendenteId);
        Dipendente dipendente = dipendenteOptional.orElse(null);

        if (dipendente == null) {
            System.err.println("Avviso: Dipendente con ID " + dipendenteId + " non trovato durante la deserializzazione del Turno " + id);
            throw new IllegalArgumentException("Dipendente associato al turno non trovato: " + dipendenteId);
        }

        return new Turno(id, dipendente, localData, localOra, tipoTurno);
    }



    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Turno)) return false;
        Turno turno = (Turno) o;
        return id == turno.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Turno{" +
                "id=" + id +
                ", dipendente=" + dipendente +
                ", data=" + data +
                ", ora=" + ora +
                ", tipoTurno='" + tipoTurno + '\'' +
                '}';
    }
}