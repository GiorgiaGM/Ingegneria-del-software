package org.example.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


public class Menu {
    private List<Piatto> piatti;
    private List<Ingrediente> ingredientiDisponibili;

    public Menu() {
        this.piatti = new ArrayList<>();
        this.ingredientiDisponibili = new ArrayList<>();
    }

    // Getters
    public List<Piatto> getPiatti() {
        return piatti;
    }

    public List<Ingrediente> getIngredientiDisponibili() {
        return ingredientiDisponibili;
    }

    // Setters
    public void setPiatti(List<Piatto> piatti) {
        this.piatti = piatti;
    }

    public void setIngredientiDisponibili(List<Ingrediente> ingredientiDisponibili) {
        this.ingredientiDisponibili = ingredientiDisponibili;
    }


    public void addPiatto(Piatto piatto) {
        if (!piatti.contains(piatto)) {
            this.piatti.add(piatto);
        }
    }

    public void removePiatto(Piatto piatto) {
        this.piatti.remove(piatto);
    }

    public Optional<Piatto> findPiattoById(int id) {
        return piatti.stream().filter(p -> p.getId() == id).findFirst();
    }

    public Optional<Piatto> findPiattoByNome(String nome) {
        return piatti.stream().filter(p -> p.getNome().equalsIgnoreCase(nome)).findFirst();
    }

    public void addIngredienteDisponibile(Ingrediente ingrediente) {
        if (!ingredientiDisponibili.contains(ingrediente)) {
            this.ingredientiDisponibili.add(ingrediente);
        }
    }

    public void removeIngredienteDisponibile(Ingrediente ingrediente) {
        this.ingredientiDisponibili.remove(ingrediente);
    }

    public Optional<Ingrediente> findIngredienteDisponibileById(int id) {
        return ingredientiDisponibili.stream().filter(i -> i.getId() == id).findFirst();
    }

    public Optional<Ingrediente> findIngredienteDisponibileByNome(String nome) {
        return ingredientiDisponibili.stream().filter(i -> i.getNome().equalsIgnoreCase(nome)).findFirst();
    }


    @Override
    public String toString() {
        return "Menu{" +
                "numeroPiatti=" + piatti.size() +
                ", numeroIngredientiDisponibili=" + ingredientiDisponibili.size() +
                '}';
    }

}