package org.example.model;

import org.example.repository.RigaOrdineRepository;

public class Variazione {
    private int id;
    private String tipo;
    private float costo;
    private RigaOrdine rigaOrdine;

    public Variazione(int id, String tipo, float costo, RigaOrdine rigaOrdine) {
        this.id = id;
        this.tipo = tipo;
        this.costo = costo;
        this.rigaOrdine = rigaOrdine;
    }

    public Variazione(int id, String tipo, float costo) {
        this(id, tipo, costo, null);
    }

    // --- Getter e Setter ---
    public int getId() { return id; }
    public String getTipo() { return tipo; }
    public float getCosto() { return costo; }
    public RigaOrdine getRigaOrdine() { return rigaOrdine; }
    public void setRigaOrdine(RigaOrdine rigaOrdine) { this.rigaOrdine = rigaOrdine; }

    public String toTextString() {
        int rigaOrdineId = (rigaOrdine != null) ? rigaOrdine.getId() : -1;
        return id + "|" + tipo + "|" + costo + "|" + rigaOrdineId;
    }

    public static Variazione fromTextString(String data, RigaOrdineRepository rigaOrdineRepository) {
        String[] parts = data.split("\\|");
        int id = Integer.parseInt(parts[0]);
        String tipo = parts[1];
        float costo = Float.parseFloat(parts[2].replace(",", "."));
        int rigaOrdineId = Integer.parseInt(parts[3]);

        RigaOrdine rigaOrdine = null;
        if (rigaOrdineId != -1) {
            rigaOrdine = rigaOrdineRepository.findById(rigaOrdineId).orElse(null);
            if (rigaOrdine == null) {
                System.err.println("Avviso: RigaOrdine con ID " + rigaOrdineId + " non trovata durante la deserializzazione della Variazione " + id);
            }
        }
        return new Variazione(id, tipo, costo, rigaOrdine);
    }
}