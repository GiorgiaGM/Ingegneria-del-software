package org.example.model;

import java.util.Objects;

public class Cliente {
    private int id;
    private String nome;
    private String cognome;
    private String email;

    public Cliente(int id, String nome, String cognome, String email) {
        this.id = id;
        this.nome = nome;
        this.cognome = cognome;
        this.email = email;
    }

    public Cliente(String nome, String cognome, String email) {
        this(0, nome, cognome, email);
    }

    // Getters
    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getCognome() { return cognome; }
    public String getEmail() { return email; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setCognome(String cognome) { this.cognome = cognome; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cliente cliente = (Cliente) o;
        return id == cliente.id; // Confronta per ID int
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", cognome='" + cognome + '\'' +
                ", email='" + email + '\'' +
                '}';
    }

    private static final String DELIMITER = "|";


    public String toTextString() {
        return String.join(DELIMITER, String.valueOf(id), nome, cognome, email);
    }

    public static Cliente fromTextString(String textString) {
        String[] parts = textString.split("\\" + DELIMITER);
        if (parts.length != 4) {
            throw new IllegalArgumentException("Stringa Cliente malformata: " + textString);
        }
        int id = Integer.parseInt(parts[0]);
        String nome = parts[1];
        String cognome = parts[2];
        String email = parts[3];
        return new Cliente(id, nome, cognome, email);
    }
}