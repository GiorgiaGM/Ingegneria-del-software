package org.example.model;

import org.example.repository.IngredienteRepository;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Piatto {
    private int id;
    private String nome;
    private String descrizione;
    private float prezzo;
    private List<Ingrediente> ingredienti;

    // Costruttore
    public Piatto(int id, String nome, String descrizione, float prezzo, List<Ingrediente> ingredienti) {
        this.id = id;
        this.nome = nome;
        this.descrizione = descrizione;
        this.prezzo = prezzo;
        this.ingredienti = (ingredienti != null) ? new ArrayList<>(ingredienti) : new ArrayList<>();
    }

    public Piatto(int id, String nome, String descrizione, float prezzo) {
        this(id, nome, descrizione, prezzo, new ArrayList<>());
    }


    // --- Getter e Setter ---
    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getDescrizione() { return descrizione; }
    public float getPrezzo() { return prezzo; }
    public List<Ingrediente> getIngredienti() { return ingredienti; }

    public void setId(int id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setDescrizione(String descrizione) { this.descrizione = descrizione; }
    public void setPrezzo(float prezzo) { this.prezzo = prezzo; }
    public void setIngredienti(List<Ingrediente> ingredienti) { this.ingredienti = ingredienti; }

    public void addIngrediente(Ingrediente ingrediente) {
        if (!this.ingredienti.contains(ingrediente)) {
            this.ingredienti.add(ingrediente);
        }
    }
    public void removeIngrediente(Ingrediente ingrediente) {
        this.ingredienti.remove(ingrediente);
    }


    // Metodo per serializzare l'oggetto in una stringa di testo
    public String toTextString() {
        // Serializza gli ID degli ingredienti separati da virgole
        String ingredientiIds = ingredienti.stream()
                .map(ing -> String.valueOf(ing.getId()))
                .collect(Collectors.joining(","));
        // Se non ci sono ingredienti, la stringa sarà vuota o "null"
        if (ingredientiIds.isEmpty()) {
            ingredientiIds = "null"; // Usa "null" come marcatore per assenza di ingredienti
        }

        return id + "|" + nome + "|" + descrizione + "|" + prezzo + "|" + ingredientiIds;
    }

    // Metodo statico per deserializzare una stringa di testo in un oggetto Piatto
    public static Piatto fromTextString(String data, IngredienteRepository ingredienteRepository) {
        String[] parts = data.split("\\|");
        int id = Integer.parseInt(parts[0]);
        String nome = parts[1];
        String descrizione = parts[2];
        float prezzo = Float.parseFloat(parts[3].replace(",", "."));
        String ingredientiIdsString = parts[4];

        List<Ingrediente> resolvedIngredienti = new ArrayList<>();
        if (!"null".equals(ingredientiIdsString) && !ingredientiIdsString.isEmpty()) {
            Arrays.stream(ingredientiIdsString.split(","))
                    .map(Integer::parseInt)
                    .forEach(ingredienteId -> ingredienteRepository.findById(ingredienteId)
                            .ifPresent(resolvedIngredienti::add));
        }

        return new Piatto(id, nome, descrizione, prezzo, resolvedIngredienti);
    }
}