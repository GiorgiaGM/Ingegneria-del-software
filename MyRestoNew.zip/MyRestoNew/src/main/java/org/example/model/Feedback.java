package org.example.model;

import org.example.repository.ClienteRepository;
import org.example.repository.PiattoRepository;

public class Feedback {
    private int id;
    private Cliente cliente;
    private Piatto piatto;
    private int valutazione; // Da 1 a 5
    private String commento;

    public Feedback(int id, Cliente cliente, Piatto piatto, int valutazione, String commento) {
        this.id = id;
        this.cliente = cliente;
        this.piatto = piatto;
        this.valutazione = valutazione;
        this.commento = commento;
    }

    // Metodi Getter e Setter
    public int getId() { return id; }
    public Cliente getCliente() { return cliente; }
    public Piatto getPiatto() { return piatto; }
    public int getValutazione() { return valutazione; }
    public String getCommento() { return commento; }

    public void setId(int id) { this.id = id; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public void setPiatto(Piatto piatto) { this.piatto = piatto; }
    public void setValutazione(int valutazione) { this.valutazione = valutazione; }
    public void setCommento(String commento) { this.commento = commento; }


    // Metodo per serializzare l'oggetto in una stringa di testo
    public String toTextString() {
        int clienteId = (cliente != null) ? cliente.getId() : -1;
        int piattoId = (piatto != null) ? piatto.getId() : -1;

        return id + "|" + clienteId + "|" + piattoId + "|" + valutazione + "|" + commento;
    }

    // Metodo statico per deserializzare una stringa di testo in un oggetto Feedback
    public static Feedback fromTextString(String data, ClienteRepository clienteRepository, PiattoRepository piattoRepository) {
        String[] parts = data.split("\\|");
        int id = Integer.parseInt(parts[0]);
        int clienteId = Integer.parseInt(parts[1]);
        int piattoId = Integer.parseInt(parts[2]);
        int valutazione = Integer.parseInt(parts[3]);
        String commento = parts[4];

        Cliente cliente = null;
        if (clienteId != -1) {
            cliente = clienteRepository.findById(clienteId).orElse(null);
            if (cliente == null) {
                System.err.println("Avviso: Cliente con ID " + clienteId + " non trovato durante la deserializzazione del Feedback " + id);
            }
        }

        Piatto piatto = null;
        if (piattoId != -1) {
            piatto = piattoRepository.findById(piattoId).orElse(null);
            if (piatto == null) {
                System.err.println("Avviso: Piatto con ID " + piattoId + " non trovato durante la deserializzazione del Feedback " + id);
            }
        }

        return new Feedback(id, cliente, piatto, valutazione, commento);
    }
}