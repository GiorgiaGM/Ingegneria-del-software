package org.example.model;

import java.time.LocalDate;

public class Report {
    private int id;
    private String tipoReport;
    private LocalDate dataInizio;
    private LocalDate dataFine;
    private String contenuto;

    // Costruttore
    public Report(int id, String tipoReport, LocalDate dataInizio, LocalDate dataFine, String contenuto) {
        this.id = id;
        this.tipoReport = tipoReport;
        this.dataInizio = dataInizio;
        this.dataFine = dataFine;
        this.contenuto = contenuto;
    }

    // --- Getter e Setter ---
    public int getId() { return id; }
    public String getTipoReport() { return tipoReport; }
    public LocalDate getDataInizio() { return dataInizio; }
    public LocalDate getDataFine() { return dataFine; }
    public String getContenuto() { return contenuto; }

    public void setId(int id) { this.id = id; }
    public void setTipoReport(String tipoReport) { this.tipoReport = tipoReport; }
    public void setDataInizio(LocalDate dataInizio) { this.dataInizio = dataInizio; }
    public void setDataFine(LocalDate dataFine) { this.dataFine = dataFine; }
    public void setContenuto(String contenuto) { this.contenuto = contenuto; }


    // Metodo per serializzare l'oggetto in una stringa di testo
    public String toTextString() {
        return id + "|" + tipoReport + "|" + dataInizio.toString() + "|" + dataFine.toString() + "|" + contenuto;
    }

    // Metodo statico per deserializzare una stringa di testo in un oggetto Report
    public static Report fromTextString(String data) {
        String[] parts = data.split("\\|");
        int id = Integer.parseInt(parts[0]);
        String tipoReport = parts[1];
        LocalDate dataInizio = LocalDate.parse(parts[2]);
        LocalDate dataFine = LocalDate.parse(parts[3]);
        String contenuto = parts[4];

        return new Report(id, tipoReport, dataInizio, dataFine, contenuto);
    }
}