package org.example.model;

import java.util.Objects;

public class Tavolo {
    private int numeroTavolo;
    private int numPosti;
    private String stato;

    public static final String STATO_LIBERO = "Libero";
    public static final String STATO_OCCUPATO = "Occupato";
    public static final String STATO_RISERVATO = "Riservato";

    public Tavolo(int numeroTavolo, int numPosti, String stato) {
        this.numeroTavolo = numeroTavolo;
        this.numPosti = numPosti;
        this.stato = stato;
    }

    public Tavolo(int numeroTavolo, int numPosti) {
        this(numeroTavolo, numPosti, STATO_LIBERO);
    }

    // --- Getter e Setter ---
    public int getNumeroTavolo() { return numeroTavolo; }
    public void setNumeroTavolo(int numeroTavolo) { this.numeroTavolo = numeroTavolo; }

    public int getNumPosti() { return numPosti; }
    public void setNumPosti(int numPosti) { this.numPosti = numPosti; }
    public String getStato() { return stato; }
    public void setStato(String stato) {
        this.stato = stato;
    }

    public boolean isLibero() { return STATO_LIBERO.equals(this.stato); }
    public boolean isOccupato() { return STATO_OCCUPATO.equals(this.stato); }
    public boolean isRiservato() { return STATO_RISERVATO.equals(this.stato); }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tavolo tavolo = (Tavolo) o;
        return numeroTavolo == tavolo.numeroTavolo;
    }

    @Override
    public int hashCode() {
        return Objects.hash(numeroTavolo);
    }

    @Override
    public String toString() {
        return "Tavolo{" +
                "numeroTavolo=" + numeroTavolo +
                ", numPosti=" + numPosti +
                ", stato='" + stato + '\'' +
                '}';
    }

    // Metodo per serializzare l'oggetto in una stringa per il salvataggio su file
    public String toTextString() {
        return numeroTavolo + "|" + numPosti + "|" + stato;
    }

    public static Tavolo fromTextString(String data) {
        String[] parts = data.split("\\|");
        // Ora ci aspettiamo 3 parti
        if (parts.length < 3) {
            throw new IllegalArgumentException("Formato dati Tavolo non valido: " + data);
        }
        int numeroTavolo = Integer.parseInt(parts[0]);
        int numPosti = Integer.parseInt(parts[1]);
        String stato = parts[2];
        return new Tavolo(numeroTavolo, numPosti, stato);
    }
}