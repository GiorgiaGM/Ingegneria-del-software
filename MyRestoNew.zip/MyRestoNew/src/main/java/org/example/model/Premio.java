package org.example.model;

import java.util.Objects;

public class Premio {
    private int id;
    private String nome;
    private String descrizione;
    private int puntiNecessari;

    public Premio(int id, String nome, String descrizione, int puntiNecessari) {
        this.id = id;
        this.nome = nome;
        this.descrizione = descrizione;
        this.puntiNecessari = puntiNecessari;
    }

    public Premio(String nome, String descrizione, int puntiNecessari) {
        this(0, nome, descrizione, puntiNecessari);
    }

    // Getters
    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getDescrizione() { return descrizione; }
    public int getPuntiNecessari() { return puntiNecessari; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setDescrizione(String descrizione) { this.descrizione = descrizione; }
    public void setPuntiNecessari(int puntiNecessari) { this.puntiNecessari = puntiNecessari; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Premio premio = (Premio) o;
        return id == premio.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Premio{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", puntiNecessari=" + puntiNecessari +
                '}';
    }

    // --- Metodi per la persistenza su file di testo ---
    private static final String DELIMITER = "|";

    public String toTextString() {
        return String.join(DELIMITER,
                String.valueOf(id),
                nome,
                descrizione,
                String.valueOf(puntiNecessari));
    }

    public static Premio fromTextString(String textString) {
        String[] parts = textString.split("\\" + DELIMITER);
        if (parts.length != 4) {
            throw new IllegalArgumentException("Stringa Premio malformata: " + textString);
        }
        int id = Integer.parseInt(parts[0]);
        String nome = parts[1];
        String descrizione = parts[2];
        int puntiNecessari = Integer.parseInt(parts[3]);
        return new Premio(id, nome, descrizione, puntiNecessari);
    }
}