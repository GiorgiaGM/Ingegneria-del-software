package org.example.model;

import java.util.Objects;

public class Dipendente {
    private int id;
    private String nome;
    private String cognome;
    private String ruolo;

    public Dipendente(int id, String nome, String cognome, String ruolo) {
        this.id = id;
        this.nome = nome;
        this.cognome = cognome;
        this.ruolo = ruolo;
    }

    public Dipendente(String nome, String cognome, String ruolo) {
        this(0, nome, cognome, ruolo);
    }

    // Getters
    public int getId() { return id; }
    public String getNome() { return nome; }
    public String getCognome() { return cognome; }
    public String getRuolo() { return ruolo; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setCognome(String cognome) { this.cognome = cognome; }
    public void setRuolo(String ruolo) { this.ruolo = ruolo; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Dipendente that = (Dipendente) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Dipendente{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", cognome='" + cognome + '\'' +
                ", ruolo='" + ruolo + '\'' +
                '}';
    }

    private static final String DELIMITER = "|";

    public String toTextString() {
        return String.join(DELIMITER,
                String.valueOf(id),
                nome,
                cognome,
                ruolo);
    }

    public static Dipendente fromTextString(String textString) {
        String[] parts = textString.split("\\" + DELIMITER);
        if (parts.length != 4) {
            throw new IllegalArgumentException("Stringa Dipendente malformata: " + textString);
        }
        int id = Integer.parseInt(parts[0]);
        String nome = parts[1];
        String cognome = parts[2];
        String ruolo = parts[3];
        return new Dipendente(id, nome, cognome, ruolo);
    }
}