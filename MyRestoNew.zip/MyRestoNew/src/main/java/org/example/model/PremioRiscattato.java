package org.example.model;

import org.example.repository.ClienteRepository;
import org.example.repository.PremioRepository;

import java.time.LocalDateTime;

public class PremioRiscattato {
    private int id;
    private Cliente cliente;
    private Premio premio;
    private LocalDateTime dataRiscatto;

    // Costruttore
    public PremioRiscattato(int id, Cliente cliente, Premio premio, LocalDateTime dataRiscatto) {
        this.id = id;
        this.cliente = cliente;
        this.premio = premio;
        this.dataRiscatto = dataRiscatto;
    }

    // --- Getter e Setter ---
    public int getId() { return id; }
    public Cliente getCliente() { return cliente; }
    public Premio getPremio() { return premio; }
    public LocalDateTime getDataRiscatto() { return dataRiscatto; }

    public void setId(int id) { this.id = id; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public void setPremio(Premio premio) { this.premio = premio; }
    public void setDataRiscatto(LocalDateTime dataRiscatto) { this.dataRiscatto = dataRiscatto; }


    // Metodo per serializzare l'oggetto in una stringa di testo
    public String toTextString() {
        int clienteId = (cliente != null) ? cliente.getId() : -1;
        int premioId = (premio != null) ? premio.getId() : -1;

        return id + "|" + clienteId + "|" + premioId + "|" + dataRiscatto.toString();
    }

    // Metodo statico per deserializzare una stringa di testo in un oggetto PremioRiscattato
    public static PremioRiscattato fromTextString(String data, ClienteRepository clienteRepository, PremioRepository premioRepository) {
        String[] parts = data.split("\\|");
        int id = Integer.parseInt(parts[0]);
        int clienteId = Integer.parseInt(parts[1]);
        int premioId = Integer.parseInt(parts[2]);
        LocalDateTime dataRiscatto = LocalDateTime.parse(parts[3]);

        Cliente cliente = null;
        if (clienteId != -1) {
            cliente = clienteRepository.findById(clienteId).orElse(null);
            if (cliente == null) {
                System.err.println("Avviso: Cliente con ID " + clienteId + " non trovato durante la deserializzazione del PremioRiscattato " + id);
            }
        }

        Premio premio = null;
        if (premioId != -1) {
            premio = premioRepository.findById(premioId).orElse(null);
            if (premio == null) {
                System.err.println("Avviso: Premio con ID " + premioId + " non trovato durante la deserializzazione del PremioRiscattato " + id);
            }
        }

        return new PremioRiscattato(id, cliente, premio, dataRiscatto);
    }
}