package org.example.model;

import org.example.repository.ClienteRepository;
import org.example.repository.TavoloRepository;
import org.example.repository.RigaOrdineRepository;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Ordine {
    private int idOrdine;
    private Cliente cliente;
    private Tavolo tavolo;
    private LocalDateTime dataOraCreazione;
    private String statoOrdine;
    private List<RigaOrdine> righeOrdine;


    public Ordine(int idOrdine, Cliente cliente, Tavolo tavolo, String statoOrdine) {
        this.idOrdine = idOrdine;
        this.cliente = cliente;
        this.tavolo = tavolo;
        this.dataOraCreazione = LocalDateTime.now();
        this.statoOrdine = statoOrdine;
        this.righeOrdine = new ArrayList<>();
    }


    public Ordine(int idOrdine, Cliente cliente, Tavolo tavolo, LocalDateTime dataOraCreazione, String statoOrdine, List<RigaOrdine> righeOrdine) {
        this.idOrdine = idOrdine;
        this.cliente = cliente;
        this.tavolo = tavolo;
        this.dataOraCreazione = dataOraCreazione;
        this.statoOrdine = statoOrdine;
        this.righeOrdine = (righeOrdine != null) ? new ArrayList<>(righeOrdine) : new ArrayList<>();
    }


    // --- Getter e Setter ---
    public int getIdOrdine() { return idOrdine; }
    public void setIdOrdine(int idOrdine) { this.idOrdine = idOrdine; }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public Tavolo getTavolo() { return tavolo; }
    public void setTavolo(Tavolo tavolo) { this.tavolo = tavolo; }
    public LocalDateTime getDataOraCreazione() { return dataOraCreazione; }
    public void setDataOraCreazione(LocalDateTime dataOraCreazione) { this.dataOraCreazione = dataOraCreazione; }
    public String getStatoOrdine() { return statoOrdine; }
    public void setStatoOrdine(String statoOrdine) { this.statoOrdine = statoOrdine; }
    public List<RigaOrdine> getRigheOrdine() { return righeOrdine; }
    public void setRigheOrdine(List<RigaOrdine> righeOrdine) { this.righeOrdine = righeOrdine; }


    public void addRigaOrdine(RigaOrdine rigaOrdine) {
        if (rigaOrdine != null) {
            this.righeOrdine.add(rigaOrdine);
            rigaOrdine.setOrdine(this);
        }
    }

    public double calcolaTotale() {
        double totale = 0.0;
        if (righeOrdine != null) {
            for (RigaOrdine riga : righeOrdine) {
                totale += riga.calcolaCostoTotaleRiga();
            }
        }
        return totale;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ordine ordine = (Ordine) o;
        return idOrdine == ordine.idOrdine;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idOrdine);
    }

    @Override
    public String toString() {
        return "Ordine{" +
                "idOrdine=" + idOrdine +
                ", cliente=" + (cliente != null ? cliente.getId() : "N/A") +
                ", tavolo=" + (tavolo != null ? tavolo.getNumeroTavolo() : "N/A") +
                ", dataOraCreazione=" + dataOraCreazione +
                ", statoOrdine='" + statoOrdine + '\'' +
                ", righeOrdineCount=" + righeOrdine.size() +
                '}';
    }


    public String toTextString() {
        int clienteId = (cliente != null) ? cliente.getId() : -1;
        int tavoloId = (tavolo != null) ? tavolo.getNumeroTavolo() : -1;

        String righeOrdineIds = righeOrdine.stream()
                .map(r -> String.valueOf(r.getId()))
                .collect(Collectors.joining(","));
        if (righeOrdineIds.isEmpty()) {
            righeOrdineIds = "null";
        }

        // Costruisce la stringa serializzata con l'ordine definito
        return String.join("|",
                String.valueOf(idOrdine),
                String.valueOf(clienteId),
                String.valueOf(tavoloId),
                dataOraCreazione.toString(),
                statoOrdine,
                righeOrdineIds
        );
    }

    public static Ordine fromTextString(String data, ClienteRepository clienteRepository, TavoloRepository tavoloRepository, RigaOrdineRepository rigaOrdineRepository) {
        String[] parts = data.split("\\|");
        if (parts.length < 6) {
            throw new IllegalArgumentException("Formato dati Ordine non valido: " + data + ". Attese almeno 6 parti (id|clienteId|tavoloId|dataOraCreazione|statoOrdine|righeOrdineIds).");
        }

        int idOrdine = Integer.parseInt(parts[0]);
        int clienteId = Integer.parseInt(parts[1]);
        int tavoloId = Integer.parseInt(parts[2]);
        LocalDateTime dataOraCreazione = LocalDateTime.parse(parts[3]);
        String statoOrdine = parts[4];
        String righeOrdineIdsString = parts[5];

        Cliente cliente = clienteRepository.findById(clienteId).orElse(null);
        if (cliente == null && clienteId != -1) {
            System.err.println("Avviso: Cliente con ID " + clienteId + " non trovato durante la deserializzazione dell'Ordine " + idOrdine);
        }

        Tavolo tavolo = tavoloRepository.findByNumeroTavolo(tavoloId).orElse(null);
        if (tavolo == null && tavoloId != -1) {
            System.err.println("Avviso: Tavolo con ID " + tavoloId + " non trovato durante la deserializzazione dell'Ordine " + idOrdine);
        }

        List<RigaOrdine> resolvedRigheOrdine = new ArrayList<>();
        if (!"null".equals(righeOrdineIdsString) && !righeOrdineIdsString.isEmpty()) {
            String[] rigaIds = righeOrdineIdsString.split(",");
            for (String rigaIdStr : rigaIds) {
                try {
                    int rigaId = Integer.parseInt(rigaIdStr.trim());
                    rigaOrdineRepository.findById(rigaId)
                            .ifPresent(resolvedRigheOrdine::add);
                } catch (NumberFormatException e) {
                    System.err.println("Avviso: ID riga ordine non valido '" + rigaIdStr + "' durante la deserializzazione dell'Ordine " + idOrdine);
                }
            }
        }

        Ordine ordine = new Ordine(idOrdine, cliente, tavolo, dataOraCreazione, statoOrdine, resolvedRigheOrdine);

        for (RigaOrdine riga : resolvedRigheOrdine) {
            riga.setOrdine(ordine);
        }

        return ordine;
    }
}