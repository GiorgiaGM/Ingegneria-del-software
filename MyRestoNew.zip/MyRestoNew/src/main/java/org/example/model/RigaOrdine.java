package org.example.model;

import org.example.repository.OrdineRepository;
import org.example.repository.PiattoRepository;
import org.example.repository.VariazioneRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.function.Supplier;

public class RigaOrdine {
    private int id;
    private int quantita;
    private float prezzoUnitario;
    private Piatto piatto;
    private List<Variazione> variazioni;
    private String note;
    private Ordine ordine;

    public RigaOrdine(int id, int quantita, float prezzoUnitario, Piatto piatto, List<Variazione> variazioni, String note, Ordine ordine) {
        this.id = id;
        this.quantita = quantita;
        this.prezzoUnitario = prezzoUnitario;
        this.piatto = piatto;
        this.variazioni = variazioni != null ? new ArrayList<>(variazioni) : new ArrayList<>();
        this.note = note;
        this.ordine = ordine;
    }

    public RigaOrdine(int id, int quantita, float prezzoUnitario, Piatto piatto, String note) {
        this(id, quantita, prezzoUnitario, piatto, null, note, null); // Chiama il costruttore completo
    }

    // --- Getter e Setter ---
    public int getId() { return id; }
    public int getQuantita() { return quantita; }
    public void setQuantita(int quantita) { this.quantita = quantita; }
    public float getPrezzoUnitario() { return prezzoUnitario; }
    public Piatto getPiatto() { return piatto; }
    public List<Variazione> getVariazioni() { return new ArrayList<>(variazioni); }
    public String getNote() { return note; }
    public Ordine getOrdine() { return ordine; }
    public void setOrdine(Ordine ordine) { this.ordine = ordine; }

    public void addVariazione(Variazione variazione) {
        if (variazione != null && !this.variazioni.contains(variazione)) {
            this.variazioni.add(variazione);
        }
    }

    public void removeVariazione(Variazione variazione) {
        this.variazioni.remove(variazione);
    }

    public double calcolaCostoTotaleRiga() {
        double costoVariazioni = variazioni.stream()
                .mapToDouble(Variazione::getCosto)
                .sum();
        return (prezzoUnitario + costoVariazioni) * quantita;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RigaOrdine that = (RigaOrdine) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "RigaOrdine{" +
                "id=" + id +
                ", quantita=" + quantita +
                ", prezzoUnitario=" + prezzoUnitario +
                ", piatto=" + (piatto != null ? piatto.getNome() : "N/A") +
                ", variazioni=" + variazioni.stream().map(Variazione::getTipo).collect(Collectors.joining(", ")) +
                ", note='" + note + '\'' +
                ", ordineId=" + (ordine != null ? ordine.getIdOrdine() : "N/A") +
                '}';
    }


    // --- Metodi per la serializzazione/deserializzazione ---
    public String toTextString() {
        String variazioniIds = variazioni.stream()
                .map(v -> String.valueOf(v.getId()))
                .collect(Collectors.joining(","));
        if (variazioniIds.isEmpty()) {
            variazioniIds = "null";
        }
        int ordineId = (ordine != null) ? ordine.getIdOrdine() : -1;

        return String.join("|",
                String.valueOf(id),
                String.valueOf(quantita),
                String.valueOf(prezzoUnitario),
                String.valueOf(piatto.getId()),
                variazioniIds,
                note,
                String.valueOf(ordineId)
        );
    }


    public static RigaOrdine fromTextString(String text,
                                            PiattoRepository piattoRepository,
                                            VariazioneRepository variazioneRepository,
                                            Supplier<OrdineRepository> ordineRepositorySupplier) {
        String[] parts = text.split("\\|");
        if (parts.length < 7) {
            throw new IllegalArgumentException("Formato dati RigaOrdine non valido: " + text + ". Attese 7 parti.");
        }

        int id = Integer.parseInt(parts[0]);
        int quantita = Integer.parseInt(parts[1]);
        float prezzoUnitario = Float.parseFloat(parts[2].replace(",", "."));
        int piattoId = Integer.parseInt(parts[3]);
        String variazioniIdsString = parts[4]; // Contiene gli ID delle variazioni o "null"
        String note = parts[5];
        int ordineId = Integer.parseInt(parts[6]);

        Piatto piatto = piattoRepository.findById(piattoId)
                .orElseThrow(() -> new IllegalArgumentException("Piatto non trovato (ID: " + piattoId + ") durante deserializzazione RigaOrdine: " + text));

        List<Variazione> variazioni = new ArrayList<>();
        if (!"null".equals(variazioniIdsString) && !variazioniIdsString.isEmpty()) {
            String[] variazioniIds = variazioniIdsString.split(",");
            for (String varIdStr : variazioniIds) {
                try {
                    variazioneRepository.findById(Integer.parseInt(varIdStr.trim()))
                            .ifPresent(variazioni::add);
                } catch (NumberFormatException e) {
                    System.err.println("Avviso: ID variazione non valido '" + varIdStr + "' durante la deserializzazione di RigaOrdine " + id);
                }
            }
        }

        Ordine ordine = null;
        if (ordineId != -1) {
            OrdineRepository tempOrdineRepo = ordineRepositorySupplier.get();
            ordine = tempOrdineRepo.findById(ordineId).orElse(null);
            if (ordine == null) {
                System.err.println("Avviso: Ordine con ID " + ordineId + " non trovato durante la deserializzazione di RigaOrdine " + id + ". L'ordine potrebbe non essere ancora stato caricato o esiste un errore nei dati.");
            }
        }

        return new RigaOrdine(id, quantita, prezzoUnitario, piatto, variazioni, note, ordine);
    }
}