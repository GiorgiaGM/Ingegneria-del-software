package org.example.model;

import org.example.repository.ClienteRepository;
import org.example.repository.TavoloRepository;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Prenotazione {
    private String codicePrenotazione;
    private LocalDate data;
    private LocalTime ora;
    private int numeroPersone;
    private Cliente cliente;
    private Tavolo tavoloAssegnato;
    private String statoPrenotazione;

    public static final String STATO_ATTIVA = "ATTIVA";
    public static final String STATO_COMPLETATA = "COMPLETATA";
    public static final String STATO_ANNULLATA = "ANNULLATA";
    public static final String STATO_ARRIVATO = "ARRIVATO";

    private static final Set<String> STATI_VALIDI = new HashSet<>(Arrays.asList(
            STATO_ATTIVA, STATO_COMPLETATA, STATO_ANNULLATA, STATO_ARRIVATO
    ));

    // Costruttore
    public Prenotazione(String codicePrenotazione, Cliente cliente, LocalDate data, LocalTime ora,
                        int numeroPersone, Tavolo tavoloAssegnato, String statoPrenotazione) {
        if (!STATI_VALIDI.contains(statoPrenotazione.toUpperCase())) {
            throw new IllegalArgumentException("Stato prenotazione non valido: " + statoPrenotazione +
                    ". I valori permessi sono: " + String.join(", ", STATI_VALIDI));
        }

        this.codicePrenotazione = codicePrenotazione;
        this.cliente = cliente;
        this.data = data;
        this.ora = ora;
        this.numeroPersone = numeroPersone;
        this.tavoloAssegnato = tavoloAssegnato;
        this.statoPrenotazione = statoPrenotazione.toUpperCase();
    }

    // --- Getter e Setter ---

    public String getCodicePrenotazione() { return codicePrenotazione; }
    public void setCodicePrenotazione(String codicePrenotazione) { this.codicePrenotazione = codicePrenotazione; }

    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    public LocalDate getData() { return data; }
    public void setData(LocalDate data) { this.data = data; }

    public LocalTime getOra() { return ora; }
    public void setOra(LocalTime ora) { this.ora = ora; }

    public int getNumeroPersone() { return numeroPersone; }
    public void setNumeroPersone(int numeroPersone) { this.numeroPersone = numeroPersone; }

    public Tavolo getTavoloAssegnato() { return tavoloAssegnato; }
    public void setTavoloAssegnato(Tavolo tavoloAssegnato) { this.tavoloAssegnato = tavoloAssegnato; }

    public String getStatoPrenotazione() { return statoPrenotazione; }
    public void setStatoPrenotazione(String statoPrenotazione) {
        if (!STATI_VALIDI.contains(statoPrenotazione.toUpperCase())) {
            throw new IllegalArgumentException("Stato prenotazione non valido: " + statoPrenotazione +
                    ". I valori permessi sono: " + String.join(", ", STATI_VALIDI));
        }
        this.statoPrenotazione = statoPrenotazione.toUpperCase();
    }

    // Metodo per serializzare l'oggetto in una stringa di testo per la persistenza
    public String toTextString() {
        int clienteId = (cliente != null) ? cliente.getId() : -1;
        int tavoloNumero = (tavoloAssegnato != null) ? tavoloAssegnato.getNumeroTavolo() : -1;

        return codicePrenotazione + "|" + clienteId + "|" + data.toString() + "|" +
                ora.toString() + "|" + numeroPersone + "|" + tavoloNumero + "|" + statoPrenotazione;
    }

    // Metodo statico per deserializzare una stringa di testo in un oggetto Prenotazione
    public static Prenotazione fromTextString(String data, ClienteRepository clienteRepository, TavoloRepository tavoloRepository) {
        String[] parts = data.split("\\|");
        String codicePrenotazione = parts[0];
        int clienteId = Integer.parseInt(parts[1]);
        LocalDate localDate = LocalDate.parse(parts[2]);
        LocalTime localTime = LocalTime.parse(parts[3]);
        int numeroPersone = Integer.parseInt(parts[4]);
        int tavoloNumero = Integer.parseInt(parts[5]);
        String statoPrenotazione = parts[6];

        Cliente cliente = clienteRepository.findById(clienteId)
                .orElseThrow(() -> new IllegalArgumentException("Cliente con ID " + clienteId + " non trovato durante la deserializzazione della Prenotazione " + codicePrenotazione));

        Tavolo tavolo = null;
        if (tavoloNumero != -1) { // -1 indica che non c'è un tavolo assegnato
            tavolo = tavoloRepository.findByNumeroTavolo(tavoloNumero)
                    .orElseThrow(() -> new IllegalArgumentException("Tavolo con numero " + tavoloNumero + " non trovato durante la deserializzazione della Prenotazione " + codicePrenotazione));
        }

        return new Prenotazione(codicePrenotazione, cliente, localDate, localTime, numeroPersone, tavolo, statoPrenotazione);
    }
}