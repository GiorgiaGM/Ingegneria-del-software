package org.example.model;

import java.util.Objects;

public class Ingrediente {
    private int id;
    private String nome;
    private float prezzo;

    public Ingrediente(int id, String nome, float prezzo) {
        this.id = id;
        this.nome = nome;
        this.prezzo = prezzo;
    }

    // Costruttore per la deserializzazione
    public Ingrediente() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public float getPrezzo() { // Getter per prezzo
        return prezzo;
    }

    public void setPrezzo(float prezzo) { // Setter per prezzo
        this.prezzo = prezzo;
    }

    // Metodi per serializzazione/deserializzazione
    public String toTextString() {
        return String.format("%d;%s;%.2f", id, nome, prezzo);
    }

    public static Ingrediente fromTextString(String text) {
        String[] parts = text.split(";");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Formato stringa Ingrediente non valido: " + text);
        }
        int id = Integer.parseInt(parts[0]);
        String nome = parts[1];
        float prezzo = Float.parseFloat(parts[2].replace(",", "."));
        return new Ingrediente(id, nome, prezzo);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Ingrediente that = (Ingrediente) o;
        return id == that.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public String toString() {
        return "Ingrediente{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", prezzo=" + prezzo +
                '}';
    }
}