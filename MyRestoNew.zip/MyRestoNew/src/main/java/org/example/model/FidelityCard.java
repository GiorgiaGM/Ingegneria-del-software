package org.example.model;

import org.example.repository.ClienteRepository;

public class FidelityCard {
    private int idCard;
    private Cliente cliente;
    private int puntiAccumulati;

    public FidelityCard(int idCard, Cliente cliente, int puntiAccumulati) {
        this.idCard = idCard;
        this.cliente = cliente;
        this.puntiAccumulati = puntiAccumulati;
    }

    // --- Getter ---
    public int getIdCard() { return idCard; }
    public Cliente getCliente() { return cliente; }
    public int getPuntiAccumulati() { return puntiAccumulati; }

    // --- Setter ---
    public void setIdCard(int idCard) { this.idCard = idCard; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }
    public void setPuntiAccumulati(int puntiAccumulati) { this.puntiAccumulati = puntiAccumulati; }


    public String toTextString() {
        int clienteId = (cliente != null) ? cliente.getId() : -1;
        return idCard + "|" + clienteId + "|" + puntiAccumulati;
    }

    public static FidelityCard fromTextString(String data, ClienteRepository clienteRepository) {
        String[] parts = data.split("\\|");
        int idCard = Integer.parseInt(parts[0]);
        int clienteId = Integer.parseInt(parts[1]);
        int puntiAccumulati = Integer.parseInt(parts[2]);

        Cliente cliente = null;
        if (clienteId != -1) {
            cliente = clienteRepository.findById(clienteId).orElse(null);
        }

        return new FidelityCard(idCard, cliente, puntiAccumulati);
    }
}